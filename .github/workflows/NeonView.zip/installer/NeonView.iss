﻿; NeonView — установщик (Inno Setup 6)
; Собирается автоматически в GitHub Actions.

#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif
#ifndef SourceDir
  #define SourceDir "..\publish"
#endif

[Setup]
AppId={{6E7B3C2A-9D41-4F3B-A8E5-2C7D1B9F4E10}
AppName=NeonView
AppVersion={#AppVersion}
AppVerName=NeonView {#AppVersion}
AppPublisher=NeonView
AppComments=Безопасный офлайн-просмотрщик и редактор фотографий
DefaultDirName={autopf}\NeonView
DefaultGroupName=NeonView
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
MinVersion=10.0.17763
OutputDir=output
OutputBaseFilename=NeonView-Setup-{#AppVersion}
SetupIconFile=..\src\NeonView\Assets\NeonView.ico
UninstallDisplayIcon={app}\NeonView.exe
UninstallDisplayName=NeonView
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ChangesAssociations=yes
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "assoc"; Description: "Зарегистрировать NeonView для всех форматов изображений (появится в «Приложениях по умолчанию», эскизы Windows сохраняются)"; GroupDescription: "Интеграция с Windows:"
Name: "firewall"; Description: "Запретить NeonView любой доступ к сети (правило брандмауэра Windows)"; GroupDescription: "Безопасность:"
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Ярлыки:"; Flags: unchecked

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\NeonView"; Filename: "{app}\NeonView.exe"; Comment: "Просмотр и редактирование фотографий"
Name: "{autodesktop}\NeonView"; Filename: "{app}\NeonView.exe"; Tasks: desktopicon

[Registry]
; ===== Регистрация NeonView (сгенерировано) =====
Root: HKLM; Subkey: "Software\Microsoft\Windows\CurrentVersion\App Paths\NeonView.exe"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe"; ValueType: string; ValueName: "FriendlyAppName"; ValueData: "NeonView"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities"; ValueType: string; ValueName: "ApplicationName"; ValueData: "NeonView"; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities"; ValueType: string; ValueName: "ApplicationDescription"; ValueData: "Безопасный офлайн-просмотрщик и редактор фотографий"; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities"; ValueType: string; ValueName: "ApplicationIcon"; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\RegisteredApplications"; ValueType: string; ValueName: "NeonView"; ValueData: "Software\NeonView\Capabilities"; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\image\shell\NeonView"; ValueType: string; ValueName: ""; ValueData: "Открыть в NeonView"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\image\shell\NeonView"; ValueType: string; ValueName: "Icon"; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\image\shell\NeonView\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
; .jpg
Root: HKLM; Subkey: "Software\Classes\NeonView.jpg"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpg"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpg\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpg\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpg\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpg\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.jpg\OpenWithProgids"; ValueType: string; ValueName: "NeonView.jpg"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".jpg"; ValueData: "NeonView.jpg"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".jpg"; ValueData: ""; Tasks: assoc
; .jpeg
Root: HKLM; Subkey: "Software\Classes\NeonView.jpeg"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpeg"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpeg\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpeg\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpeg\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpeg\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.jpeg\OpenWithProgids"; ValueType: string; ValueName: "NeonView.jpeg"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".jpeg"; ValueData: "NeonView.jpeg"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".jpeg"; ValueData: ""; Tasks: assoc
; .jpe
Root: HKLM; Subkey: "Software\Classes\NeonView.jpe"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpe"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpe\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpe\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpe\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpe\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.jpe\OpenWithProgids"; ValueType: string; ValueName: "NeonView.jpe"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".jpe"; ValueData: "NeonView.jpe"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".jpe"; ValueData: ""; Tasks: assoc
; .jfif
Root: HKLM; Subkey: "Software\Classes\NeonView.jfif"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jfif"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jfif\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jfif\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jfif\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jfif\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.jfif\OpenWithProgids"; ValueType: string; ValueName: "NeonView.jfif"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".jfif"; ValueData: "NeonView.jfif"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".jfif"; ValueData: ""; Tasks: assoc
; .png
Root: HKLM; Subkey: "Software\Classes\NeonView.png"; ValueType: string; ValueName: ""; ValueData: "Изображение PNG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.png"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение PNG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.png\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.png\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.png\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.png\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.png\OpenWithProgids"; ValueType: string; ValueName: "NeonView.png"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".png"; ValueData: "NeonView.png"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".png"; ValueData: ""; Tasks: assoc
; .apng
Root: HKLM; Subkey: "Software\Classes\NeonView.apng"; ValueType: string; ValueName: ""; ValueData: "Анимированный PNG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.apng"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Анимированный PNG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.apng\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.apng\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.apng\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.apng\OpenWithProgids"; ValueType: string; ValueName: "NeonView.apng"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".apng"; ValueData: "NeonView.apng"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".apng"; ValueData: ""; Tasks: assoc
; .bmp
Root: HKLM; Subkey: "Software\Classes\NeonView.bmp"; ValueType: string; ValueName: ""; ValueData: "Точечный рисунок BMP"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.bmp"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Точечный рисунок BMP"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.bmp\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.bmp\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.bmp\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.bmp\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.bmp\OpenWithProgids"; ValueType: string; ValueName: "NeonView.bmp"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".bmp"; ValueData: "NeonView.bmp"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".bmp"; ValueData: ""; Tasks: assoc
; .dib
Root: HKLM; Subkey: "Software\Classes\NeonView.dib"; ValueType: string; ValueName: ""; ValueData: "Точечный рисунок DIB"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dib"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Точечный рисунок DIB"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dib\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dib\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dib\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dib\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.dib\OpenWithProgids"; ValueType: string; ValueName: "NeonView.dib"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".dib"; ValueData: "NeonView.dib"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".dib"; ValueData: ""; Tasks: assoc
; .gif
Root: HKLM; Subkey: "Software\Classes\NeonView.gif"; ValueType: string; ValueName: ""; ValueData: "Изображение GIF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.gif"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение GIF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.gif\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.gif\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.gif\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.gif\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.gif\OpenWithProgids"; ValueType: string; ValueName: "NeonView.gif"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".gif"; ValueData: "NeonView.gif"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".gif"; ValueData: ""; Tasks: assoc
; .tif
Root: HKLM; Subkey: "Software\Classes\NeonView.tif"; ValueType: string; ValueName: ""; ValueData: "Изображение TIFF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tif"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение TIFF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tif\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tif\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tif\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tif\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.tif\OpenWithProgids"; ValueType: string; ValueName: "NeonView.tif"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".tif"; ValueData: "NeonView.tif"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".tif"; ValueData: ""; Tasks: assoc
; .tiff
Root: HKLM; Subkey: "Software\Classes\NeonView.tiff"; ValueType: string; ValueName: ""; ValueData: "Изображение TIFF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tiff"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение TIFF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tiff\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tiff\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tiff\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tiff\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.tiff\OpenWithProgids"; ValueType: string; ValueName: "NeonView.tiff"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".tiff"; ValueData: "NeonView.tiff"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".tiff"; ValueData: ""; Tasks: assoc
; .ico
Root: HKLM; Subkey: "Software\Classes\NeonView.ico"; ValueType: string; ValueName: ""; ValueData: "Значок ICO"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ico"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Значок ICO"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ico\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ico\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ico\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ico\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.ico\OpenWithProgids"; ValueType: string; ValueName: "NeonView.ico"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".ico"; ValueData: "NeonView.ico"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".ico"; ValueData: ""; Tasks: assoc
; .cur
Root: HKLM; Subkey: "Software\Classes\NeonView.cur"; ValueType: string; ValueName: ""; ValueData: "Курсор CUR"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cur"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Курсор CUR"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cur\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cur\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cur\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.cur\OpenWithProgids"; ValueType: string; ValueName: "NeonView.cur"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".cur"; ValueData: "NeonView.cur"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".cur"; ValueData: ""; Tasks: assoc
; .webp
Root: HKLM; Subkey: "Software\Classes\NeonView.webp"; ValueType: string; ValueName: ""; ValueData: "Изображение WebP"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.webp"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение WebP"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.webp\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.webp\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.webp\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.webp\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.webp\OpenWithProgids"; ValueType: string; ValueName: "NeonView.webp"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".webp"; ValueData: "NeonView.webp"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".webp"; ValueData: ""; Tasks: assoc
; .heic
Root: HKLM; Subkey: "Software\Classes\NeonView.heic"; ValueType: string; ValueName: ""; ValueData: "Изображение HEIC"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heic"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение HEIC"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heic\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heic\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heic\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heic\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.heic\OpenWithProgids"; ValueType: string; ValueName: "NeonView.heic"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".heic"; ValueData: "NeonView.heic"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".heic"; ValueData: ""; Tasks: assoc
; .heif
Root: HKLM; Subkey: "Software\Classes\NeonView.heif"; ValueType: string; ValueName: ""; ValueData: "Изображение HEIF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heif"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение HEIF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heif\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heif\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heif\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.heif\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.heif\OpenWithProgids"; ValueType: string; ValueName: "NeonView.heif"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".heif"; ValueData: "NeonView.heif"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".heif"; ValueData: ""; Tasks: assoc
; .hif
Root: HKLM; Subkey: "Software\Classes\NeonView.hif"; ValueType: string; ValueName: ""; ValueData: "Изображение HEIF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hif"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение HEIF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hif\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hif\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hif\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hif\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.hif\OpenWithProgids"; ValueType: string; ValueName: "NeonView.hif"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".hif"; ValueData: "NeonView.hif"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".hif"; ValueData: ""; Tasks: assoc
; .avif
Root: HKLM; Subkey: "Software\Classes\NeonView.avif"; ValueType: string; ValueName: ""; ValueData: "Изображение AVIF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.avif"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение AVIF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.avif\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.avif\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.avif\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.avif\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.avif\OpenWithProgids"; ValueType: string; ValueName: "NeonView.avif"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".avif"; ValueData: "NeonView.avif"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".avif"; ValueData: ""; Tasks: assoc
; .jxl
Root: HKLM; Subkey: "Software\Classes\NeonView.jxl"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG XL"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jxl"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG XL"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jxl\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jxl\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jxl\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jxl\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.jxl\OpenWithProgids"; ValueType: string; ValueName: "NeonView.jxl"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".jxl"; ValueData: "NeonView.jxl"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".jxl"; ValueData: ""; Tasks: assoc
; .psd
Root: HKLM; Subkey: "Software\Classes\NeonView.psd"; ValueType: string; ValueName: ""; ValueData: "Документ Photoshop"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.psd"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Документ Photoshop"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.psd\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.psd\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.psd\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.psd\OpenWithProgids"; ValueType: string; ValueName: "NeonView.psd"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".psd"; ValueData: "NeonView.psd"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".psd"; ValueData: ""; Tasks: assoc
; .svg
Root: HKLM; Subkey: "Software\Classes\NeonView.svg"; ValueType: string; ValueName: ""; ValueData: "Векторный рисунок SVG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svg"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Векторный рисунок SVG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svg\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svg\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svg\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.svg\OpenWithProgids"; ValueType: string; ValueName: "NeonView.svg"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".svg"; ValueData: "NeonView.svg"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".svg"; ValueData: ""; Tasks: assoc
; .svgz
Root: HKLM; Subkey: "Software\Classes\NeonView.svgz"; ValueType: string; ValueName: ""; ValueData: "Сжатый рисунок SVG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svgz"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Сжатый рисунок SVG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svgz\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svgz\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.svgz\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.svgz\OpenWithProgids"; ValueType: string; ValueName: "NeonView.svgz"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".svgz"; ValueData: "NeonView.svgz"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".svgz"; ValueData: ""; Tasks: assoc
; .tga
Root: HKLM; Subkey: "Software\Classes\NeonView.tga"; ValueType: string; ValueName: ""; ValueData: "Изображение TGA"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tga"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение TGA"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tga\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tga\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.tga\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.tga\OpenWithProgids"; ValueType: string; ValueName: "NeonView.tga"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".tga"; ValueData: "NeonView.tga"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".tga"; ValueData: ""; Tasks: assoc
; .qoi
Root: HKLM; Subkey: "Software\Classes\NeonView.qoi"; ValueType: string; ValueName: ""; ValueData: "Изображение QOI"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.qoi"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение QOI"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.qoi\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.qoi\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.qoi\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.qoi\OpenWithProgids"; ValueType: string; ValueName: "NeonView.qoi"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".qoi"; ValueData: "NeonView.qoi"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".qoi"; ValueData: ""; Tasks: assoc
; .dds
Root: HKLM; Subkey: "Software\Classes\NeonView.dds"; ValueType: string; ValueName: ""; ValueData: "Текстура DDS"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dds"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Текстура DDS"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dds\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dds\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dds\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dds\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.dds\OpenWithProgids"; ValueType: string; ValueName: "NeonView.dds"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".dds"; ValueData: "NeonView.dds"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".dds"; ValueData: ""; Tasks: assoc
; .exr
Root: HKLM; Subkey: "Software\Classes\NeonView.exr"; ValueType: string; ValueName: ""; ValueData: "Изображение OpenEXR"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.exr"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение OpenEXR"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.exr\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.exr\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.exr\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.exr\OpenWithProgids"; ValueType: string; ValueName: "NeonView.exr"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".exr"; ValueData: "NeonView.exr"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".exr"; ValueData: ""; Tasks: assoc
; .hdr
Root: HKLM; Subkey: "Software\Classes\NeonView.hdr"; ValueType: string; ValueName: ""; ValueData: "Изображение HDR"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hdr"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение HDR"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hdr\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hdr\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.hdr\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.hdr\OpenWithProgids"; ValueType: string; ValueName: "NeonView.hdr"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".hdr"; ValueData: "NeonView.hdr"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".hdr"; ValueData: ""; Tasks: assoc
; .pcx
Root: HKLM; Subkey: "Software\Classes\NeonView.pcx"; ValueType: string; ValueName: ""; ValueData: "Изображение PCX"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pcx"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение PCX"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pcx\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pcx\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pcx\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.pcx\OpenWithProgids"; ValueType: string; ValueName: "NeonView.pcx"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pcx"; ValueData: "NeonView.pcx"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".pcx"; ValueData: ""; Tasks: assoc
; .jp2
Root: HKLM; Subkey: "Software\Classes\NeonView.jp2"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG 2000"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jp2"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG 2000"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jp2\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jp2\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jp2\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.jp2\OpenWithProgids"; ValueType: string; ValueName: "NeonView.jp2"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".jp2"; ValueData: "NeonView.jp2"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".jp2"; ValueData: ""; Tasks: assoc
; .j2k
Root: HKLM; Subkey: "Software\Classes\NeonView.j2k"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG 2000"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.j2k"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG 2000"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.j2k\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.j2k\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.j2k\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.j2k\OpenWithProgids"; ValueType: string; ValueName: "NeonView.j2k"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".j2k"; ValueData: "NeonView.j2k"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".j2k"; ValueData: ""; Tasks: assoc
; .jpf
Root: HKLM; Subkey: "Software\Classes\NeonView.jpf"; ValueType: string; ValueName: ""; ValueData: "Изображение JPEG 2000"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpf"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение JPEG 2000"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpf\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpf\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.jpf\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.jpf\OpenWithProgids"; ValueType: string; ValueName: "NeonView.jpf"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".jpf"; ValueData: "NeonView.jpf"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".jpf"; ValueData: ""; Tasks: assoc
; .ppm
Root: HKLM; Subkey: "Software\Classes\NeonView.ppm"; ValueType: string; ValueName: ""; ValueData: "Изображение PPM"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ppm"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение PPM"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ppm\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ppm\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.ppm\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.ppm\OpenWithProgids"; ValueType: string; ValueName: "NeonView.ppm"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".ppm"; ValueData: "NeonView.ppm"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".ppm"; ValueData: ""; Tasks: assoc
; .pgm
Root: HKLM; Subkey: "Software\Classes\NeonView.pgm"; ValueType: string; ValueName: ""; ValueData: "Изображение PGM"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pgm"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение PGM"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pgm\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pgm\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pgm\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.pgm\OpenWithProgids"; ValueType: string; ValueName: "NeonView.pgm"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pgm"; ValueData: "NeonView.pgm"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".pgm"; ValueData: ""; Tasks: assoc
; .pbm
Root: HKLM; Subkey: "Software\Classes\NeonView.pbm"; ValueType: string; ValueName: ""; ValueData: "Изображение PBM"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pbm"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение PBM"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pbm\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pbm\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pbm\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.pbm\OpenWithProgids"; ValueType: string; ValueName: "NeonView.pbm"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pbm"; ValueData: "NeonView.pbm"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".pbm"; ValueData: ""; Tasks: assoc
; .pnm
Root: HKLM; Subkey: "Software\Classes\NeonView.pnm"; ValueType: string; ValueName: ""; ValueData: "Изображение PNM"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pnm"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение PNM"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pnm\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pnm\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pnm\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.pnm\OpenWithProgids"; ValueType: string; ValueName: "NeonView.pnm"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pnm"; ValueData: "NeonView.pnm"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".pnm"; ValueData: ""; Tasks: assoc
; .pam
Root: HKLM; Subkey: "Software\Classes\NeonView.pam"; ValueType: string; ValueName: ""; ValueData: "Изображение PAM"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pam"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Изображение PAM"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pam\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pam\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pam\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.pam\OpenWithProgids"; ValueType: string; ValueName: "NeonView.pam"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pam"; ValueData: "NeonView.pam"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".pam"; ValueData: ""; Tasks: assoc
; .xcf
Root: HKLM; Subkey: "Software\Classes\NeonView.xcf"; ValueType: string; ValueName: ""; ValueData: "Документ GIMP"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.xcf"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Документ GIMP"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.xcf\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.xcf\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.xcf\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.xcf\OpenWithProgids"; ValueType: string; ValueName: "NeonView.xcf"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".xcf"; ValueData: "NeonView.xcf"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".xcf"; ValueData: ""; Tasks: assoc
; .dng
Root: HKLM; Subkey: "Software\Classes\NeonView.dng"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок DNG"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dng"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок DNG"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dng\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dng\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dng\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dng\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.dng\OpenWithProgids"; ValueType: string; ValueName: "NeonView.dng"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".dng"; ValueData: "NeonView.dng"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".dng"; ValueData: ""; Tasks: assoc
; .cr2
Root: HKLM; Subkey: "Software\Classes\NeonView.cr2"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок CR2"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr2"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок CR2"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr2\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr2\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr2\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr2\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.cr2\OpenWithProgids"; ValueType: string; ValueName: "NeonView.cr2"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".cr2"; ValueData: "NeonView.cr2"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".cr2"; ValueData: ""; Tasks: assoc
; .cr3
Root: HKLM; Subkey: "Software\Classes\NeonView.cr3"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок CR3"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr3"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок CR3"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr3\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr3\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr3\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.cr3\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.cr3\OpenWithProgids"; ValueType: string; ValueName: "NeonView.cr3"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".cr3"; ValueData: "NeonView.cr3"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".cr3"; ValueData: ""; Tasks: assoc
; .crw
Root: HKLM; Subkey: "Software\Classes\NeonView.crw"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок CRW"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.crw"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок CRW"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.crw\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.crw\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.crw\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.crw\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.crw\OpenWithProgids"; ValueType: string; ValueName: "NeonView.crw"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".crw"; ValueData: "NeonView.crw"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".crw"; ValueData: ""; Tasks: assoc
; .nef
Root: HKLM; Subkey: "Software\Classes\NeonView.nef"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок NEF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nef"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок NEF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nef\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nef\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nef\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nef\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.nef\OpenWithProgids"; ValueType: string; ValueName: "NeonView.nef"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".nef"; ValueData: "NeonView.nef"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".nef"; ValueData: ""; Tasks: assoc
; .nrw
Root: HKLM; Subkey: "Software\Classes\NeonView.nrw"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок NRW"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nrw"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок NRW"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nrw\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nrw\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nrw\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.nrw\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.nrw\OpenWithProgids"; ValueType: string; ValueName: "NeonView.nrw"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".nrw"; ValueData: "NeonView.nrw"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".nrw"; ValueData: ""; Tasks: assoc
; .arw
Root: HKLM; Subkey: "Software\Classes\NeonView.arw"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок ARW"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.arw"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок ARW"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.arw\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.arw\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.arw\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.arw\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.arw\OpenWithProgids"; ValueType: string; ValueName: "NeonView.arw"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".arw"; ValueData: "NeonView.arw"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".arw"; ValueData: ""; Tasks: assoc
; .srf
Root: HKLM; Subkey: "Software\Classes\NeonView.srf"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок SRF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srf"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок SRF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srf\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srf\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srf\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.srf\OpenWithProgids"; ValueType: string; ValueName: "NeonView.srf"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".srf"; ValueData: "NeonView.srf"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".srf"; ValueData: ""; Tasks: assoc
; .sr2
Root: HKLM; Subkey: "Software\Classes\NeonView.sr2"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок SR2"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.sr2"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок SR2"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.sr2\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.sr2\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.sr2\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.sr2\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.sr2\OpenWithProgids"; ValueType: string; ValueName: "NeonView.sr2"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".sr2"; ValueData: "NeonView.sr2"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".sr2"; ValueData: ""; Tasks: assoc
; .orf
Root: HKLM; Subkey: "Software\Classes\NeonView.orf"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок ORF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.orf"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок ORF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.orf\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.orf\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.orf\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.orf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.orf\OpenWithProgids"; ValueType: string; ValueName: "NeonView.orf"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".orf"; ValueData: "NeonView.orf"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".orf"; ValueData: ""; Tasks: assoc
; .rw2
Root: HKLM; Subkey: "Software\Classes\NeonView.rw2"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок RW2"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rw2"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок RW2"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rw2\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rw2\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rw2\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rw2\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.rw2\OpenWithProgids"; ValueType: string; ValueName: "NeonView.rw2"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".rw2"; ValueData: "NeonView.rw2"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".rw2"; ValueData: ""; Tasks: assoc
; .raf
Root: HKLM; Subkey: "Software\Classes\NeonView.raf"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок RAF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.raf"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок RAF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.raf\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.raf\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.raf\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.raf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.raf\OpenWithProgids"; ValueType: string; ValueName: "NeonView.raf"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".raf"; ValueData: "NeonView.raf"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".raf"; ValueData: ""; Tasks: assoc
; .pef
Root: HKLM; Subkey: "Software\Classes\NeonView.pef"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок PEF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pef"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок PEF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pef\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pef\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pef\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.pef\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.pef\OpenWithProgids"; ValueType: string; ValueName: "NeonView.pef"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pef"; ValueData: "NeonView.pef"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".pef"; ValueData: ""; Tasks: assoc
; .srw
Root: HKLM; Subkey: "Software\Classes\NeonView.srw"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок SRW"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srw"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок SRW"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srw\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srw\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srw\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.srw\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.srw\OpenWithProgids"; ValueType: string; ValueName: "NeonView.srw"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".srw"; ValueData: "NeonView.srw"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".srw"; ValueData: ""; Tasks: assoc
; .x3f
Root: HKLM; Subkey: "Software\Classes\NeonView.x3f"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок X3F"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.x3f"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок X3F"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.x3f\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.x3f\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.x3f\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.x3f\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.x3f\OpenWithProgids"; ValueType: string; ValueName: "NeonView.x3f"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".x3f"; ValueData: "NeonView.x3f"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".x3f"; ValueData: ""; Tasks: assoc
; .3fr
Root: HKLM; Subkey: "Software\Classes\NeonView.3fr"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок 3FR"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.3fr"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок 3FR"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.3fr\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.3fr\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.3fr\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.3fr\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.3fr\OpenWithProgids"; ValueType: string; ValueName: "NeonView.3fr"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".3fr"; ValueData: "NeonView.3fr"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".3fr"; ValueData: ""; Tasks: assoc
; .mef
Root: HKLM; Subkey: "Software\Classes\NeonView.mef"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок MEF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mef"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок MEF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mef\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mef\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mef\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mef\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.mef\OpenWithProgids"; ValueType: string; ValueName: "NeonView.mef"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".mef"; ValueData: "NeonView.mef"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".mef"; ValueData: ""; Tasks: assoc
; .mos
Root: HKLM; Subkey: "Software\Classes\NeonView.mos"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок MOS"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mos"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок MOS"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mos\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mos\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mos\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.mos\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.mos\OpenWithProgids"; ValueType: string; ValueName: "NeonView.mos"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".mos"; ValueData: "NeonView.mos"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".mos"; ValueData: ""; Tasks: assoc
; .erf
Root: HKLM; Subkey: "Software\Classes\NeonView.erf"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок ERF"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.erf"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок ERF"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.erf\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.erf\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.erf\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.erf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.erf\OpenWithProgids"; ValueType: string; ValueName: "NeonView.erf"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".erf"; ValueData: "NeonView.erf"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".erf"; ValueData: ""; Tasks: assoc
; .kdc
Root: HKLM; Subkey: "Software\Classes\NeonView.kdc"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок KDC"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.kdc"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок KDC"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.kdc\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.kdc\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.kdc\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.kdc\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.kdc\OpenWithProgids"; ValueType: string; ValueName: "NeonView.kdc"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".kdc"; ValueData: "NeonView.kdc"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".kdc"; ValueData: ""; Tasks: assoc
; .dcr
Root: HKLM; Subkey: "Software\Classes\NeonView.dcr"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок DCR"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dcr"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок DCR"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dcr\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dcr\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dcr\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.dcr\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.dcr\OpenWithProgids"; ValueType: string; ValueName: "NeonView.dcr"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".dcr"; ValueData: "NeonView.dcr"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".dcr"; ValueData: ""; Tasks: assoc
; .rwl
Root: HKLM; Subkey: "Software\Classes\NeonView.rwl"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок RWL"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rwl"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок RWL"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rwl\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rwl\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rwl\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.rwl\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.rwl\OpenWithProgids"; ValueType: string; ValueName: "NeonView.rwl"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".rwl"; ValueData: "NeonView.rwl"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".rwl"; ValueData: ""; Tasks: assoc
; .iiq
Root: HKLM; Subkey: "Software\Classes\NeonView.iiq"; ValueType: string; ValueName: ""; ValueData: "RAW-снимок IIQ"; Flags: uninsdeletekey; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.iiq"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "RAW-снимок IIQ"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.iiq\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\NeonView.exe,0"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.iiq\shell"; ValueType: string; ValueName: ""; ValueData: "open"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.iiq\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\NeonView.exe"" ""%1"""; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\NeonView.iiq\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{C7657C4A-9F68-40fa-A4DF-96BC08EB3551}"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\.iiq\OpenWithProgids"; ValueType: string; ValueName: "NeonView.iiq"; ValueData: ""; Flags: uninsdeletevalue; Tasks: assoc
Root: HKLM; Subkey: "Software\NeonView\Capabilities\FileAssociations"; ValueType: string; ValueName: ".iiq"; ValueData: "NeonView.iiq"; Tasks: assoc
Root: HKLM; Subkey: "Software\Classes\Applications\NeonView.exe\SupportedTypes"; ValueType: string; ValueName: ".iiq"; ValueData: ""; Tasks: assoc

[Run]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""NeonView - block outbound"""; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""NeonView - block inbound"""; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""NeonView - block outbound"" dir=out action=block program=""{app}\NeonView.exe"" enable=yes profile=any"; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""NeonView - block inbound"" dir=in action=block program=""{app}\NeonView.exe"" enable=yes profile=any"; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{app}\NeonView.exe"; Description: "Запустить NeonView"; Flags: nowait postinstall skipifsilent
Filename: "ms-settings:defaultapps"; Description: "Открыть «Приложения по умолчанию», чтобы выбрать NeonView"; Flags: shellexec postinstall skipifsilent unchecked nowait

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""NeonView - block outbound"""; Flags: runhidden; RunOnceId: "DelFwOut"
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""NeonView - block inbound"""; Flags: runhidden; RunOnceId: "DelFwIn"

[UninstallDelete]
Type: filesandordirs; Name: "{localappdata}\NeonView\Temp"
