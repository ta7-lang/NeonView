using System;
using System.IO;
using System.Runtime.InteropServices;

namespace NeonView.Security
{
    /// <summary>
    /// Защита процесса: запрет поиска DLL в текущей папке (DLL hijacking),
    /// запрет загрузки DLL с сетевых ресурсов и из папок с низким уровнем целостности,
    /// отключение устаревших точек внедрения (AppInit_DLLs, Winsock LSP и т.п.).
    /// </summary>
    public static class SecurityHardening
    {
        public static bool DllDirectoryHardened { get; private set; }
        public static bool ImageLoadPolicy { get; private set; }
        public static bool ExtensionPointPolicy { get; private set; }

        private const int ProcessExtensionPointDisablePolicy = 6;
        private const int ProcessImageLoadPolicy = 10;

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool SetDllDirectoryW(string lpPathName);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetProcessMitigationPolicy(int policy, ref uint lpBuffer, UIntPtr dwLength);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetSearchPathMode(uint flags);

        public static void Apply()
        {
            try
            {
                // Пустая строка убирает текущую папку из пути поиска DLL.
                DllDirectoryHardened = SetDllDirectoryW(string.Empty);
            }
            catch { }

            try
            {
                // BASE_SEARCH_PATH_ENABLE_SAFE_SEARCHMODE | BASE_SEARCH_PATH_PERMANENT
                SetSearchPathMode(0x00000001 | 0x00008000);
            }
            catch { }

            try
            {
                // NoRemoteImages (1) | NoLowMandatoryLabelImages (2)
                uint flags = 0x1 | 0x2;
                ImageLoadPolicy = SetProcessMitigationPolicy(ProcessImageLoadPolicy, ref flags, (UIntPtr)sizeof(uint));
            }
            catch { }

            try
            {
                uint flags = 0x1; // DisableExtensionPoints
                ExtensionPointPolicy = SetProcessMitigationPolicy(ProcessExtensionPointDisablePolicy, ref flags, (UIntPtr)sizeof(uint));
            }
            catch { }

            try
            {
                // Рабочая папка процесса — папка программы (а не папка с фото).
                Environment.CurrentDirectory = AppContext.BaseDirectory;
            }
            catch { }
        }
    }

    /// <summary>Чтение метки «Mark of the Web» (файл скачан из интернета).</summary>
    public static class Motw
    {
        public sealed class Info
        {
            public int ZoneId;
            public string HostUrl;
            public string ReferrerUrl;
            public string ZoneName => ZoneId switch
            {
                0 => "Этот компьютер",
                1 => "Локальная сеть",
                2 => "Надёжные сайты",
                3 => "Интернет",
                4 => "Опасные сайты",
                _ => "Неизвестно"
            };
            public bool IsInternet => ZoneId >= 3;
        }

        public static Info Read(string path)
        {
            try
            {
                string ads = path + ":Zone.Identifier";
                using var fs = new FileStream(ads, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                if (fs.Length > 16 * 1024) return null;
                using var sr = new StreamReader(fs);
                var info = new Info { ZoneId = -1 };
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = line.Substring(0, eq).Trim();
                    string v = line.Substring(eq + 1).Trim();
                    if (k.Equals("ZoneId", StringComparison.OrdinalIgnoreCase) && int.TryParse(v, out int z)) info.ZoneId = z;
                    else if (k.Equals("HostUrl", StringComparison.OrdinalIgnoreCase)) info.HostUrl = Trunc(v);
                    else if (k.Equals("ReferrerUrl", StringComparison.OrdinalIgnoreCase)) info.ReferrerUrl = Trunc(v);
                }
                return info.ZoneId >= 0 ? info : null;
            }
            catch
            {
                return null;
            }
        }

        private static string Trunc(string s) => s.Length > 300 ? s.Substring(0, 300) + "…" : s;
    }
}
