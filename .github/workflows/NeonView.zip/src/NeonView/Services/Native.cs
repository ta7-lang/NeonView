using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace NeonView.Services
{
    public static class Native
    {
        [DllImport("shlwapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
        private static extern int StrCmpLogicalW(string x, string y);

        public sealed class NaturalComparer : IComparer<string>
        {
            public static readonly NaturalComparer Instance = new NaturalComparer();
            public int Compare(string x, string y)
            {
                try { return StrCmpLogicalW(x ?? "", y ?? ""); }
                catch { return string.Compare(x, y, StringComparison.CurrentCultureIgnoreCase); }
            }
        }

        // ---- Корзина ----
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct SHFILEOPSTRUCT
        {
            public IntPtr hwnd;
            public uint wFunc;
            public string pFrom;
            public string pTo;
            public ushort fFlags;
            public int fAnyOperationsAborted;
            public IntPtr hNameMappings;
            public string lpszProgressTitle;
        }

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        private static extern int SHFileOperation(ref SHFILEOPSTRUCT op);

        private const uint FO_DELETE = 3;
        private const ushort FOF_SILENT = 0x0004, FOF_NOCONFIRMATION = 0x0010, FOF_ALLOWUNDO = 0x0040, FOF_NOERRORUI = 0x0400, FOF_WANTNUKEWARNING = 0x4000;

        /// <summary>Перемещает файл в Корзину (с возможностью восстановления).</summary>
        public static bool MoveToRecycleBin(string path, IntPtr owner)
        {
            var op = new SHFILEOPSTRUCT
            {
                hwnd = owner,
                wFunc = FO_DELETE,
                pFrom = path + "\0\0",
                fFlags = (ushort)(FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI | FOF_WANTNUKEWARNING)
            };
            int r = SHFileOperation(ref op);
            return r == 0 && op.fAnyOperationsAborted == 0 && !File.Exists(path);
        }

        // ---- Обновление ассоциаций / значков Проводника ----
        [DllImport("shell32.dll")]
        private static extern void SHChangeNotify(int wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);

        public static void NotifyAssociationsChanged()
        {
            try { SHChangeNotify(0x08000000 /*SHCNE_ASSOCCHANGED*/, 0x1000 /*SHCNF_FLUSH*/, IntPtr.Zero, IntPtr.Zero); } catch { }
        }

        // ---- Монитор ----
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT { public int Left, Top, Right, Bottom; }

        [StructLayout(LayoutKind.Sequential)]
        private struct MONITORINFO
        {
            public int cbSize;
            public RECT rcMonitor;
            public RECT rcWork;
            public uint dwFlags;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);

        [DllImport("user32.dll")]
        private static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO lpmi);

        public static RECT? GetMonitorBounds(IntPtr hwnd)
        {
            try
            {
                var mon = MonitorFromWindow(hwnd, 2 /*MONITOR_DEFAULTTONEAREST*/);
                var mi = new MONITORINFO { cbSize = Marshal.SizeOf<MONITORINFO>() };
                if (GetMonitorInfo(mon, ref mi)) return mi.rcMonitor;
            }
            catch { }
            return null;
        }

        // ---- Тёмный заголовок для системных окон ----
        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        public static void SetDarkTitleBar(IntPtr hwnd, bool dark)
        {
            try { int v = dark ? 1 : 0; DwmSetWindowAttribute(hwnd, 20, ref v, sizeof(int)); } catch { }
        }
    }

    /// <summary>Проверка установленных кодеков Windows (WIC), от которых зависят эскизы в Проводнике.</summary>
    public static class CodecChecker
    {
        public sealed class CodecStatus
        {
            public string Name { get; set; }
            public string Extensions { get; set; }
            public bool Installed { get; set; }
            public string StoreId { get; set; }
            public string Hint { get; set; }
            public string StatusText => Installed ? "✔ установлен" : "✖ не найден";
        }

        public static HashSet<string> GetWicDecoderExtensions()
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            const string catPath = @"CLSID\{7ED96837-96F0-4812-B211-F13C24117ED3}\Instance";
            try
            {
                using var cat = Registry.ClassesRoot.OpenSubKey(catPath);
                if (cat == null) return set;
                foreach (var sub in cat.GetSubKeyNames())
                {
                    try
                    {
                        using var inst = cat.OpenSubKey(sub);
                        string clsid = inst?.GetValue("CLSID") as string ?? sub;
                        using var cls = Registry.ClassesRoot.OpenSubKey(@"CLSID\" + clsid);
                        if (cls?.GetValue("FileExtensions") is string exts)
                            foreach (var e in exts.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
                                set.Add(e.Trim().TrimStart('.'));
                    }
                    catch { }
                }
            }
            catch { }
            return set;
        }

        public static List<CodecStatus> Check()
        {
            var ext = GetWicDecoderExtensions();
            bool Has(params string[] e) => e.Any(x => ext.Contains(x));
            return new List<CodecStatus>
            {
                new CodecStatus { Name = "JPEG, PNG, BMP, GIF, TIFF, ICO", Extensions = "встроены в Windows", Installed = Has("jpg", "jpeg") && Has("png") },
                new CodecStatus { Name = "Расширения для изображений HEIF", Extensions = ".heic .heif", Installed = Has("heic", "heif"), StoreId = "9PMMSR1CGPWG",
                    Hint = "Для HEIC с iPhone дополнительно нужны «Расширения видео HEVC»." },
                new CodecStatus { Name = "Расширения видео HEVC", Extensions = "нужны для HEIC", Installed = Has("heic") && HevcPresent(), StoreId = "9N4WGH0Z6VHQ",
                    Hint = "Бесплатная версия «от производителя устройства»." },
                new CodecStatus { Name = "Расширение AV1 / AVIF", Extensions = ".avif", Installed = Has("avif"), StoreId = "9MVZQVXJBQ9V" },
                new CodecStatus { Name = "Расширения изображений WebP", Extensions = ".webp", Installed = Has("webp"), StoreId = "9PG2DK419DRG" },
                new CodecStatus { Name = "Расширение RAW-изображений", Extensions = ".dng .cr2 .nef .arw …", Installed = Has("dng", "cr2", "nef", "arw"), StoreId = "9NCTDW2W1BH8" },
                new CodecStatus { Name = "Расширение JPEG XL", Extensions = ".jxl", Installed = Has("jxl"), StoreId = null,
                    Hint = "Доступно в новых сборках Windows 11." },
            };
        }

        private static bool HevcPresent()
        {
            try
            {
                using var k = Registry.ClassesRoot.OpenSubKey(@"Extensions\ContractId\Windows.BackgroundTasks\PackageId");
                if (k != null && k.GetSubKeyNames().Any(n => n.StartsWith("Microsoft.HEVCVideoExtension", StringComparison.OrdinalIgnoreCase))) return true;
            }
            catch { }
            try
            {
                using var k = Registry.ClassesRoot.OpenSubKey(@"Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\PackageRepository\Packages");
                if (k != null && k.GetSubKeyNames().Any(n => n.StartsWith("Microsoft.HEVCVideoExtension", StringComparison.OrdinalIgnoreCase))) return true;
            }
            catch { }
            return false;
        }
    }

    /// <summary>Обслуживание системного кэша эскизов Проводника (thumbcache_*.db).</summary>
    public static class ExplorerThumbCache
    {
        public static string Folder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Microsoft\Windows\Explorer");

        public static long Size()
        {
            long s = 0;
            try
            {
                foreach (var f in new DirectoryInfo(Folder).EnumerateFiles("thumbcache_*.db")) { try { s += f.Length; } catch { } }
            }
            catch { }
            return s;
        }

        /// <summary>Удаляет незаблокированные файлы кэша. Возвращает (удалено файлов, освобождено байт, заблокировано файлов).</summary>
        public static (int deleted, long freed, int locked) Clear()
        {
            int del = 0, locked = 0; long freed = 0;
            try
            {
                foreach (var f in new DirectoryInfo(Folder).EnumerateFiles("thumbcache_*.db"))
                {
                    try { long l = f.Length; f.Delete(); del++; freed += l; }
                    catch { locked++; }
                }
            }
            catch { }
            return (del, freed, locked);
        }
    }
}
