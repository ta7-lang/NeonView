using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;

namespace NeonView.Theming
{
    public sealed class ThemePalette
    {
        public string Id { get; init; }
        public string Name { get; init; }
        public string Description { get; init; }
        public string Bg { get; init; }
        public string Viewer { get; init; }
        public string Panel { get; init; }
        public string Panel2 { get; init; }
        public string Line { get; init; }
        public string Text { get; init; }
        public string SubText { get; init; }
        public string Accent { get; init; }
        public string Accent2 { get; init; }
        public bool IsLight { get; init; }

        // Для превью в настройках
        public Brush PreviewBrush => new LinearGradientBrush(ThemeManager.ParseColor(Accent), ThemeManager.ParseColor(Accent2), 0);
        public Brush PreviewBg => new SolidColorBrush(ThemeManager.ParseColor(Bg));
        public Brush PreviewPanel => new SolidColorBrush(ThemeManager.ParseColor(Panel));
        public Brush PreviewText => new SolidColorBrush(ThemeManager.ParseColor(Text));
    }

    public static class ThemeManager
    {
        public static readonly IReadOnlyList<ThemePalette> Themes = new List<ThemePalette>
        {
            new ThemePalette { Id = "cyber",   Name = "Киберпанк",        Description = "Бирюзовый и маджента на глубоком тёмном",
                Bg = "#0B0B16", Viewer = "#07070F", Panel = "#13132A", Panel2 = "#1C1C3A", Line = "#2A2A52", Text = "#EAF6FF", SubText = "#8F97C8", Accent = "#00F0FF", Accent2 = "#FF2BD6" },
            new ThemePalette { Id = "synth",   Name = "Синтвейв",          Description = "Розовый закат 80-х",
                Bg = "#120821", Viewer = "#0B0416", Panel = "#1E0F33", Panel2 = "#2A1648", Line = "#3D2262", Text = "#FFEFFB", SubText = "#B99AD1", Accent = "#FF3CAC", Accent2 = "#FF9E2C" },
            new ThemePalette { Id = "matrix",  Name = "Матрица",           Description = "Кислотно-зелёный терминал",
                Bg = "#050A06", Viewer = "#020503", Panel = "#0C1A10", Panel2 = "#122717", Line = "#1C3D24", Text = "#E2FFE8", SubText = "#7FB68C", Accent = "#39FF14", Accent2 = "#00FFA3" },
            new ThemePalette { Id = "aurora",  Name = "Северное сияние",   Description = "Мятный и фиолетовый",
                Bg = "#071318", Viewer = "#040B0E", Panel = "#0E2129", Panel2 = "#143039", Line = "#1F4552", Text = "#E6FFFA", SubText = "#86B5B0", Accent = "#3DFFC5", Accent2 = "#8A5CFF" },
            new ThemePalette { Id = "lava",    Name = "Лава",              Description = "Огненно-оранжевый и жёлтый",
                Bg = "#140707", Viewer = "#0B0303", Panel = "#241010", Panel2 = "#341717", Line = "#4E2222", Text = "#FFF1EA", SubText = "#C99A8A", Accent = "#FF4D1C", Accent2 = "#FFD200" },
            new ThemePalette { Id = "ice",     Name = "Лёд",               Description = "Холодный голубой и лавандовый",
                Bg = "#0A1220", Viewer = "#060B15", Panel = "#12203A", Panel2 = "#1A2C4E", Line = "#27406B", Text = "#EEF6FF", SubText = "#93A9CC", Accent = "#7FDBFF", Accent2 = "#B794FF" },
            new ThemePalette { Id = "midnight",Name = "Полночь",           Description = "Минимализм: чёрный и холодный свет",
                Bg = "#000000", Viewer = "#000000", Panel = "#0E0E10", Panel2 = "#18181C", Line = "#2A2A30", Text = "#F2F2F7", SubText = "#8E8E99", Accent = "#A0A8FF", Accent2 = "#FF7AD9" },
            new ThemePalette { Id = "light",   Name = "Неон-лайт",         Description = "Светлая тема с яркими акцентами", IsLight = true,
                Bg = "#EEF0F8", Viewer = "#E2E5F0", Panel = "#FFFFFF", Panel2 = "#F1F2F9", Line = "#D2D6E6", Text = "#15151F", SubText = "#5E6380", Accent = "#0077FF", Accent2 = "#FF00A8" },
        };

        public static ThemePalette Current { get; private set; } = Themes[0];

        public static void Apply(AppSettings s)
        {
            var app = Application.Current;
            if (app == null) return;
            var p = Themes.FirstOrDefault(t => t.Id == s.Theme) ?? Themes[0];
            Current = p;

            Color accent = ParseColor(p.Accent), accent2 = ParseColor(p.Accent2);
            if (s.UseCustomAccent)
            {
                accent = FromHsv(s.CustomHue1, p.IsLight ? 1.0 : 0.85, p.IsLight ? 0.85 : 1.0);
                accent2 = FromHsv(s.CustomHue2, p.IsLight ? 1.0 : 0.85, p.IsLight ? 0.85 : 1.0);
            }

            var r = app.Resources;
            Set(r, "BgBrush", ParseColor(p.Bg));
            Set(r, "PanelBrush", ParseColor(p.Panel));
            Set(r, "Panel2Brush", ParseColor(p.Panel2));
            Set(r, "LineBrush", ParseColor(p.Line));
            Set(r, "TextBrush", ParseColor(p.Text));
            Set(r, "SubTextBrush", ParseColor(p.SubText));
            Set(r, "AccentBrush", accent);
            Set(r, "Accent2Brush", accent2);
            Set(r, "OnAccentBrush", p.IsLight ? Colors.White : ParseColor("#07070F"));
            Set(r, "AccentSoftBrush", Color.FromArgb(0x33, accent.R, accent.G, accent.B));
            Set(r, "OverlayBrush", p.IsLight ? Color.FromArgb(0xE6, 0xFF, 0xFF, 0xFF) : Color.FromArgb(0xD9, 0x0A, 0x0A, 0x16));
            Set(r, "DangerBrush", ParseColor("#FF4D6D"));
            Set(r, "WarnBrush", ParseColor("#FFC24D"));
            Set(r, "OkBrush", ParseColor("#3DFF9A"));

            var grad = new LinearGradientBrush(accent, accent2, new Point(0, 0), new Point(1, 1));
            grad.Freeze();
            r["AccentGradient"] = grad;

            r["AccentColor"] = accent;
            r["Accent2Color"] = accent2;
            r["GlowColor"] = accent;
            r["GlowRadius"] = s.GlowStrength;
            r["GlowOpacity"] = s.GlowStrength <= 0.5 ? 0.0 : 0.9;
            r["Radius"] = new CornerRadius(s.CornerRadius);
            r["RadiusSmall"] = new CornerRadius(Math.Max(0, s.CornerRadius * 0.66));
            r["RadiusPill"] = new CornerRadius(Math.Max(0, s.CornerRadius * 1.8));

            r["ViewerBrush"] = BuildViewerBrush(s.ViewerBackground, p);
        }

        private static Brush BuildViewerBrush(string mode, ThemePalette p)
        {
            Brush b;
            switch (mode)
            {
                case "black": b = new SolidColorBrush(Colors.Black); break;
                case "gray": b = new SolidColorBrush(ParseColor("#3A3A40")); break;
                case "white": b = new SolidColorBrush(Colors.White); break;
                case "checker": b = CreateChecker(); break;
                default: b = new SolidColorBrush(ParseColor(p.Viewer)); break;
            }
            b.Freeze();
            return b;
        }

        public static Brush CreateChecker()
        {
            var light = new SolidColorBrush(ParseColor("#3C3C46"));
            var dark = new SolidColorBrush(ParseColor("#2A2A32"));
            var group = new DrawingGroup();
            group.Children.Add(new GeometryDrawing(dark, null, new RectangleGeometry(new Rect(0, 0, 16, 16))));
            var g = new GeometryGroup();
            g.Children.Add(new RectangleGeometry(new Rect(0, 0, 8, 8)));
            g.Children.Add(new RectangleGeometry(new Rect(8, 8, 8, 8)));
            group.Children.Add(new GeometryDrawing(light, null, g));
            var brush = new DrawingBrush(group)
            {
                TileMode = TileMode.Tile,
                Viewport = new Rect(0, 0, 16, 16),
                ViewportUnits = BrushMappingMode.Absolute,
                Stretch = Stretch.None
            };
            brush.Freeze();
            return brush;
        }

        private static void Set(ResourceDictionary r, string key, Color c)
        {
            var b = new SolidColorBrush(c);
            b.Freeze();
            r[key] = b;
        }

        public static Color ParseColor(string hex)
        {
            try { return (Color)ColorConverter.ConvertFromString(hex); }
            catch { return Colors.Magenta; }
        }

        public static Color FromHsv(double h, double s, double v)
        {
            h = ((h % 360) + 360) % 360;
            double c = v * s, x = c * (1 - Math.Abs((h / 60) % 2 - 1)), m = v - c;
            double r, g, b;
            if (h < 60) { r = c; g = x; b = 0; }
            else if (h < 120) { r = x; g = c; b = 0; }
            else if (h < 180) { r = 0; g = c; b = x; }
            else if (h < 240) { r = 0; g = x; b = c; }
            else if (h < 300) { r = x; g = 0; b = c; }
            else { r = c; g = 0; b = x; }
            return Color.FromRgb((byte)Math.Round((r + m) * 255), (byte)Math.Round((g + m) * 255), (byte)Math.Round((b + m) * 255));
        }

        public static string ToHex(Color c) => $"#{c.R:X2}{c.G:X2}{c.B:X2}";
    }
}
