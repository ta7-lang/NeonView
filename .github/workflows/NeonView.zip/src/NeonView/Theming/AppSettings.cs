using System;
using System.IO;
using System.Text.Json;

namespace NeonView.Theming
{
    public sealed class AppSettings
    {
        // Оформление
        public string Theme { get; set; } = "cyber";
        public bool UseCustomAccent { get; set; } = false;
        public double CustomHue1 { get; set; } = 185;
        public double CustomHue2 { get; set; } = 310;
        public double GlowStrength { get; set; } = 18;
        public double CornerRadius { get; set; } = 12;
        public double UiScale { get; set; } = 1.0;
        public string ViewerBackground { get; set; } = "theme"; // theme | black | gray | white | checker
        public bool Animations { get; set; } = true;
        public bool ShowInfoOverlay { get; set; } = true;

        // Просмотр
        public bool ShowThumbnails { get; set; } = true;
        public bool WheelNavigates { get; set; } = false;
        public string SortMode { get; set; } = "name"; // name | date | size | type
        public bool SortDescending { get; set; } = false;
        public bool LoopNavigation { get; set; } = true;
        public double SlideshowSeconds { get; set; } = 4;
        public bool PixelZoom { get; set; } = true;
        public bool UpscaleSmall { get; set; } = false;
        public bool Preload { get; set; } = true;

        // Редактор
        public int JpegQuality { get; set; } = 92;
        public bool StripMetadataOnSave { get; set; } = false;
        public int PreviewMaxSide { get; set; } = 2048;

        // Безопасность
        public int MaxFileSizeMb { get; set; } = 1024;
        public bool WarnInternetFiles { get; set; } = true;
        public bool ConfirmDelete { get; set; } = true;

        // Окно
        public double WinLeft { get; set; } = double.NaN;
        public double WinTop { get; set; } = double.NaN;
        public double WinWidth { get; set; } = 1280;
        public double WinHeight { get; set; } = 820;
        public bool WinMaximized { get; set; } = false;

        public long MaxFileBytes => (long)Math.Clamp(MaxFileSizeMb, 16, 2000) * 1024L * 1024L;

        public void Normalize()
        {
            GlowStrength = Math.Clamp(Finite(GlowStrength, 18), 0, 40);
            CornerRadius = Math.Clamp(Finite(CornerRadius, 12), 0, 24);
            UiScale = Math.Clamp(Finite(UiScale, 1), 0.8, 1.6);
            CustomHue1 = Math.Clamp(Finite(CustomHue1, 185), 0, 360);
            CustomHue2 = Math.Clamp(Finite(CustomHue2, 310), 0, 360);
            SlideshowSeconds = Math.Clamp(Finite(SlideshowSeconds, 4), 1, 60);
            JpegQuality = Math.Clamp(JpegQuality, 40, 100);
            PreviewMaxSide = Math.Clamp(PreviewMaxSide, 1024, 4096);
            MaxFileSizeMb = Math.Clamp(MaxFileSizeMb, 16, 2000);
            WinWidth = Math.Clamp(Finite(WinWidth, 1280), 720, 10000);
            WinHeight = Math.Clamp(Finite(WinHeight, 820), 480, 10000);
            if (string.IsNullOrWhiteSpace(Theme) || Theme.Length > 32) Theme = "cyber";
            if (ViewerBackground is not ("theme" or "black" or "gray" or "white" or "checker")) ViewerBackground = "theme";
            if (SortMode is not ("name" or "date" or "size" or "type")) SortMode = "name";
        }

        private static double Finite(double v, double def) => double.IsFinite(v) ? v : def;
    }

    public static class SettingsStore
    {
        private static string FilePath => Path.Combine(AppPaths.SettingsDir, "settings.json");

        public static AppSettings Load()
        {
            try
            {
                var fi = new FileInfo(FilePath);
                // защита от подмены: огромный/битый файл настроек игнорируется
                if (fi.Exists && fi.Length < 64 * 1024)
                {
                    var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath),
                        new JsonSerializerOptions { AllowTrailingCommas = true, MaxDepth = 8, NumberHandling = System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals });
                    if (s != null) { s.Normalize(); return s; }
                }
            }
            catch { }
            var d = new AppSettings();
            d.Normalize();
            return d;
        }

        public static void Save(AppSettings s)
        {
            Directory.CreateDirectory(AppPaths.SettingsDir);
            var json = JsonSerializer.Serialize(s, new JsonSerializerOptions
            {
                WriteIndented = true,
                NumberHandling = System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals
            });
            var tmp = FilePath + ".tmp";
            File.WriteAllText(tmp, json);
            File.Move(tmp, FilePath, true);
        }
    }
}
