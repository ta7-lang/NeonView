using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NeonView.Imaging;
using NeonView.Metadata;
using NeonView.Security;
using NeonView.Services;
using NeonView.Theming;

namespace NeonView.Views
{
    public partial class SettingsWindow : Window
    {
        private bool _loading = true;
        private AppSettings S => App.Settings;
        public bool SortChanged { get; private set; }

        private static readonly (string Id, string Name)[] ViewerBgs =
        {
            ("theme", "Как в теме"), ("black", "Чёрный"), ("gray", "Нейтральный серый"), ("white", "Белый"), ("checker", "Шахматка (видна прозрачность)")
        };
        private static readonly (string Id, string Name)[] Sorts =
        {
            ("name", "По имени (как в Проводнике)"), ("date", "По дате изменения"), ("size", "По размеру"), ("type", "По типу файла")
        };
        private static readonly int[] PreviewSizes = { 1024, 1600, 2048, 3072, 4096 };

        public sealed class Protection
        {
            public string Icon { get; set; }
            public Brush Color { get; set; }
            public string Title { get; set; }
            public string Text { get; set; }
        }

        public SettingsWindow()
        {
            InitializeComponent();
            ThemeList.ItemsSource = ThemeManager.Themes;
            CbViewerBg.ItemsSource = ViewerBgs.Select(x => x.Name).ToList();
            CbSort.ItemsSource = Sorts.Select(x => x.Name).ToList();
            CbPreview.ItemsSource = PreviewSizes.Select(x => x == 2048 ? $"{x} пикс. (рекомендуется)" : $"{x} пикс.").ToList();
            LoadValues();
            Wire();
            FillSystem();
            FillAbout();
            _loading = false;
            Closed += (s, e) => { try { SettingsStore.Save(S); } catch { } };
        }

        private void LoadValues()
        {
            _loading = true;
            ChkCustom.IsChecked = S.UseCustomAccent;
            SlHue1.Value = S.CustomHue1; SlHue2.Value = S.CustomHue2;
            SlGlow.Value = S.GlowStrength; SlRadius.Value = S.CornerRadius; SlScale.Value = S.UiScale;
            CbViewerBg.SelectedIndex = Math.Max(0, Array.FindIndex(ViewerBgs, x => x.Id == S.ViewerBackground));
            ChkAnim.IsChecked = S.Animations; ChkInfo.IsChecked = S.ShowInfoOverlay;
            ChkThumbs.IsChecked = S.ShowThumbnails; ChkWheel.IsChecked = S.WheelNavigates; ChkLoop.IsChecked = S.LoopNavigation;
            ChkPixel.IsChecked = S.PixelZoom; ChkUpscale.IsChecked = S.UpscaleSmall; ChkPreload.IsChecked = S.Preload;
            CbSort.SelectedIndex = Math.Max(0, Array.FindIndex(Sorts, x => x.Id == S.SortMode));
            ChkDesc.IsChecked = S.SortDescending;
            SlSlide.Value = S.SlideshowSeconds;
            SlQuality.Value = S.JpegQuality; ChkStrip.IsChecked = S.StripMetadataOnSave;
            int pi = Array.IndexOf(PreviewSizes, S.PreviewMaxSide);
            CbPreview.SelectedIndex = pi >= 0 ? pi : 2;
            SlMaxSize.Value = S.MaxFileSizeMb; ChkMotw.IsChecked = S.WarnInternetFiles; ChkConfirmDel.IsChecked = S.ConfirmDelete;
            UpdateLabels();
        }

        private void Wire()
        {
            RoutedEventHandler chk = (s, e) => Commit();
            foreach (var c in new[] { ChkCustom, ChkAnim, ChkInfo, ChkThumbs, ChkWheel, ChkLoop, ChkPixel, ChkUpscale, ChkPreload, ChkDesc, ChkStrip, ChkMotw, ChkConfirmDel })
            {
                c.Checked += chk;
                c.Unchecked += chk;
            }
            foreach (var sl in new[] { SlHue1, SlHue2, SlGlow, SlRadius, SlScale, SlSlide, SlQuality, SlMaxSize })
                sl.ValueChanged += (s, e) => Commit();
            foreach (var cb in new[] { CbViewerBg, CbSort, CbPreview })
                cb.SelectionChanged += (s, e) => Commit();
        }

        private void Commit()
        {
            if (_loading) return;
            string oldSort = S.SortMode; bool oldDesc = S.SortDescending;
            S.UseCustomAccent = ChkCustom.IsChecked == true;
            S.CustomHue1 = SlHue1.Value; S.CustomHue2 = SlHue2.Value;
            S.GlowStrength = SlGlow.Value; S.CornerRadius = SlRadius.Value; S.UiScale = Math.Round(SlScale.Value, 2);
            if (CbViewerBg.SelectedIndex >= 0) S.ViewerBackground = ViewerBgs[CbViewerBg.SelectedIndex].Id;
            S.Animations = ChkAnim.IsChecked == true; S.ShowInfoOverlay = ChkInfo.IsChecked == true;
            S.ShowThumbnails = ChkThumbs.IsChecked == true; S.WheelNavigates = ChkWheel.IsChecked == true; S.LoopNavigation = ChkLoop.IsChecked == true;
            S.PixelZoom = ChkPixel.IsChecked == true; S.UpscaleSmall = ChkUpscale.IsChecked == true; S.Preload = ChkPreload.IsChecked == true;
            if (CbSort.SelectedIndex >= 0) S.SortMode = Sorts[CbSort.SelectedIndex].Id;
            S.SortDescending = ChkDesc.IsChecked == true;
            S.SlideshowSeconds = SlSlide.Value;
            S.JpegQuality = (int)SlQuality.Value; S.StripMetadataOnSave = ChkStrip.IsChecked == true;
            if (CbPreview.SelectedIndex >= 0) S.PreviewMaxSide = PreviewSizes[CbPreview.SelectedIndex];
            S.MaxFileSizeMb = (int)SlMaxSize.Value; S.WarnInternetFiles = ChkMotw.IsChecked == true; S.ConfirmDelete = ChkConfirmDel.IsChecked == true;
            S.Normalize();
            if (oldSort != S.SortMode || oldDesc != S.SortDescending) SortChanged = true;
            UpdateLabels();
            App.RaiseSettingsChanged();
        }

        private void UpdateLabels()
        {
            var p = ThemeManager.Themes.FirstOrDefault(t => t.Id == S.Theme) ?? ThemeManager.Themes[0];
            ThemeCurrent.Text = "Текущая тема: " + p.Name + " — " + p.Description;
            Swatch1.Background = new SolidColorBrush(ThemeManager.FromHsv(SlHue1.Value, 0.85, 1));
            Swatch2.Background = new SolidColorBrush(ThemeManager.FromHsv(SlHue2.Value, 0.85, 1));
            SlHue1.IsEnabled = SlHue2.IsEnabled = ChkCustom.IsChecked == true;
            GlowVal.Text = SlGlow.Value <= 0 ? "выкл." : $"{SlGlow.Value:0}";
            RadiusVal.Text = $"{SlRadius.Value:0} пикс.";
            ScaleVal.Text = $"{SlScale.Value * 100:0}%";
            SlideVal.Text = $"{SlSlide.Value:0.#} с";
            QualityVal.Text = $"{SlQuality.Value:0}";
            MaxSizeVal.Text = $"{SlMaxSize.Value:0} МБ";
        }

        private void Theme_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button b && b.Tag is string id)
            {
                S.Theme = id;
                if (S.UseCustomAccent) { S.UseCustomAccent = false; _loading = true; ChkCustom.IsChecked = false; _loading = false; }
                UpdateLabels();
                App.RaiseSettingsChanged();
            }
        }

        private void ResetAll_Click(object sender, RoutedEventArgs e)
        {
            if (!NeonDialog.Confirm(this, "Сбросить настройки?", "Все параметры оформления, просмотра и редактора вернутся к значениям по умолчанию.", "Сбросить", "Отмена")) return;
            var d = new AppSettings();
            d.Normalize();
            foreach (var prop in typeof(AppSettings).GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(pp => pp.CanWrite && !pp.Name.StartsWith("Win")))
                prop.SetValue(S, prop.GetValue(d));
            SortChanged = true;
            LoadValues();
            _loading = false;
            App.RaiseSettingsChanged();
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        // ---------------- Система ----------------

        private void FillSystem()
        {
            CodecList.ItemsSource = CodecChecker.Check();
            UpdateCacheInfo();

            var ok = (Brush)FindResource("OkBrush");
            var warn = (Brush)FindResource("WarnBrush");
            ProtectionList.ItemsSource = new List<Protection>
            {
                new Protection { Icon = "✔", Color = ok, Title = "Определение формата по содержимому", Text = "Исполняемые файлы, скрипты, HTML, PDF и архивы под видом изображений блокируются." },
                new Protection { Icon = MagickBootstrap.Initialized ? "✔" : "✖", Color = MagickBootstrap.Initialized ? ok : warn, Title = "Строгая политика декодера", Text = "Сеть, внешние программы, PostScript/PDF/XPS, текстовые и «скриптовые» кодеки, чтение путей через @ — запрещены; память и размеры ограничены." },
                new Protection { Icon = "✔", Color = ok, Title = "Обезвреживание SVG", Text = "Скрипты, обработчики событий, внешние ссылки, встроенный HTML, DTD и сущности удаляются до отрисовки." },
                new Protection { Icon = SecurityHardening.DllDirectoryHardened ? "✔" : "•", Color = SecurityHardening.DllDirectoryHardened ? ok : warn, Title = "Защита от подмены DLL", Text = "Текущая папка исключена из поиска библиотек." },
                new Protection { Icon = SecurityHardening.ImageLoadPolicy ? "✔" : "•", Color = SecurityHardening.ImageLoadPolicy ? ok : warn, Title = "Запрет загрузки кода по сети и из ненадёжных мест", Text = "Политика Windows ProcessImageLoadPolicy." },
                new Protection { Icon = SecurityHardening.ExtensionPointPolicy ? "✔" : "•", Color = SecurityHardening.ExtensionPointPolicy ? ok : warn, Title = "Отключены устаревшие точки внедрения", Text = "AppInit_DLLs, Winsock LSP и глобальные хуки не загружаются в процесс." },
                new Protection { Icon = "✔", Color = ok, Title = "Только чтение и атомарная запись", Text = "Оригиналы не изменяются без явной команды; сохранение идёт через временный файл с проверкой." },
                new Protection { Icon = "✔", Color = ok, Title = "Полностью офлайн", Text = "В программе нет сетевого кода; установщик может дополнительно запретить ей доступ в сеть брандмауэром." },
                new Protection { Icon = "✔", Color = ok, Title = "Без кэша на диске", Text = "Миниатюры — только в памяти, временные файлы удаляются при запуске и выходе." },
            };
        }

        private void UpdateCacheInfo()
        {
            long temp = MagickBootstrap.TempSize();
            long explorer = ExplorerThumbCache.Size();
            CacheInfo.Text = $"Временные файлы NeonView: {MetadataService.FormatSize(temp)}  ·  Миниатюр в памяти: {ThumbnailService.LoadedCount} (лимит {ThumbnailService.Capacity})  ·  Кэш эскизов Windows (общий для системы): {MetadataService.FormatSize(explorer)}";
        }

        private static void ShellOpen(string uri)
        {
            try { Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); } catch { }
        }

        private void DefaultApps_Click(object sender, RoutedEventArgs e) =>
            ShellOpen("ms-settings:defaultapps?registeredAppMachine=NeonView");

        private void RefreshAssoc_Click(object sender, RoutedEventArgs e)
        {
            Native.NotifyAssociationsChanged();
            NeonDialog.Info(this, "Готово", "Проводник получил сигнал обновить значки и эскизы файлов.", "✔");
        }

        private void Store_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button b && b.Tag is string id && !string.IsNullOrEmpty(id))
            {
                if (NeonDialog.Confirm(this, "Открыть Microsoft Store?", "Будет открыто приложение Microsoft Store на странице расширения. Сам NeonView в интернет не обращается.", "Открыть", "Отмена", "ℹ"))
                    ShellOpen("ms-windows-store://pdp/?ProductId=" + id);
            }
            else NeonDialog.Info(this, "Нет ссылки", "Это расширение входит в состав новых версий Windows — обновите систему через Центр обновления.");
        }

        private void RecheckCodecs_Click(object sender, RoutedEventArgs e) => CodecList.ItemsSource = CodecChecker.Check();

        private void CleanTemp_Click(object sender, RoutedEventArgs e)
        {
            long freed = MagickBootstrap.CleanTemp();
            UpdateCacheInfo();
            NeonDialog.Info(this, "Очищено", $"Освобождено: {MetadataService.FormatSize(freed)}.", "✔");
        }

        private void CleanMemory_Click(object sender, RoutedEventArgs e)
        {
            ThumbnailService.ClearMemory();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            UpdateCacheInfo();
        }

        private void CleanExplorer_Click(object sender, RoutedEventArgs e)
        {
            if (!NeonDialog.Confirm(this, "Сбросить кэш эскизов Windows?",
                "Windows заново создаст эскизы при открытии папок. Часть файлов кэша может быть занята Проводником — для полной очистки можно перезапустить Проводник (панель задач на секунду исчезнет).",
                "Сбросить", "Отмена", "🧹")) return;
            var (del, freed, locked) = ExplorerThumbCache.Clear();
            UpdateCacheInfo();
            if (locked > 0)
            {
                int r = NeonDialog.Show(this, "Часть кэша занята",
                    $"Удалено файлов: {del} ({MetadataService.FormatSize(freed)}). Занято Проводником: {locked}. Перезапустить Проводник и удалить остальное?",
                    "?", 0, "Перезапустить Проводник", "Не нужно");
                if (r == 0) RestartExplorerAndClear();
            }
            else NeonDialog.Info(this, "Готово", $"Удалено файлов: {del}, освобождено {MetadataService.FormatSize(freed)}.", "✔");
            Native.NotifyAssociationsChanged();
        }

        private void RestartExplorerAndClear()
        {
            try
            {
                string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                foreach (var p in Process.GetProcessesByName("explorer"))
                {
                    try { p.Kill(); p.WaitForExit(5000); } catch { }
                    finally { p.Dispose(); }
                }
                System.Threading.Thread.Sleep(800);
                var (del, freed, locked) = ExplorerThumbCache.Clear();
                Process.Start(new ProcessStartInfo(Path.Combine(win, "explorer.exe")) { UseShellExecute = false });
                UpdateCacheInfo();
                NeonDialog.Info(this, "Готово", $"Проводник перезапущен. Дополнительно удалено файлов: {del}.", "✔");
            }
            catch (Exception ex)
            {
                NeonDialog.Info(this, "Ошибка", ex.Message, "⚠");
            }
        }

        // ---------------- О программе ----------------

        private void FillAbout()
        {
            var v = Assembly.GetExecutingAssembly().GetName().Version;
            AboutVersion.Text = $"Версия {v?.ToString(3) ?? "1.0.0"} · .NET {Environment.Version} · {(Environment.Is64BitProcess ? "x64" : "x86")}";
            Shortcuts.Text =
                "←/→, PgUp/PgDn, Пробел   — предыдущее / следующее\n" +
                "Home / End              — первое / последнее\n" +
                "Колесо / Ctrl+колесо    — масштаб\n" +
                "+ / − / 0 / 1           — больше / меньше / вписать / 100%\n" +
                "Двойной щелчок          — вписать ↔ 100%\n" +
                "R / Shift+R             — повернуть для просмотра\n" +
                "F11 / Esc               — полный экран / выход\n" +
                "F5                      — слайд-шоу\n" +
                "E                       — редактор\n" +
                "Ctrl+Z / Ctrl+Y         — отменить / повторить правку\n" +
                "Ctrl+S / Ctrl+Shift+S   — сохранить копию / сохранить как\n" +
                "I или Alt+Enter         — свойства и метаданные\n" +
                "F2                      — переименовать\n" +
                "Del                     — в корзину\n" +
                "Ctrl+C / Ctrl+Shift+C   — копировать изображение / путь\n" +
                "Ctrl+O / Ctrl+P / Ctrl+, — открыть / печать / настройки";
            DecoderInfo.Text = $"ImageMagick: {MagickBootstrap.Version}\nПодключённые библиотеки: {MagickBootstrap.Delegates}";
        }

        private void OpenLog_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(CrashLog.LogPath))
            {
                try { Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "notepad.exe"), "\"" + CrashLog.LogPath + "\"") { UseShellExecute = false }); }
                catch { }
            }
            else NeonDialog.Info(this, "Журнал пуст", "Ошибок не зарегистрировано.", "✔");
        }
    }
}
