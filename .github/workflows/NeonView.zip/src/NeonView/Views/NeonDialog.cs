using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shell;

namespace NeonView.Views
{
    /// <summary>Диалоговое окно в стиле приложения.</summary>
    public sealed class NeonDialog : Window
    {
        private int _result = -1;
        private TextBox _input;

        private NeonDialog(Window owner, string title, string message, string icon, string[] buttons, int accentIndex, string inputText)
        {
            Owner = owner;
            WindowStartupLocation = owner != null ? WindowStartupLocation.CenterOwner : WindowStartupLocation.CenterScreen;
            SizeToContent = SizeToContent.Height;
            Width = 460;
            ResizeMode = ResizeMode.NoResize;
            ShowInTaskbar = false;
            Title = title;
            SetResourceReference(BackgroundProperty, "PanelBrush");
            SetResourceReference(ForegroundProperty, "TextBrush");
            FontFamily = (FontFamily)Application.Current.FindResource("UiFont");
            UseLayoutRounding = true;
            WindowChrome.SetWindowChrome(this, new WindowChrome { CaptionHeight = 36, GlassFrameThickness = new Thickness(0), ResizeBorderThickness = new Thickness(0), UseAeroCaptionButtons = false });

            var outer = new Border { BorderThickness = new Thickness(1) };
            outer.SetResourceReference(Border.BorderBrushProperty, "AccentBrush");

            var root = new StackPanel { Margin = new Thickness(24, 18, 24, 20) };
            var head = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            if (!string.IsNullOrEmpty(icon))
            {
                var ic = new TextBlock { Text = icon, FontSize = 22, Margin = new Thickness(0, 0, 12, 0), VerticalAlignment = VerticalAlignment.Center, FontFamily = (FontFamily)Application.Current.FindResource("SymbolFont") };
                ic.SetResourceReference(TextBlock.ForegroundProperty, "AccentBrush");
                head.Children.Add(ic);
            }
            var tt = new TextBlock { Text = title, FontSize = 17, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap, MaxWidth = 360 };
            head.Children.Add(tt);
            root.Children.Add(head);

            if (!string.IsNullOrEmpty(message))
            {
                var msg = new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap, FontSize = 13, LineHeight = 19 };
                msg.SetResourceReference(TextBlock.ForegroundProperty, "SubTextBrush");
                root.Children.Add(msg);
            }

            if (inputText != null)
            {
                _input = new TextBox { Text = inputText, Margin = new Thickness(0, 14, 0, 0) };
                root.Children.Add(_input);
                Loaded += (s, e) =>
                {
                    _input.Focus();
                    int dot = _input.Text.LastIndexOf('.');
                    if (dot > 0) _input.Select(0, dot); else _input.SelectAll();
                };
            }

            var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 20, 0, 0) };
            for (int i = 0; i < buttons.Length; i++)
            {
                int idx = i;
                var b = new Button { Content = buttons[i], Margin = new Thickness(8, 0, 0, 0), MinWidth = 96 };
                b.Style = (Style)Application.Current.FindResource(i == accentIndex ? "AccentButton" : "NeonButton");
                if (i == accentIndex) b.IsDefault = true;
                if (i == buttons.Length - 1 && buttons.Length > 1) b.IsCancel = true;
                b.Click += (s, e) => { _result = idx; DialogResult = true; };
                bar.Children.Add(b);
            }
            root.Children.Add(bar);
            outer.Child = root;
            Content = outer;

            PreviewKeyDown += (s, e) =>
            {
                if (e.Key == Key.Escape) { _result = -1; DialogResult = false; e.Handled = true; }
            };
        }

        public static int Show(Window owner, string title, string message, string icon, int accentIndex, params string[] buttons)
        {
            var d = new NeonDialog(owner, title, message, icon, buttons, accentIndex, null);
            try { d.ShowDialog(); } catch { }
            return d._result;
        }

        public static bool Confirm(Window owner, string title, string message, string yes = "Да", string no = "Отмена", string icon = "⚠") =>
            Show(owner, title, message, icon, 0, yes, no) == 0;

        public static void Info(Window owner, string title, string message, string icon = "ℹ") =>
            Show(owner, title, message, icon, 0, "OK");

        public static string Prompt(Window owner, string title, string message, string initial)
        {
            var d = new NeonDialog(owner, title, message, "✎", new[] { "Готово", "Отмена" }, 0, initial ?? "");
            try { d.ShowDialog(); } catch { }
            return d._result == 0 ? d._input.Text : null;
        }
    }
}
