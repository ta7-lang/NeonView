using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NeonView.Imaging;
using NeonView.Metadata;
using IOPath = System.IO.Path;

namespace NeonView.Views
{
    public partial class PropertiesWindow : Window
    {
        private readonly string _path;
        private readonly DecodedImage _decoded;
        private readonly BitmapSource _preview;
        private MetadataReport _report;
        private List<PropRow> _all = new List<PropRow>();

        public event Action MetadataChanged;
        public event Action<string> FileCreated;

        public PropertiesWindow(string path, DecodedImage decoded, BitmapSource preview)
        {
            _path = path;
            _decoded = decoded;
            _preview = preview ?? decoded?.Bitmap;
            InitializeComponent();
            FileName.Text = IOPath.GetFileName(path);
            Thumb.Source = _preview;
            EdRating.ItemsSource = new[] { "Без оценки", "★", "★★", "★★★", "★★★★", "★★★★★" };
            EdRating.SelectedIndex = 0;
            Loaded += async (s, e) => await LoadAsync();
            PreviewKeyDown += (s, e) => { if (e.Key == Key.Escape) Close(); };
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private void AddChip(string text, string brushKey = "SubTextBrush")
        {
            var tb = new TextBlock { Text = text, FontSize = 12 };
            tb.SetResourceReference(TextBlock.ForegroundProperty, brushKey);
            var b = new Border { Child = tb, Margin = new Thickness(0, 0, 6, 6) };
            b.Style = (Style)FindResource("Chip");
            Chips.Children.Add(b);
        }

        private async Task LoadAsync()
        {
            Busy.Visibility = Visibility.Visible;
            BusyText.Text = "Чтение метаданных…";
            try
            {
                long max = App.Settings.MaxFileBytes;
                _report = await Task.Run(() => MetadataService.Read(_path, _decoded, max));
            }
            catch (Exception ex)
            {
                BusyText.Text = "Не удалось прочитать файл: " + ex.Message;
                return;
            }
            Fill();
            DrawHistogram();
            Busy.Visibility = Visibility.Collapsed;
        }

        private void Fill()
        {
            var r = _report;
            Chips.Children.Clear();
            if (r.Detect?.DisplayName != null) AddChip(r.Detect.DisplayName, "AccentBrush");
            if (_decoded != null)
            {
                AddChip($"{_decoded.OriginalWidth} × {_decoded.OriginalHeight}");
                AddChip($"{_decoded.Megapixels:0.#} МП");
            }
            try { AddChip(MetadataService.FormatSize(new FileInfo(_path).Length)); } catch { }
            if (r.Latitude.HasValue) AddChip("📍 GPS", "WarnBrush");
            if (r.Detect?.ExtensionMismatch == true) AddChip("⚠ расширение ≠ содержимое", "WarnBrush");

            FileRows.ItemsSource = r.File;
            ImageRows.ItemsSource = r.Image;
            CameraRows.ItemsSource = r.Camera;
            NoCamera.Visibility = r.Camera.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            SecurityRows.ItemsSource = r.Security;

            if (r.Latitude.HasValue && r.Longitude.HasValue)
            {
                GpsText.Text = "📍 " + MetadataService.FormatCoord(r.Latitude.Value, r.Longitude.Value);
                GpsDms.Text = MetadataService.FormatDms(r.Latitude.Value, r.Longitude.Value);
                GpsAlt.Text = r.Altitude.HasValue ? $"Высота: {r.Altitude.Value:0.#} м" : "";
                GpsButtons.Visibility = Visibility.Visible;
            }
            else
            {
                GpsText.Text = "Координат нет";
                GpsDms.Text = "Снимок не содержит геоданных — местоположение съёмки по файлу определить нельзя.";
                GpsAlt.Text = "";
                GpsButtons.Visibility = Visibility.Collapsed;
            }

            _all = r.All;
            ApplyFilter();

            // Редактирование
            var e = r.Editable ?? new EditableMeta();
            EdTitle.Text = e.Title; EdSubject.Text = e.Subject; EdKeywords.Text = e.Keywords; EdComment.Text = e.Comment;
            EdAuthors.Text = e.Authors; EdCopyright.Text = e.Copyright; EdDate.Text = FormatDate(e.DateTaken);
            EdMake.Text = e.CameraMake; EdModel.Text = e.CameraModel;
            EdRating.SelectedIndex = Math.Clamp(e.Rating, 0, 5);

            bool can = r.CanEdit;
            EditGrid.IsEnabled = can;
            BtnSaveMeta.IsEnabled = can;
            BtnRemoveGps.IsEnabled = can && r.Latitude.HasValue;
            BtnStrip.IsEnabled = r.Detect != null && !r.Detect.Rejected && !r.Detect.IsSvg;
            if (!string.IsNullOrEmpty(r.EditNote))
            {
                EditNote.Text = r.EditNote;
                EditNoteBox.Visibility = Visibility.Visible;
            }
            else EditNoteBox.Visibility = Visibility.Collapsed;
        }

        private static string FormatDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out var dt) ||
                DateTime.TryParse(s, CultureInfo.CurrentCulture, DateTimeStyles.AllowWhiteSpaces, out dt))
                return dt.ToString("dd.MM.yyyy HH:mm:ss");
            return s;
        }

        private void ApplyFilter()
        {
            string q = SearchBox.Text?.Trim() ?? "";
            IEnumerable<PropRow> rows = _all;
            if (q.Length > 0)
                rows = _all.Where(x =>
                    (x.Group?.IndexOf(q, StringComparison.CurrentCultureIgnoreCase) ?? -1) >= 0 ||
                    (x.Name?.IndexOf(q, StringComparison.CurrentCultureIgnoreCase) ?? -1) >= 0 ||
                    (x.Value?.IndexOf(q, StringComparison.CurrentCultureIgnoreCase) ?? -1) >= 0);
            var list = rows.ToList();
            AllList.ItemsSource = list;
            AllCount.Text = q.Length > 0 ? $"найдено {list.Count} из {_all.Count}" : $"{_all.Count} полей";
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilter();

        private void AllList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (AllList.SelectedItem is PropRow r)
            {
                try { Clipboard.SetText($"{r.Group} / {r.Name}: {r.Value}"); } catch { }
            }
        }

        private void CopyGps_Click(object sender, RoutedEventArgs e)
        {
            if (_report?.Latitude == null || _report.Longitude == null) return;
            try { Clipboard.SetText(MetadataService.FormatCoord(_report.Latitude.Value, _report.Longitude.Value)); } catch { }
        }

        private async void SaveMeta_Click(object sender, RoutedEventArgs e)
        {
            var m = new EditableMeta
            {
                Title = EdTitle.Text, Subject = EdSubject.Text, Keywords = EdKeywords.Text, Comment = EdComment.Text,
                Authors = EdAuthors.Text, Copyright = EdCopyright.Text, DateTaken = EdDate.Text,
                CameraMake = EdMake.Text, CameraModel = EdModel.Text, Rating = Math.Max(0, EdRating.SelectedIndex)
            };
            await RunWrite("Сохранение метаданных…", () => MetadataWriter.Save(_path, m), changed: true);
        }

        private async void RemoveGps_Click(object sender, RoutedEventArgs e)
        {
            if (_report == null || !_report.CanEdit)
            {
                NeonDialog.Info(this, "Недоступно", "Удаление GPS «на месте» возможно для JPEG и TIFF. Для других форматов используйте «Создать копию без метаданных».");
                return;
            }
            if (!NeonDialog.Confirm(this, "Удалить геоданные?", "Координаты места съёмки будут удалены из файла. Отменить это действие нельзя.", "Удалить", "Отмена", "📍")) return;
            await RunWrite("Удаление GPS…", () => MetadataWriter.RemoveGps(_path), changed: true);
        }

        private async void Strip_Click(object sender, RoutedEventArgs e)
        {
            string newPath = null;
            await RunWrite("Создание очищенной копии…", () =>
            {
                string msg = MetadataWriter.StripToCopy(_path, out var p);
                newPath = p;
                return msg + "\n\nНовый файл: " + IOPath.GetFileName(p);
            }, changed: false);
            if (newPath != null) FileCreated?.Invoke(newPath);
        }

        private async Task RunWrite(string busy, Func<string> work, bool changed)
        {
            Busy.Visibility = Visibility.Visible;
            BusyText.Text = busy;
            string msg;
            bool ok;
            try
            {
                msg = await Task.Run(work);
                ok = true;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                ok = false;
            }
            Busy.Visibility = Visibility.Collapsed;
            NeonDialog.Info(this, ok ? "Готово" : "Ошибка", msg, ok ? "✔" : "⚠");
            if (ok && changed)
            {
                MetadataChanged?.Invoke();
                await LoadAsync();
            }
        }

        // ---------------- Гистограмма ----------------

        private void DrawHistogram()
        {
            HistCanvas.Children.Clear();
            if (_preview == null) { HistStats.Text = "Нет данных."; return; }
            try
            {
                BitmapSource src = _preview;
                double k = Math.Min(1.0, 640.0 / Math.Max(src.PixelWidth, src.PixelHeight));
                if (k < 1) src = new TransformedBitmap(src, new ScaleTransform(k, k));
                var conv = new FormatConvertedBitmap(src, PixelFormats.Bgra32, null, 0);
                int w = conv.PixelWidth, h = conv.PixelHeight, stride = w * 4;
                var px = new byte[stride * h];
                conv.CopyPixels(px, stride, 0);

                var r = new double[256]; var g = new double[256]; var b = new double[256]; var l = new double[256];
                long n = 0; double sumL = 0; long clipHi = 0, clipLo = 0;
                for (int i = 0; i < px.Length; i += 4)
                {
                    if (px[i + 3] < 8) continue;
                    byte B = px[i], G = px[i + 1], R = px[i + 2];
                    r[R]++; g[G]++; b[B]++;
                    int L = (int)Math.Round(0.2126 * R + 0.7152 * G + 0.0722 * B);
                    l[L]++; sumL += L; n++;
                    if (R >= 254 && G >= 254 && B >= 254) clipHi++;
                    if (R <= 1 && G <= 1 && B <= 1) clipLo++;
                }
                if (n == 0) { HistStats.Text = "Изображение полностью прозрачное."; return; }

                double max = 0;
                for (int i = 1; i < 255; i++) max = Math.Max(max, Math.Max(Math.Max(r[i], g[i]), Math.Max(b[i], l[i])));
                if (max <= 0) max = 1;

                HistCanvas.Children.Add(MakeArea(r, max, Color.FromArgb(0x70, 0xFF, 0x54, 0x70)));
                HistCanvas.Children.Add(MakeArea(g, max, Color.FromArgb(0x70, 0x3D, 0xFF, 0x9A)));
                HistCanvas.Children.Add(MakeArea(b, max, Color.FromArgb(0x70, 0x4D, 0xA3, 0xFF)));
                var line = MakeLine(l, max);
                line.SetResourceReference(Shape.StrokeProperty, "TextBrush");
                HistCanvas.Children.Add(line);

                double mean = sumL / n;
                HistStats.Text = $"Средняя яркость: {mean:0} из 255 ({mean / 2.55:0}%) · Пересвет: {clipHi * 100.0 / n:0.##}% · Провалы в чёрное: {clipLo * 100.0 / n:0.##}% · Проанализировано пикселей: {n:N0}";
            }
            catch (Exception ex)
            {
                HistStats.Text = "Не удалось построить гистограмму: " + ex.Message;
            }
        }

        private static Polygon MakeArea(double[] hist, double max, Color c)
        {
            var poly = new Polygon { Fill = new SolidColorBrush(c), StrokeThickness = 0 };
            poly.Points.Add(new Point(0, 100));
            for (int i = 0; i < 256; i++) poly.Points.Add(new Point(i, 100 - Math.Min(100, hist[i] / max * 100)));
            poly.Points.Add(new Point(255, 100));
            return poly;
        }

        private static Polyline MakeLine(double[] hist, double max)
        {
            var pl = new Polyline { StrokeThickness = 0.8 };
            for (int i = 0; i < 256; i++) pl.Points.Add(new Point(i, 100 - Math.Min(100, hist[i] / max * 100)));
            return pl;
        }
    }
}
