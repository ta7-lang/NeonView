using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using ImageMagick;

namespace NeonView.Imaging
{
    public class ImageLoadException : Exception
    {
        public bool Security { get; }
        public ImageLoadException(string message, bool security = false) : base(message) { Security = security; }
    }

    public sealed class AnimFrame
    {
        public BitmapSource Bitmap;
        public int DelayMs;
    }

    public sealed class DecodedImage
    {
        public string Path;
        public BitmapSource Bitmap;
        public List<AnimFrame> Frames;
        public int OriginalWidth;
        public int OriginalHeight;
        public long FileSize;
        public DateTime LastWrite;
        public DetectResult Detect;
        public bool Downscaled;
        public int SvgRemovedItems;
        public readonly List<KeyValuePair<string, string>> Info = new List<KeyValuePair<string, string>>();

        public bool IsAnimated => Frames != null && Frames.Count > 1;
        public string FormatName => Detect?.DisplayName ?? "?";
        public double Megapixels => OriginalWidth * (double)OriginalHeight / 1_000_000.0;
    }

    /// <summary>Безопасная загрузка и декодирование изображений.</summary>
    public static class ImageLoader
    {
        public const int MaxAnimationFrames = 400;
        public const long MaxAnimationPixels = 400L * 1000 * 1000; // суммарно по всем кадрам

        public static byte[] ReadFileSafe(string path, long maxBytes)
        {
            FileInfo fi;
            try { fi = new FileInfo(path); }
            catch { throw new ImageLoadException("Недопустимый путь к файлу."); }
            if (!fi.Exists) throw new ImageLoadException("Файл не найден или был перемещён.");
            if (fi.Length == 0) throw new ImageLoadException("Файл пустой.");
            if (fi.Length > maxBytes)
                throw new ImageLoadException($"Файл слишком большой ({fi.Length / 1024 / 1024} МБ). Предел безопасности — {maxBytes / 1024 / 1024} МБ (меняется в настройках).", true);

            using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16, FileOptions.SequentialScan);
            long len = fs.Length;
            if (len > maxBytes || len > int.MaxValue - 64) throw new ImageLoadException("Файл слишком большой.", true);
            var buf = new byte[len];
            int read = 0;
            while (read < len)
            {
                int n = fs.Read(buf, read, (int)Math.Min(len - read, 1 << 22));
                if (n <= 0) break;
                read += n;
            }
            if (read != len) Array.Resize(ref buf, read);
            return buf;
        }

        private static MagickFormat ParseFormat(string name)
        {
            if (!string.IsNullOrEmpty(name) && Enum.TryParse(typeof(MagickFormat), name, true, out object f))
                return (MagickFormat)f;
            return MagickFormat.Unknown;
        }

        /// <summary>Чтение файла, определение формата, обезвреживание SVG и подготовка настроек декодера.</summary>
        private static (byte[] data, MagickReadSettings settings, DetectResult det, int svgRemoved) Prepare(string path, long maxBytes)
        {
            byte[] data = ReadFileSafe(path, maxBytes);
            var det = FormatDetector.Detect(data, path);
            if (det.Rejected) throw new ImageLoadException(det.Reason, det.RejectedForSecurity);

            int svgRemoved = 0;
            if (det.IsSvg)
            {
                if (det.IsGzip) data = SvgSanitizer.Gunzip(data);
                data = SvgSanitizer.Sanitize(data);
                svgRemoved = SvgSanitizer.LastRemovedCount;
            }

            var fmt = ParseFormat(det.MagickFormat);
            // Любой RAW можно декодировать через libraw (кодек DNG)
            if (fmt == MagickFormat.Unknown && det.IsRaw) fmt = ParseFormat("Dng");
            if (fmt == MagickFormat.Unknown)
                throw new ImageLoadException($"Формат {det.DisplayName} не поддерживается этой сборкой декодера.");

            var settings = new MagickReadSettings { Format = fmt };
            if (det.IsSvg)
            {
                settings.BackgroundColor = MagickColors.Transparent;
                settings.Density = new Density(96);
            }
            return (data, settings, det, svgRemoved);
        }

        /// <summary>Приведение к стандартному виду: ориентация по EXIF, цветовой профиль → sRGB.</summary>
        private static void Normalize(IMagickImage<ushort> img)
        {
            try { img.AutoOrient(); } catch { }
            try
            {
                var profile = img.GetColorProfile();
                if (img.ColorSpace == ColorSpace.CMYK)
                {
                    if (profile == null) img.TransformColorSpace(ColorProfile.USWebCoatedSWOP, ColorProfile.SRGB);
                    else img.TransformColorSpace(ColorProfile.SRGB);
                }
                else if (profile != null && img.ColorSpace != ColorSpace.Gray)
                {
                    img.TransformColorSpace(ColorProfile.SRGB);
                }
            }
            catch { }
            try
            {
                if (img.ColorSpace != ColorSpace.sRGB && img.ColorSpace != ColorSpace.RGB)
                    img.ColorSpace = ColorSpace.sRGB;
            }
            catch { }
        }

        private static void Collect(DecodedImage d, IMagickImage<ushort> img, int frames)
        {
            void Add(string k, string v) { if (!string.IsNullOrWhiteSpace(v)) d.Info.Add(new KeyValuePair<string, string>(k, v)); }
            try
            {
                Add("Размер", $"{img.Width} × {img.Height} пикс.");
                Add("Мегапиксели", $"{img.Width * (double)img.Height / 1e6:0.##} МП");
                int g = Gcd(img.Width, img.Height);
                if (g > 0) Add("Соотношение сторон", $"{img.Width / g}:{img.Height / g}  ({img.Width / (double)Math.Max(1, img.Height):0.###})");
                Add("Глубина цвета", $"{img.Depth} бит на канал");
                Add("Цветовое пространство", img.ColorSpace.ToString());
                Add("Тип", img.ColorType.ToString());
                Add("Прозрачность (альфа)", img.HasAlpha ? "Есть" : "Нет");
                try { Add("Сжатие", img.Compression.ToString()); } catch { }
                try
                {
                    var den = img.Density;
                    if (den != null && den.X > 0) Add("Разрешение (DPI)", $"{den.X:0.#} × {den.Y:0.#} ({den.Units})");
                }
                catch { }
                try { Add("Чересстрочность", img.Interlace.ToString()); } catch { }
                try
                {
                    var cp = img.GetColorProfile();
                    Add("ICC-профиль", cp != null ? (cp.Description ?? cp.Model ?? "встроен") : "нет (считается sRGB)");
                }
                catch { }
                try { Add("Ориентация (EXIF)", img.Orientation.ToString()); } catch { }
                if (frames > 1) Add("Кадров", frames.ToString());
                try { Add("Гамма", img.Gamma.ToString("0.####")); } catch { }
            }
            catch { }
        }

        private static int Gcd(int a, int b) { while (b != 0) { int t = a % b; a = b; b = t; } return a; }

        /// <summary>Основное декодирование для просмотра.</summary>
        public static DecodedImage Decode(string path, int maxSide, long maxBytes, CancellationToken ct)
        {
            var (data, settings, det, svgRemoved) = Prepare(path, maxBytes);
            ct.ThrowIfCancellationRequested();

            var fi = new FileInfo(path);
            var d = new DecodedImage
            {
                Path = path,
                Detect = det,
                FileSize = fi.Exists ? fi.Length : data.Length,
                LastWrite = fi.Exists ? fi.LastWriteTimeUtc : DateTime.MinValue,
                SvgRemovedItems = svgRemoved
            };

            try
            {
                if (det.MaybeAnimated)
                {
                    var animSettings = new MagickReadSettings { Format = settings.Format, FrameCount = MaxAnimationFrames };
                    using var coll = new MagickImageCollection(data, animSettings);
                    if (coll.Count > 1)
                    {
                        coll.Coalesce();
                        var first = coll[0];
                        d.OriginalWidth = first.Width;
                        d.OriginalHeight = first.Height;
                        Collect(d, first, coll.Count);

                        long totalPixels = (long)first.Width * first.Height * coll.Count;
                        int animMax = Math.Min(maxSide, 1920);
                        if (totalPixels > MaxAnimationPixels) animMax = Math.Min(animMax, 800);

                        d.Frames = new List<AnimFrame>(coll.Count);
                        foreach (var frame in coll)
                        {
                            ct.ThrowIfCancellationRequested();
                            Normalize(frame);
                            Fit(frame, animMax, false);
                            int ticks = frame.AnimationTicksPerSecond > 0 ? frame.AnimationTicksPerSecond : 100;
                            int delay = (int)(frame.AnimationDelay * 1000L / ticks);
                            if (delay < 20) delay = 100; // как в браузерах
                            d.Frames.Add(new AnimFrame { Bitmap = ToBitmapSource(frame), DelayMs = delay });
                        }
                        d.Bitmap = d.Frames[0].Bitmap;
                        d.Downscaled = d.Bitmap.PixelWidth < d.OriginalWidth;
                        return d;
                    }
                }

                settings.FrameIndex = 0;
                settings.FrameCount = 1;
                IMagickImage<ushort> img = new MagickImage(data, settings);
                try
                {
                    ct.ThrowIfCancellationRequested();
                    if (det.IsSvg && Math.Max(img.Width, img.Height) < 1600)
                    {
                        // Векторное изображение — перерисовываем крупнее для чёткости
                        double k = Math.Min(10, 2000.0 / Math.Max(1, Math.Max(img.Width, img.Height)));
                        if (k > 1.2)
                        {
                            img.Dispose();
                            settings.Density = new Density(96 * k);
                            img = new MagickImage(data, settings);
                        }
                    }
                    Normalize(img);
                    d.OriginalWidth = img.Width;
                    d.OriginalHeight = img.Height;
                    Collect(d, img, 1);
                    ct.ThrowIfCancellationRequested();
                    d.Downscaled = Fit(img, maxSide, false);
                    d.Bitmap = ToBitmapSource(img);
                }
                finally
                {
                    img.Dispose();
                }
                return d;
            }
            catch (OperationCanceledException) { throw; }
            catch (ImageLoadException) { throw; }
            catch (MagickException mex)
            {
                throw new ImageLoadException(FriendlyMagickError(mex, det));
            }
        }

        /// <summary>Декодирование в объект ImageMagick (для редактора и сохранения).</summary>
        public static IMagickImage<ushort> DecodeMagick(string path, int maxSide, long maxBytes)
        {
            var (data, settings, det, _) = Prepare(path, maxBytes);
            settings.FrameIndex = 0;
            settings.FrameCount = 1;
            try
            {
                IMagickImage<ushort> img = new MagickImage(data, settings);
                if (det.IsSvg && Math.Max(img.Width, img.Height) < 1600)
                {
                    double k = Math.Min(10, 2000.0 / Math.Max(1, Math.Max(img.Width, img.Height)));
                    if (k > 1.2)
                    {
                        img.Dispose();
                        settings.Density = new Density(96 * k);
                        img = new MagickImage(data, settings);
                    }
                }
                Normalize(img);
                Fit(img, maxSide, false);
                return img;
            }
            catch (MagickException mex)
            {
                throw new ImageLoadException(FriendlyMagickError(mex, det));
            }
        }

        /// <summary>Миниатюра (только в памяти, на диск ничего не пишется).</summary>
        public static BitmapSource DecodeThumbnail(string path, int size, long maxBytes)
        {
            var (data, settings, det, _) = Prepare(path, maxBytes);
            settings.FrameIndex = 0;
            settings.FrameCount = 1;
            if (det.IsJpeg)
            {
                // Декодер JPEG сразу уменьшает изображение — в разы быстрее
                try { settings.SetDefine(MagickFormat.Jpeg, "size", $"{size * 2}x{size * 2}"); } catch { }
            }
            using var img = new MagickImage(data, settings);
            try { img.AutoOrient(); } catch { }
            try
            {
                if (img.ColorSpace == ColorSpace.CMYK)
                {
                    if (img.GetColorProfile() == null) img.TransformColorSpace(ColorProfile.USWebCoatedSWOP, ColorProfile.SRGB);
                    else img.TransformColorSpace(ColorProfile.SRGB);
                }
                if (img.ColorSpace != ColorSpace.sRGB && img.ColorSpace != ColorSpace.RGB) img.ColorSpace = ColorSpace.sRGB;
            }
            catch { }
            img.Thumbnail(size, size);
            return ToBitmapSource(img);
        }

        private static bool Fit(IMagickImage<ushort> img, int maxSide, bool thumbnail)
        {
            if (maxSide <= 0) return false;
            int w = img.Width, h = img.Height;
            int longSide = Math.Max(w, h);
            if (longSide <= maxSide) return false;
            double k = maxSide / (double)longSide;
            int nw = Math.Max(1, (int)Math.Round(w * k));
            int nh = Math.Max(1, (int)Math.Round(h * k));
            var g = new MagickGeometry(nw, nh) { IgnoreAspectRatio = true };
            if (thumbnail) img.Thumbnail(g); else img.Resize(g);
            return true;
        }

        public static BitmapSource ToBitmapSource(IMagickImage<ushort> img)
        {
            int w = img.Width, h = img.Height;
            using var pixels = img.GetPixelsUnsafe();
            if (img.HasAlpha)
            {
                byte[] bytes = pixels.ToByteArray(PixelMapping.BGRA);
                var bs = BitmapSource.Create(w, h, 96, 96, PixelFormats.Bgra32, null, bytes, w * 4);
                bs.Freeze();
                return bs;
            }
            else
            {
                byte[] bytes = pixels.ToByteArray(PixelMapping.BGR);
                var bs = BitmapSource.Create(w, h, 96, 96, PixelFormats.Bgr24, null, bytes, w * 3);
                bs.Freeze();
                return bs;
            }
        }

        private static string FriendlyMagickError(MagickException ex, DetectResult det)
        {
            string m = ex.Message ?? "";
            if (m.Contains("not authorized", StringComparison.OrdinalIgnoreCase))
                return "Операция заблокирована политикой безопасности (файл пытался использовать запрещённую функцию).";
            if (m.Contains("width or height exceeds", StringComparison.OrdinalIgnoreCase) || m.Contains("limit", StringComparison.OrdinalIgnoreCase))
                return "Изображение превышает безопасные пределы размеров/памяти (защита от «бомб» декомпрессии).";
            if (m.Contains("no decode delegate", StringComparison.OrdinalIgnoreCase))
                return $"Формат {det?.DisplayName} не поддерживается декодером.";
            if (m.Length > 400) m = m.Substring(0, 400) + "…";
            return $"Не удалось декодировать {det?.DisplayName}: файл повреждён или использует неподдерживаемый вариант формата.\n\n{m}";
        }
    }
}
