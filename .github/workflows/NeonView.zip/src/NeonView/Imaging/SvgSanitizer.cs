using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace NeonView.Imaging
{
    /// <summary>
    /// Обезвреживание SVG перед отрисовкой: удаляются скрипты, обработчики событий,
    /// внешние ссылки (сеть и локальные файлы), встроенный HTML, DTD/сущности (XXE, «billion laughs»),
    /// инструкции xml-stylesheet и CSS-импорты.
    /// </summary>
    public static class SvgSanitizer
    {
        private const int MaxDecompressed = 64 * 1024 * 1024;
        public static int LastRemovedCount { get; private set; }

        private static readonly HashSet<string> ForbiddenElements = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "script", "foreignObject", "iframe", "object", "embed", "audio", "video", "canvas", "handler", "listener",
            "set", "animate", "animateMotion", "animateTransform", "animateColor", "discard", "html", "body", "link",
            "meta", "base", "form", "input", "button", "textarea", "frame", "frameset", "applet"
        };

        private static readonly Regex UrlRegex = new Regex(@"url\s*\(\s*(?!['""]?\s*#)[^)]*\)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex ImportRegex = new Regex(@"@import[^;]*;?", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex DataImageRegex = new Regex(@"^data:image/(png|jpe?g|gif|webp|bmp);base64,", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public static byte[] Gunzip(byte[] data)
        {
            using var input = new MemoryStream(data);
            using var gz = new GZipStream(input, CompressionMode.Decompress);
            using var output = new MemoryStream();
            var buf = new byte[81920];
            int n;
            while ((n = gz.Read(buf, 0, buf.Length)) > 0)
            {
                output.Write(buf, 0, n);
                if (output.Length > MaxDecompressed) throw new ImageLoadException("Сжатый SVG слишком велик после распаковки (возможная «zip-бомба»).", true);
            }
            return output.ToArray();
        }

        public static byte[] Sanitize(byte[] data)
        {
            int removed = 0;
            var settings = new XmlReaderSettings
            {
                DtdProcessing = DtdProcessing.Ignore,   // никаких внешних DTD и сущностей
                XmlResolver = null,                     // никаких внешних загрузок
                MaxCharactersInDocument = 64L * 1024 * 1024,
                MaxCharactersFromEntities = 1024,
                IgnoreProcessingInstructions = true,    // удаляет <?xml-stylesheet?>
                IgnoreComments = true
            };

            XDocument doc;
            try
            {
                using var ms = new MemoryStream(data);
                using var reader = XmlReader.Create(ms, settings);
                doc = XDocument.Load(reader, LoadOptions.None);
            }
            catch (Exception ex)
            {
                throw new ImageLoadException("SVG-файл повреждён или содержит недопустимую разметку: " + ex.Message);
            }

            if (doc.Root == null || !doc.Root.Name.LocalName.Equals("svg", StringComparison.OrdinalIgnoreCase))
                throw new ImageLoadException("Корневой элемент не является <svg>.", true);

            var all = doc.Root.DescendantsAndSelf().ToList();
            foreach (var el in all)
            {
                if (el.Parent == null && el != doc.Root) continue; // уже удалён вместе с родителем
                string ln = el.Name.LocalName;

                if (ForbiddenElements.Contains(ln))
                {
                    el.Remove();
                    removed++;
                    continue;
                }

                if (ln.Equals("style", StringComparison.OrdinalIgnoreCase))
                {
                    string css = el.Value;
                    string clean = ImportRegex.Replace(UrlRegex.Replace(css, "none"), "");
                    clean = clean.Replace("expression(", "(", StringComparison.OrdinalIgnoreCase);
                    if (clean != css) { el.Value = clean; removed++; }
                }

                foreach (var attr in el.Attributes().ToList())
                {
                    string an = attr.Name.LocalName;
                    string val = attr.Value ?? "";
                    string compact = new string(val.Where(c => !char.IsWhiteSpace(c) && c > 31).ToArray()).ToLowerInvariant();

                    if (an.StartsWith("on", StringComparison.OrdinalIgnoreCase))
                    {
                        attr.Remove(); removed++; continue;
                    }
                    if (compact.Contains("javascript:") || compact.Contains("vbscript:") || compact.Contains("data:text/html") ||
                        compact.Contains("data:image/svg"))
                    {
                        attr.Remove(); removed++; continue;
                    }
                    if (an.Equals("href", StringComparison.OrdinalIgnoreCase) || an.Equals("src", StringComparison.OrdinalIgnoreCase))
                    {
                        string v = val.Trim();
                        bool internalRef = v.StartsWith("#", StringComparison.Ordinal);
                        bool inlineImage = ln.Equals("image", StringComparison.OrdinalIgnoreCase) && DataImageRegex.IsMatch(v);
                        if (!internalRef && !inlineImage)
                        {
                            attr.Remove(); removed++;
                        }
                        continue;
                    }
                    if (an.Equals("style", StringComparison.OrdinalIgnoreCase) || compact.Contains("url("))
                    {
                        string clean = ImportRegex.Replace(UrlRegex.Replace(val, "none"), "");
                        if (clean != val) { attr.Value = clean; removed++; }
                    }
                }

                // <image> без допустимой ссылки удаляется целиком
                if (ln.Equals("image", StringComparison.OrdinalIgnoreCase) &&
                    !el.Attributes().Any(a => a.Name.LocalName.Equals("href", StringComparison.OrdinalIgnoreCase)))
                {
                    el.Remove(); removed++;
                }
            }

            LastRemovedCount = removed;
            using var outMs = new MemoryStream();
            using (var writer = XmlWriter.Create(outMs, new XmlWriterSettings { Encoding = new UTF8Encoding(false), OmitXmlDeclaration = false }))
            {
                doc.Save(writer);
            }
            return outMs.ToArray();
        }
    }
}
