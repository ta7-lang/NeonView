using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace NeonView.Imaging
{
    public sealed class ThumbItem : INotifyPropertyChanged
    {
        public string Path { get; }
        public string Name { get; }
        internal int Generation { get; }
        internal bool Requested;
        private BitmapSource _thumb;
        private bool _failed;

        public ThumbItem(string path, int generation)
        {
            Path = path;
            Name = System.IO.Path.GetFileName(path);
            Generation = generation;
        }

        public string Tip => Name;

        public BitmapSource Thumb
        {
            get
            {
                if (_thumb == null && !Requested && !_failed)
                {
                    Requested = true;
                    ThumbnailService.Request(this);
                }
                return _thumb;
            }
        }

        public bool Failed => _failed;
        public bool IsLoading => _thumb == null && !_failed;

        internal void SetThumb(BitmapSource b)
        {
            if (b == null) _failed = true;
            _thumb = b;
            OnChanged(nameof(Thumb));
            OnChanged(nameof(Failed));
            OnChanged(nameof(IsLoading));
        }

        internal void Evict()
        {
            _thumb = null;
            Requested = false;
            OnChanged(nameof(Thumb));
            OnChanged(nameof(IsLoading));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnChanged(string n) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    /// <summary>
    /// Миниатюры для ленты. Хранятся ТОЛЬКО в оперативной памяти с жёстким лимитом (LRU),
    /// ничего не пишется на диск — кэш не накапливается.
    /// </summary>
    public static class ThumbnailService
    {
        public const int ThumbSize = 176;
        public const int Capacity = 240;
        private const int MaxPending = 300;
        private const int MaxWorkers = 2;

        private static readonly object Gate = new object();
        private static readonly LinkedList<ThumbItem> Pending = new LinkedList<ThumbItem>();
        private static readonly LinkedList<ThumbItem> Loaded = new LinkedList<ThumbItem>();
        private static int _workers;
        private static volatile bool _shutdown;
        private static Dispatcher _ui;

        public static int Generation { get; private set; }
        public static long MaxBytes { get; set; } = 512L * 1024 * 1024;
        public static int LoadedCount => Loaded.Count;

        public static void Init(Dispatcher ui) => _ui = ui;

        public static int NewGeneration()
        {
            lock (Gate)
            {
                Generation++;
                foreach (var p in Pending) p.Requested = false;
                Pending.Clear();
            }
            Loaded.Clear();
            return Generation;
        }

        public static void ClearMemory()
        {
            var items = new List<ThumbItem>(Loaded);
            Loaded.Clear();
            foreach (var it in items) it.Evict();
        }

        internal static void Request(ThumbItem item)
        {
            if (_shutdown || _ui == null) return;
            lock (Gate)
            {
                Pending.AddFirst(item); // LIFO: сначала то, что пользователь видит сейчас
                while (Pending.Count > MaxPending)
                {
                    var last = Pending.Last.Value;
                    last.Requested = false;
                    Pending.RemoveLast();
                }
                if (_workers < MaxWorkers)
                {
                    _workers++;
                    Task.Factory.StartNew(Worker, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
                }
            }
        }

        private static void Worker()
        {
            try { Thread.CurrentThread.Priority = ThreadPriority.BelowNormal; } catch { }
            while (!_shutdown)
            {
                ThumbItem it;
                lock (Gate)
                {
                    if (Pending.Count == 0) { _workers--; return; }
                    it = Pending.First.Value;
                    Pending.RemoveFirst();
                }
                if (it.Generation != Generation) continue;

                BitmapSource bmp = null;
                try
                {
                    long max = Math.Min(MaxBytes, 300L * 1024 * 1024);
                    bmp = ImageLoader.DecodeThumbnail(it.Path, ThumbSize, max);
                }
                catch { bmp = null; }

                var ui = _ui;
                if (ui == null || _shutdown) break;
                ui.BeginInvoke(new Action(() =>
                {
                    if (it.Generation != Generation) return;
                    it.SetThumb(bmp);
                    if (bmp != null) Touch(it);
                }), DispatcherPriority.Background);
            }
            lock (Gate) { _workers = Math.Max(0, _workers - 1); }
        }

        // Вызывается только в потоке интерфейса
        private static void Touch(ThumbItem it)
        {
            Loaded.Remove(it);
            Loaded.AddLast(it);
            while (Loaded.Count > Capacity)
            {
                var old = Loaded.First.Value;
                Loaded.RemoveFirst();
                old.Evict();
            }
        }

        public static void Shutdown()
        {
            _shutdown = true;
            lock (Gate) { Pending.Clear(); }
            Loaded.Clear();
        }
    }
}
