using System;
using System.IO;
using ImageMagick;

namespace NeonView.Imaging
{
    /// <summary>
    /// Инициализация ImageMagick со строгой политикой безопасности:
    /// отключены сетевые протоколы, внешние программы (delegates), PostScript/PDF,
    /// текстовые и «скриптовые» кодеки, косвенное чтение путей (@file);
    /// ограничены память, размеры, время декодирования и временные файлы.
    /// </summary>
    public static class MagickBootstrap
    {
        public static bool Initialized { get; private set; }
        public static string LastError { get; private set; }

        public const string PolicyXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<policymap>
  <policy domain=""resource"" name=""memory"" value=""3GiB""/>
  <policy domain=""resource"" name=""map"" value=""4GiB""/>
  <policy domain=""resource"" name=""disk"" value=""6GiB""/>
  <policy domain=""resource"" name=""width"" value=""64KP""/>
  <policy domain=""resource"" name=""height"" value=""64KP""/>
  <policy domain=""resource"" name=""area"" value=""1GP""/>
  <policy domain=""resource"" name=""list-length"" value=""1000""/>
  <policy domain=""delegate"" rights=""none"" pattern=""*""/>
  <policy domain=""path"" rights=""none"" pattern=""@*""/>
  <policy domain=""coder"" rights=""none"" pattern=""{URL,HTTP,HTTPS,FTP,FILE,MSL,TEXT,TXT,LABEL,CAPTION,PANGO,PS,PS2,PS3,EPS,EPI,EPSF,EPSI,EPT,PDF,PDFA,AI,XPS,PCL,SHOW,WIN,X,SCREENSHOT,CLIPBOARD,EPHEMERAL,INLINE,VID,HTML,SHTML,MAP,MATTE,MASK,IPL,BROWSE,PLT,HPGL,GVZ,DOT,SCAN}""/>
  <policy domain=""module"" rights=""none"" pattern=""{PS,PDF,XPS,MSL,URL,TEXT,LABEL,CAPTION,PANGO,HTML,SHOW,WIN}""/>
  <policy domain=""system"" name=""shred"" value=""1""/>
</policymap>";

        public static void Initialize()
        {
            if (Initialized) return;
            try
            {
                CleanTemp();
                Directory.CreateDirectory(AppPaths.TempDir);

                var configDir = Path.Combine(AppPaths.TempDir, "config");
                Directory.CreateDirectory(configDir);

                var cfg = ConfigurationFiles.Default;
                cfg.Policy.Data = PolicyXml;
                MagickNET.Initialize(cfg, configDir);

                MagickNET.SetTempDirectory(AppPaths.TempDir);
                Initialized = true;
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
                throw;
            }
        }

        /// <summary>Удаляет все временные файлы приложения (вызывается при запуске и выходе).</summary>
        public static long CleanTemp()
        {
            long freed = 0;
            try
            {
                var dir = new DirectoryInfo(AppPaths.TempDir);
                if (!dir.Exists) return 0;
                foreach (var f in dir.EnumerateFiles("*", SearchOption.AllDirectories))
                {
                    try
                    {
                        if (f.Directory != null && f.Directory.Name == "config" && Initialized) continue;
                        long len = f.Length;
                        f.Delete();
                        freed += len;
                    }
                    catch { }
                }
                if (!Initialized)
                {
                    foreach (var d in dir.EnumerateDirectories())
                    {
                        try { d.Delete(true); } catch { }
                    }
                }
            }
            catch { }
            return freed;
        }

        public static long TempSize()
        {
            long size = 0;
            try
            {
                var dir = new DirectoryInfo(AppPaths.TempDir);
                if (!dir.Exists) return 0;
                foreach (var f in dir.EnumerateFiles("*", SearchOption.AllDirectories))
                {
                    try
                    {
                        if (f.Directory != null && f.Directory.Name == "config") continue;
                        size += f.Length;
                    }
                    catch { }
                }
            }
            catch { }
            return size;
        }

        public static void Cleanup()
        {
            try
            {
                Initialized = false;
                var dir = new DirectoryInfo(AppPaths.TempDir);
                if (dir.Exists) dir.Delete(true);
            }
            catch { }
        }

        public static string Version
        {
            get
            {
                try { return MagickNET.Version; } catch { return "?"; }
            }
        }

        public static string Delegates
        {
            get
            {
                try { return MagickNET.Delegates; } catch { return "?"; }
            }
        }
    }
}
