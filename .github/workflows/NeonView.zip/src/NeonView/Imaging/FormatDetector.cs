using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace NeonView.Imaging
{
    public sealed class DetectResult
    {
        /// <summary>Имя члена перечисления ImageMagick.MagickFormat.</summary>
        public string MagickFormat;
        public string DisplayName;
        public bool IsSvg;
        public bool IsGzip;
        public bool MaybeAnimated;
        public bool IsRaw;
        public bool ExtensionMismatch;
        public string MismatchNote;
        public bool Rejected;
        public bool RejectedForSecurity;
        public string Reason;

        public bool IsJpeg => MagickFormat == "Jpeg";
        public bool IsTiff => MagickFormat == "Tiff";
        public bool SupportsMetadataEdit => IsJpeg || IsTiff;
    }

    /// <summary>
    /// Определение формата по содержимому (сигнатурам), а не по расширению.
    /// Блокирует исполняемые файлы, скрипты, HTML, PDF, архивы и прочее,
    /// замаскированное под изображение.
    /// </summary>
    public static class FormatDetector
    {
        public static readonly string[] RawExtensions =
        {
            "dng", "cr2", "cr3", "crw", "nef", "nrw", "arw", "srf", "sr2", "orf", "rw2", "raf", "pef",
            "srw", "x3f", "3fr", "mef", "mos", "erf", "kdc", "dcr", "rwl", "iiq"
        };

        public static readonly string[] AllExtensions =
        {
            "jpg", "jpeg", "jpe", "jfif", "png", "apng", "bmp", "dib", "gif", "tif", "tiff", "webp",
            "heic", "heif", "hif", "avif", "jxl", "ico", "cur", "psd", "svg", "svgz",
            "tga", "qoi", "dds", "exr", "hdr", "pcx", "jp2", "j2k", "jpf", "ppm", "pgm", "pbm", "pnm", "pam", "xcf",
            "dng", "cr2", "cr3", "crw", "nef", "nrw", "arw", "srf", "sr2", "orf", "rw2", "raf", "pef",
            "srw", "x3f", "3fr", "mef", "mos", "erf", "kdc", "dcr", "rwl", "iiq"
        };

        private static readonly HashSet<string> All = new HashSet<string>(AllExtensions, StringComparer.OrdinalIgnoreCase);
        private static readonly HashSet<string> Raw = new HashSet<string>(RawExtensions, StringComparer.OrdinalIgnoreCase);

        public static string Ext(string path)
        {
            try
            {
                var e = Path.GetExtension(path);
                return string.IsNullOrEmpty(e) ? "" : e.Substring(1).ToLowerInvariant();
            }
            catch { return ""; }
        }

        public static bool IsSupportedExtension(string path) => All.Contains(Ext(path));
        public static bool IsRawExtension(string path) => Raw.Contains(Ext(path));

        public static string OpenDialogFilter
        {
            get
            {
                string all = string.Join(";", AllExtensions.Select(e => "*." + e));
                string raw = string.Join(";", RawExtensions.Select(e => "*." + e));
                return "Все изображения|" + all +
                       "|JPEG|*.jpg;*.jpeg;*.jpe;*.jfif" +
                       "|PNG|*.png;*.apng" +
                       "|HEIC / HEIF / AVIF|*.heic;*.heif;*.hif;*.avif" +
                       "|WebP|*.webp" +
                       "|GIF|*.gif" +
                       "|BMP|*.bmp;*.dib" +
                       "|TIFF|*.tif;*.tiff" +
                       "|SVG|*.svg;*.svgz" +
                       "|RAW (DNG, CR2, CR3, NEF, ARW…)|" + raw +
                       "|Другие (PSD, JPEG XL, TGA, QOI, DDS, EXR, HDR, ICO…)|*.psd;*.jxl;*.tga;*.qoi;*.dds;*.exr;*.hdr;*.ico;*.cur;*.pcx;*.jp2;*.j2k;*.ppm;*.pgm;*.pbm;*.pnm;*.pam;*.xcf" +
                       "|Все файлы|*.*";
            }
        }

        private static string ExpectedFamily(string ext) => ext switch
        {
            "jpg" or "jpeg" or "jpe" or "jfif" => "Jpeg",
            "png" or "apng" => "Png",
            "gif" => "Gif",
            "bmp" or "dib" => "Bmp",
            "tif" or "tiff" => "Tiff",
            "webp" => "WebP",
            "heic" or "heif" or "hif" => "Heic",
            "avif" => "Avif",
            "jxl" => "Jxl",
            "ico" => "Ico",
            "cur" => "Cur",
            "psd" => "Psd",
            "svg" or "svgz" => "Svg",
            "qoi" => "Qoi",
            "dds" => "Dds",
            "exr" => "Exr",
            "hdr" => "Hdr",
            "jp2" or "j2k" or "jpf" => "Jp2",
            "xcf" => "Xcf",
            _ => null
        };

        private static bool At(byte[] d, int off, params byte[] sig)
        {
            if (d.Length < off + sig.Length) return false;
            for (int i = 0; i < sig.Length; i++) if (d[off + i] != sig[i]) return false;
            return true;
        }

        private static bool AtAscii(byte[] d, int off, string s) => At(d, off, Encoding.ASCII.GetBytes(s));

        private static string HeadText(byte[] d, int max = 2048)
        {
            int n = Math.Min(d.Length, max);
            int start = 0;
            if (n >= 3 && d[0] == 0xEF && d[1] == 0xBB && d[2] == 0xBF) start = 3;
            else if (n >= 2 && ((d[0] == 0xFF && d[1] == 0xFE) || (d[0] == 0xFE && d[1] == 0xFF)))
            {
                try
                {
                    var enc = d[0] == 0xFF ? Encoding.Unicode : Encoding.BigEndianUnicode;
                    return enc.GetString(d, 2, Math.Min(d.Length - 2, max)).TrimStart();
                }
                catch { return ""; }
            }
            return Encoding.UTF8.GetString(d, start, n - start).TrimStart();
        }

        public static DetectResult Detect(byte[] d, string path)
        {
            string ext = Ext(path);
            var r = new DetectResult();
            if (d == null || d.Length < 4)
            {
                r.Rejected = true;
                r.Reason = "Файл пустой или повреждён.";
                return r;
            }

            string magic = null;
            string name = null;

            // --- Растровые форматы с сигнатурой ---
            if (At(d, 0, 0xFF, 0xD8, 0xFF)) { magic = "Jpeg"; name = "JPEG"; }
            else if (At(d, 0, 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) { magic = "Png"; name = ext == "apng" ? "APNG" : "PNG"; }
            else if (AtAscii(d, 0, "GIF87a") || AtAscii(d, 0, "GIF89a")) { magic = "Gif"; name = "GIF"; r.MaybeAnimated = true; }
            else if (AtAscii(d, 0, "BM") && d.Length > 26) { magic = "Bmp"; name = "BMP"; }
            else if (AtAscii(d, 0, "RIFF") && AtAscii(d, 8, "WEBP")) { magic = "WebP"; name = "WebP"; r.MaybeAnimated = true; }
            else if (AtAscii(d, 4, "ftyp"))
            {
                string brand = d.Length >= 12 ? Encoding.ASCII.GetString(d, 8, 4) : "";
                string head = Encoding.ASCII.GetString(d, 8, Math.Min(64, d.Length - 8));
                if (brand == "avif" || brand == "avis" || (brand == "mif1" && head.Contains("avif"))) { magic = "Avif"; name = "AVIF"; }
                else if (brand is "heic" or "heix" or "hevc" or "hevx" or "heim" or "heis" or "mif1" or "msf1") { magic = "Heic"; name = "HEIC/HEIF"; }
                else if (brand == "crx ") { magic = "Cr3"; name = "Canon CR3 (RAW)"; r.IsRaw = true; }
                else if (brand == "jxl ") { magic = "Jxl"; name = "JPEG XL"; }
                else if (brand.StartsWith("jp2") || brand == "jpx ") { magic = "Jp2"; name = "JPEG 2000"; }
            }
            else if (At(d, 0, 0xFF, 0x0A) || At(d, 0, 0x00, 0x00, 0x00, 0x0C, 0x4A, 0x58, 0x4C, 0x20)) { magic = "Jxl"; name = "JPEG XL"; }
            else if (At(d, 0, 0x00, 0x00, 0x00, 0x0C, 0x6A, 0x50, 0x20, 0x20)) { magic = "Jp2"; name = "JPEG 2000"; }
            else if (At(d, 0, 0xFF, 0x4F, 0xFF, 0x51)) { magic = "J2k"; name = "JPEG 2000 (поток)"; }
            else if (AtAscii(d, 0, "FUJIFILMCCD-RAW")) { magic = "Raf"; name = "Fujifilm RAF (RAW)"; r.IsRaw = true; }
            else if (AtAscii(d, 0, "IIRO") || AtAscii(d, 0, "IIRS") || AtAscii(d, 0, "MMOR")) { magic = "Orf"; name = "Olympus ORF (RAW)"; r.IsRaw = true; }
            else if (At(d, 0, 0x49, 0x49, 0x55, 0x00)) { magic = "Rw2"; name = "Panasonic RW2 (RAW)"; r.IsRaw = true; }
            else if (AtAscii(d, 0, "FOVb")) { magic = "X3f"; name = "Sigma X3F (RAW)"; r.IsRaw = true; }
            else if (At(d, 0, 0x49, 0x49, 0x1A, 0x00, 0x00, 0x00) && AtAscii(d, 6, "HEAPCCDR")) { magic = "Crw"; name = "Canon CRW (RAW)"; r.IsRaw = true; }
            else if (At(d, 0, 0x49, 0x49, 0x2A, 0x00) || At(d, 0, 0x4D, 0x4D, 0x00, 0x2A) ||
                     At(d, 0, 0x49, 0x49, 0x2B, 0x00) || At(d, 0, 0x4D, 0x4D, 0x00, 0x2B))
            {
                if (Raw.Contains(ext)) { magic = RawFormatName(ext); name = ext.ToUpperInvariant() + " (RAW)"; r.IsRaw = true; }
                else { magic = "Tiff"; name = "TIFF"; }
            }
            else if (AtAscii(d, 0, "8BPS")) { magic = "Psd"; name = "Photoshop PSD"; }
            else if (At(d, 0, 0x00, 0x00, 0x01, 0x00) && d.Length > 22) { magic = "Ico"; name = "Значок ICO"; }
            else if (At(d, 0, 0x00, 0x00, 0x02, 0x00) && d.Length > 22) { magic = "Cur"; name = "Курсор CUR"; }
            else if (AtAscii(d, 0, "qoif")) { magic = "Qoi"; name = "QOI"; }
            else if (AtAscii(d, 0, "DDS ")) { magic = "Dds"; name = "DirectDraw DDS"; }
            else if (At(d, 0, 0x76, 0x2F, 0x31, 0x01)) { magic = "Exr"; name = "OpenEXR"; }
            else if (AtAscii(d, 0, "#?RADIANCE") || AtAscii(d, 0, "#?RGBE")) { magic = "Hdr"; name = "Radiance HDR"; }
            else if (AtAscii(d, 0, "gimp xcf")) { magic = "Xcf"; name = "GIMP XCF"; }
            else if (d[0] == (byte)'P' && d[1] >= (byte)'1' && d[1] <= (byte)'7' && (d[2] == 0x0A || d[2] == 0x0D || d[2] == 0x20 || d[2] == 0x09))
            { magic = "Pnm"; name = "Netpbm (PNM)"; }
            else if (At(d, 0, 0x1F, 0x8B) && ext == "svgz") { magic = "Svg"; name = "SVGZ (сжатый SVG)"; r.IsSvg = true; r.IsGzip = true; }

            // --- Явно опасное содержимое ---
            if (magic == null)
            {
                string danger = DangerReason(d);
                if (danger != null)
                {
                    r.Rejected = true;
                    r.RejectedForSecurity = true;
                    r.Reason = danger;
                    return r;
                }

                string text = HeadText(d);
                if (LooksLikeSvg(text))
                {
                    magic = "Svg"; name = "SVG"; r.IsSvg = true;
                }
            }

            // --- Форматы без надёжной сигнатуры: доверяем расширению ---
            if (magic == null)
            {
                if (ext == "tga") { magic = "Tga"; name = "Targa TGA"; }
                else if (ext == "pcx" && d[0] == 0x0A) { magic = "Pcx"; name = "PCX"; }
                else if (Raw.Contains(ext)) { magic = RawFormatName(ext); name = ext.ToUpperInvariant() + " (RAW)"; r.IsRaw = true; }
            }

            if (magic == null)
            {
                r.Rejected = true;
                r.Reason = "Неизвестный или повреждённый формат. Содержимое файла не похоже ни на один поддерживаемый тип изображения.";
                return r;
            }

            r.MagickFormat = magic;
            r.DisplayName = name;

            string expected = ExpectedFamily(ext);
            if (expected != null && !string.Equals(expected, magic, StringComparison.OrdinalIgnoreCase) &&
                !(expected == "Jp2" && magic == "J2k"))
            {
                r.ExtensionMismatch = true;
                r.MismatchNote = $"Расширение «.{ext}» не соответствует содержимому — файл открыт как {name}.";
            }
            else if (Raw.Contains(ext) && !r.IsRaw)
            {
                r.ExtensionMismatch = true;
                r.MismatchNote = $"Расширение «.{ext}» не соответствует содержимому — файл открыт как {name}.";
            }
            return r;
        }

        private static string RawFormatName(string ext) => ext switch
        {
            "3fr" => "ThreeFr",
            "" => "Dng",
            _ => char.ToUpperInvariant(ext[0]) + ext.Substring(1)
        };

        private static bool LooksLikeSvg(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            if (!(text.StartsWith("<?xml", StringComparison.OrdinalIgnoreCase) ||
                  text.StartsWith("<svg", StringComparison.OrdinalIgnoreCase) ||
                  text.StartsWith("<!--", StringComparison.Ordinal) ||
                  text.StartsWith("<!DOCTYPE svg", StringComparison.OrdinalIgnoreCase))) return false;
            return text.IndexOf("<svg", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string DangerReason(byte[] d)
        {
            if (AtAscii(d, 0, "MZ")) return "Это исполняемый файл Windows (EXE/DLL), замаскированный под изображение. Открытие заблокировано.";
            if (At(d, 0, 0x7F, 0x45, 0x4C, 0x46)) return "Это исполняемый файл (ELF). Открытие заблокировано.";
            if (AtAscii(d, 0, "%PDF")) return "Это PDF-документ, а не изображение. Открытие заблокировано.";
            if (AtAscii(d, 0, "%!")) return "Это PostScript-программа, а не изображение. Открытие заблокировано.";
            if (At(d, 0, 0x50, 0x4B, 0x03, 0x04)) return "Это архив (ZIP/Office), а не изображение. Открытие заблокировано.";
            if (AtAscii(d, 0, "Rar!") || At(d, 0, 0x37, 0x7A, 0xBC, 0xAF)) return "Это архив, а не изображение. Открытие заблокировано.";
            if (AtAscii(d, 0, "{\\rtf")) return "Это RTF-документ. Открытие заблокировано.";
            if (At(d, 0, 0xD0, 0xCF, 0x11, 0xE0)) return "Это документ OLE (MS Office / MSI). Открытие заблокировано.";
            if (AtAscii(d, 0, "#!")) return "Это скрипт. Открытие заблокировано.";
            if (AtAscii(d, 0, "L\0\0\0")) return "Это ярлык Windows (LNK). Открытие заблокировано.";

            string t = HeadText(d, 1024).ToLowerInvariant();
            if (t.StartsWith("<html") || t.StartsWith("<!doctype html") || t.Contains("<script") || t.StartsWith("<?php") ||
                t.StartsWith("<hta:") || t.Contains("<iframe"))
                if (!t.Contains("<svg")) return "Файл содержит HTML/скрипт, а не изображение. Открытие заблокировано.";
            if (t.StartsWith("@echo") || t.StartsWith("powershell") || t.StartsWith("function ") || t.StartsWith("var ") ||
                t.StartsWith("dim ") || t.StartsWith("set ws") || t.StartsWith("<job"))
                return "Файл содержит текст скрипта, а не изображение. Открытие заблокировано.";
            return null;
        }
    }
}
