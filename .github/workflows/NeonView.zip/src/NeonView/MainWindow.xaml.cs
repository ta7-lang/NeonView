using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using NeonView.Editing;
using NeonView.Imaging;
using NeonView.Metadata;
using NeonView.Security;
using NeonView.Services;
using NeonView.Theming;
using NeonView.Views;
using IOPath = System.IO.Path;
using IMagickImageU = ImageMagick.IMagickImage<ushort>;
using MagickFormat = ImageMagick.MagickFormat;
using ExifTag = ImageMagick.ExifTag;
using MagickColors = ImageMagick.MagickColors;
using AlphaOption = ImageMagick.AlphaOption;

namespace NeonView
{
    public partial class MainWindow : Window
    {
        private AppSettings S => App.Settings;

        // --- Файлы ---
        private List<string> _files = new List<string>();
        private int _index = -1;
        private readonly ObservableCollection<ThumbItem> _thumbs = new ObservableCollection<ThumbItem>();
        private string _folder;
        private bool _syncThumb;

        // --- Текущее изображение ---
        private DecodedImage _current;
        private string _currentPath;
        private CancellationTokenSource _loadCts;
        private readonly Dictionary<string, DecodedImage> _preload = new Dictionary<string, DecodedImage>(StringComparer.OrdinalIgnoreCase);
        private int _preloadVersion;

        // --- Вид ---
        private int _bmpW, _bmpH;
        private double _zoom = 1;
        private bool _fitMode = true;
        private double _offX, _offY;
        private int _viewRotation;
        private bool _panning;
        private Point _panStart;
        private double _panOffX, _panOffY;
        private bool _isVector;

        // --- Таймеры ---
        private readonly DispatcherTimer _animTimer = new DispatcherTimer(DispatcherPriority.Render);
        private int _animIndex;
        private readonly DispatcherTimer _slideTimer = new DispatcherTimer();
        private readonly DispatcherTimer _toastTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(3) };
        private readonly DispatcherTimer _idleTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2.5) };
        private readonly DispatcherTimer _previewDebounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(110) };
        private readonly DispatcherTimer _loadingDelay = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(180) };

        // --- Полный экран ---
        private bool _fullscreen;
        private Rect _restoreBounds;
        private WindowState _restoreState;

        // --- Редактор ---
        private bool _editMode;
        private IMagickImageU _editBase;
        private IMagickImageU _appliedCache;
        private int _appliedCacheVersion = -1;
        private int _opsVersion;
        private double _editScale = 1;
        private readonly List<EditOp> _ops = new List<EditOp>();
        private readonly Stack<EditOp> _redo = new Stack<EditOp>();
        private ToolDef _tool;
        private double[] _toolValues;
        private BitmapSource _editBitmap;
        private BitmapSource _editOriginalBitmap;
        private int _previewVersion;
        private readonly SemaphoreSlim _renderGate = new SemaphoreSlim(1, 1);
        private string _category = ToolCatalog.Categories[0];
        private bool _comparing;

        private readonly string _startupPath;

        public MainWindow(string startupPath)
        {
            _startupPath = startupPath;
            InitializeComponent();

            ThumbnailService.Init(Dispatcher);
            ThumbList.ItemsSource = _thumbs;

            _animTimer.Tick += AnimTimer_Tick;
            _slideTimer.Tick += (s, e) => Navigate(+1, fromSlideshow: true);
            _toastTimer.Tick += (s, e) => HideToast();
            _idleTimer.Tick += (s, e) => { _idleTimer.Stop(); if (_fullscreen) SetChromeVisible(false); };
            _previewDebounce.Tick += (s, e) => { _previewDebounce.Stop(); RequestPreview(); };
            _loadingDelay.Tick += (s, e) => { _loadingDelay.Stop(); ShowLoading(true); };

            BuildCategories();

            App.SettingsChanged += ApplySettings;
            Loaded += MainWindow_Loaded;
            Closing += MainWindow_Closing;
            StateChanged += (s, e) => UpdateMaxState();
            PreviewKeyDown += MainWindow_PreviewKeyDown;
            Drop += MainWindow_Drop;
            DragOver += MainWindow_DragOver;
            MouseMove += (s, e) => { if (_fullscreen) { SetChromeVisible(true); _idleTimer.Stop(); _idleTimer.Start(); } };

            RestoreWindowPlacement();
            ApplySettings();
        }

        // =====================================================================
        //  Запуск / закрытие / настройки
        // =====================================================================

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateMaxState();
            UpdateUiState();
            if (!MagickBootstrap.Initialized)
                ShowError("Модуль декодирования не запущен", "Не удалось инициализировать декодер изображений: " + MagickBootstrap.LastError, false);
            if (!string.IsNullOrEmpty(_startupPath)) OpenPath(_startupPath);
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (_editMode && _ops.Count > 0)
            {
                int r = NeonDialog.Show(this, "Несохранённые правки", "В редакторе есть правки, которые ещё не сохранены. Закрыть без сохранения?", "⚠", 1, "Закрыть", "Остаться");
                if (r != 0) { e.Cancel = true; return; }
            }
            SaveWindowPlacement();
            StopSlideshow();
            _animTimer.Stop();
            App.SettingsChanged -= ApplySettings;
            ThumbnailService.Shutdown();
            try { _appliedCache?.Dispose(); _editBase?.Dispose(); } catch { }
        }

        private void RestoreWindowPlacement()
        {
            Width = S.WinWidth;
            Height = S.WinHeight;
            if (double.IsFinite(S.WinLeft) && double.IsFinite(S.WinTop))
            {
                // Окно должно быть хотя бы частично видимым
                var vs = new Rect(SystemParameters.VirtualScreenLeft, SystemParameters.VirtualScreenTop, SystemParameters.VirtualScreenWidth, SystemParameters.VirtualScreenHeight);
                if (vs.IntersectsWith(new Rect(S.WinLeft, S.WinTop, 200, 100)))
                {
                    WindowStartupLocation = WindowStartupLocation.Manual;
                    Left = S.WinLeft;
                    Top = S.WinTop;
                }
            }
            if (S.WinMaximized) WindowState = WindowState.Maximized;
        }

        private void SaveWindowPlacement()
        {
            try
            {
                var b = _fullscreen ? _restoreBounds : RestoreBounds;
                if (!b.IsEmpty && b.Width > 100)
                {
                    S.WinLeft = b.Left; S.WinTop = b.Top; S.WinWidth = b.Width; S.WinHeight = b.Height;
                }
                S.WinMaximized = _fullscreen ? _restoreState == WindowState.Maximized : WindowState == WindowState.Maximized;
                SettingsStore.Save(S);
            }
            catch { }
        }

        private void ApplySettings()
        {
            double sc = S.UiScale;
            TitleScale.ScaleX = TitleScale.ScaleY = sc;
            BarScale.ScaleX = BarScale.ScaleY = sc;
            EditScale.ScaleX = EditScale.ScaleY = sc;
            ThumbBar.Visibility = S.ShowThumbnails && !_fullscreen && _files.Count > 1 ? Visibility.Visible : Visibility.Collapsed;
            InfoOverlay.Visibility = S.ShowInfoOverlay ? Visibility.Visible : Visibility.Collapsed;
            ThumbnailService.MaxBytes = S.MaxFileBytes;
            _slideTimer.Interval = TimeSpan.FromSeconds(S.SlideshowSeconds);
            UpdateLayoutImage();
        }

        private void UpdateMaxState()
        {
            bool max = WindowState == WindowState.Maximized && !_fullscreen;
            RootGrid.Margin = max ? new Thickness(7) : new Thickness(0);
            BtnMax.Content = max ? "" : "";
            BtnMax.ToolTip = max ? "Восстановить" : "Развернуть";
        }

        // =====================================================================
        //  Открытие файлов и папок
        // =====================================================================

        private void BtnOpen_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Title = "Открыть изображение",
                Filter = FormatDetector.OpenDialogFilter,
                CheckFileExists = true,
                Multiselect = false,
                DereferenceLinks = false
            };
            if (!string.IsNullOrEmpty(_folder) && Directory.Exists(_folder)) dlg.InitialDirectory = _folder;
            if (dlg.ShowDialog(this) == true) OpenPath(dlg.FileName);
        }

        private void MenuOpenFolder_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFolderDialog { Title = "Выберите папку с изображениями" };
            if (!string.IsNullOrEmpty(_folder) && Directory.Exists(_folder)) dlg.InitialDirectory = _folder;
            if (dlg.ShowDialog(this) == true) OpenPath(dlg.FolderName);
        }

        private void MainWindow_DragOver(object sender, DragEventArgs e)
        {
            e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;
        }

        private void MainWindow_Drop(object sender, DragEventArgs e)
        {
            try
            {
                if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0)
                {
                    string f = files[0];
                    if (IOPath.GetExtension(f).Equals(".lnk", StringComparison.OrdinalIgnoreCase) || IOPath.GetExtension(f).Equals(".url", StringComparison.OrdinalIgnoreCase))
                    {
                        ShowToast("Ярлыки не открываются из соображений безопасности.", true);
                        return;
                    }
                    OpenPath(f);
                }
            }
            catch (Exception ex) { ShowToast("Не удалось открыть: " + ex.Message, true); }
        }

        public void OpenPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            if (!ConfirmLeaveEdit()) return;
            try
            {
                if (Directory.Exists(path))
                {
                    var list = ListFolder(path);
                    if (list.Count == 0) { ShowToast("В этой папке нет поддерживаемых изображений.", true); return; }
                    SetFileList(path, list, 0);
                    return;
                }
                if (!File.Exists(path)) { ShowError("Файл не найден", path, false); return; }

                string dir = IOPath.GetDirectoryName(path);
                var files = ListFolder(dir);
                int idx = files.FindIndex(f => string.Equals(f, path, StringComparison.OrdinalIgnoreCase));
                if (idx < 0) { files.Insert(0, path); idx = 0; }
                SetFileList(dir, files, idx);
            }
            catch (Exception ex)
            {
                ShowError("Не удалось открыть", ex.Message, false);
            }
        }

        private List<string> ListFolder(string dir)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(dir)) return result;
            try
            {
                var di = new DirectoryInfo(dir);
                var infos = new List<FileInfo>();
                foreach (var fi in di.EnumerateFiles())
                {
                    try
                    {
                        if ((fi.Attributes & (FileAttributes.Hidden | FileAttributes.System)) != 0) continue;
                        if (!FormatDetector.IsSupportedExtension(fi.Name)) continue;
                        infos.Add(fi);
                    }
                    catch { }
                    if (infos.Count > 50000) break;
                }
                IEnumerable<FileInfo> sorted = S.SortMode switch
                {
                    "date" => infos.OrderBy(f => f.LastWriteTimeUtc),
                    "size" => infos.OrderBy(f => f.Length),
                    "type" => infos.OrderBy(f => f.Extension, StringComparer.OrdinalIgnoreCase).ThenBy(f => f.Name, Native.NaturalComparer.Instance),
                    _ => infos.OrderBy(f => f.Name, Native.NaturalComparer.Instance)
                };
                if (S.SortDescending) sorted = sorted.Reverse();
                result.AddRange(sorted.Select(f => f.FullName));
            }
            catch { }
            return result;
        }

        private void SetFileList(string folder, List<string> files, int index)
        {
            _folder = folder;
            _files = files;
            _preload.Clear();
            int gen = ThumbnailService.NewGeneration();
            _thumbs.Clear();
            foreach (var f in files) _thumbs.Add(new ThumbItem(f, gen));
            ApplySettings();
            _ = LoadIndex(index);
        }

        public void ReloadFolder(string selectPath)
        {
            if (string.IsNullOrEmpty(_folder)) { if (selectPath != null) OpenPath(selectPath); return; }
            var files = ListFolder(_folder);
            int idx = selectPath != null ? files.FindIndex(f => string.Equals(f, selectPath, StringComparison.OrdinalIgnoreCase)) : -1;
            if (idx < 0) idx = Math.Clamp(_index, 0, Math.Max(0, files.Count - 1));
            if (files.Count == 0) { ClearView(); _files = files; _thumbs.Clear(); ApplySettings(); return; }
            SetFileList(_folder, files, idx);
        }

        // =====================================================================
        //  Загрузка изображений
        // =====================================================================

        private static string CacheKey(string path)
        {
            try { return path + "|" + File.GetLastWriteTimeUtc(path).Ticks; } catch { return path; }
        }

        private async Task LoadIndex(int i)
        {
            if (_files.Count == 0) { ClearView(); return; }
            if (i < 0 || i >= _files.Count)
            {
                if (!S.LoopNavigation) return;
                i = (i % _files.Count + _files.Count) % _files.Count;
            }
            _index = i;
            string path = _files[i];
            _currentPath = path;
            StopAnimation();
            SyncThumbSelection();

            _loadCts?.Cancel();
            var cts = _loadCts = new CancellationTokenSource();

            ErrorPanel.Visibility = Visibility.Collapsed;
            EmptyState.Visibility = Visibility.Collapsed;
            TitleText.Text = IOPath.GetFileName(path);
            Title = IOPath.GetFileName(path) + " — NeonView";
            IndexText.Text = $"{i + 1} / {_files.Count}";
            _loadingDelay.Stop();
            _loadingDelay.Start();
            LoadingText.Text = FormatDetector.IsRawExtension(path) ? "Проявка RAW…" : "Загрузка…";

            DecodedImage d = null;
            try
            {
                string key = CacheKey(path);
                if (_preload.TryGetValue(key, out var pre))
                {
                    d = pre;
                    _preload.Remove(key);
                }
                else
                {
                    long max = S.MaxFileBytes;
                    d = await Task.Run(() => ImageLoader.Decode(path, 8192, max, cts.Token), cts.Token);
                }
            }
            catch (OperationCanceledException) { return; }
            catch (Exception ex)
            {
                if (cts.IsCancellationRequested) return;
                _loadingDelay.Stop();
                ShowLoading(false);
                _current = null;
                Img.Source = null;
                bool sec = ex is ImageLoadException ile && ile.Security;
                ShowError(sec ? "Файл заблокирован защитой" : "Не удалось открыть изображение", ex.Message, sec);
                UpdateUiState();
                return;
            }
            if (cts.IsCancellationRequested || !ReferenceEquals(cts, _loadCts)) return;

            _loadingDelay.Stop();
            ShowLoading(false);
            _current = d;
            _viewRotation = 0;
            _isVector = d.Detect?.IsSvg == true;
            Img.LayoutTransform = Transform.Identity;
            SetSource(d.Bitmap, true);
            FadeIn();
            if (d.IsAnimated) StartAnimation();
            UpdateInfo();
            UpdateUiState();
            if (S.WarnInternetFiles)
            {
                var motw = Motw.Read(path);
                MotwChip.Visibility = motw != null && motw.IsInternet ? Visibility.Visible : Visibility.Collapsed;
            }
            else MotwChip.Visibility = Visibility.Collapsed;
            if (d.Detect?.ExtensionMismatch == true)
            {
                MismatchText.Text = "⚠ " + d.Detect.MismatchNote;
                MismatchChip.Visibility = Visibility.Visible;
            }
            else MismatchChip.Visibility = Visibility.Collapsed;
            if (d.SvgRemovedItems > 0) ShowToast($"SVG обезврежен: удалено {d.SvgRemovedItems} потенциально опасных элементов (скрипты, внешние ссылки).");

            PreloadNeighbor(i);
        }

        private void PreloadNeighbor(int i)
        {
            if (!S.Preload || _files.Count < 2) return;
            int next = i + 1 >= _files.Count ? (S.LoopNavigation ? 0 : -1) : i + 1;
            if (next < 0 || next == i) return;
            string path = _files[next];
            string key = CacheKey(path);
            if (_preload.ContainsKey(key)) return;
            try
            {
                var fi = new FileInfo(path);
                if (!fi.Exists || fi.Length > 60L * 1024 * 1024 || FormatDetector.IsRawExtension(path)) return;
            }
            catch { return; }
            int ver = ++_preloadVersion;
            long max = S.MaxFileBytes;
            Task.Run(() =>
            {
                try { return ImageLoader.Decode(path, 8192, max, CancellationToken.None); }
                catch { return null; }
            }).ContinueWith(t =>
            {
                var d = t.Result;
                if (d == null || ver != _preloadVersion) return;
                if ((long)d.Bitmap.PixelWidth * d.Bitmap.PixelHeight > 40_000_000) return;
                _preload.Clear(); // держим максимум одно заранее загруженное изображение
                _preload[key] = d;
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void ClearView()
        {
            StopAnimation();
            _current = null;
            _currentPath = null;
            Img.Source = null;
            _index = -1;
            EmptyState.Visibility = Visibility.Visible;
            ErrorPanel.Visibility = Visibility.Collapsed;
            TitleText.Text = "";
            Title = "NeonView";
            UpdateUiState();
        }

        private void Navigate(int delta, bool fromSlideshow = false)
        {
            if (_files.Count == 0) return;
            if (!fromSlideshow && !ConfirmLeaveEdit()) return;
            int i = _index + delta;
            if (!S.LoopNavigation && (i < 0 || i >= _files.Count))
            {
                if (fromSlideshow) StopSlideshow();
                return;
            }
            _ = LoadIndex(i);
        }

        private void BtnPrev_Click(object sender, RoutedEventArgs e) => Navigate(-1);
        private void BtnNext_Click(object sender, RoutedEventArgs e) => Navigate(+1);

        private void SyncThumbSelection()
        {
            if (_index < 0 || _index >= _thumbs.Count) return;
            _syncThumb = true;
            try
            {
                ThumbList.SelectedIndex = _index;
                ThumbList.ScrollIntoView(_thumbs[_index]);
            }
            finally { _syncThumb = false; }
        }

        private void ThumbList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_syncThumb) return;
            int i = ThumbList.SelectedIndex;
            if (i >= 0 && i != _index)
            {
                if (!ConfirmLeaveEdit()) { SyncThumbSelection(); return; }
                _ = LoadIndex(i);
            }
        }

        private void ThumbList_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            // Вертикальная прокрутка колеса листает ленту по горизонтали
            if (FindChild<ScrollViewer>(ThumbList) is ScrollViewer sv)
            {
                sv.ScrollToHorizontalOffset(sv.HorizontalOffset - e.Delta);
                e.Handled = true;
            }
        }

        private static T FindChild<T>(DependencyObject root) where T : DependencyObject
        {
            if (root == null) return null;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
            {
                var c = VisualTreeHelper.GetChild(root, i);
                if (c is T t) return t;
                var r = FindChild<T>(c);
                if (r != null) return r;
            }
            return null;
        }

        // =====================================================================
        //  Отображение, масштаб, панорамирование
        // =====================================================================

        private double DpiScale
        {
            get
            {
                double d = 1;
                try { d = VisualTreeHelper.GetDpi(this).DpiScaleX; } catch { }
                return d <= 0 ? 1 : d;
            }
        }

        /// <summary>Отношение «пикселей оригинала» к пикселям показываемого растра.</summary>
        private double PixelRatio
        {
            get
            {
                if (_current == null || _bmpW <= 0) return 1;
                if (_editMode) return _editBase != null && _editScale > 0 ? 1.0 / _editScale : 1;
                return _current.OriginalWidth / (double)_current.Bitmap.PixelWidth;
            }
        }

        private void SetSource(BitmapSource bmp, bool resetView)
        {
            bool dimsChanged = bmp == null || bmp.PixelWidth != _bmpW || bmp.PixelHeight != _bmpH;
            Img.Source = bmp;
            _bmpW = bmp?.PixelWidth ?? 0;
            _bmpH = bmp?.PixelHeight ?? 0;
            if (resetView || dimsChanged) _fitMode = true;
            UpdateLayoutImage();
        }

        private double FitZoom()
        {
            double vw = Viewport.ActualWidth, vh = Viewport.ActualHeight;
            if (vw <= 0 || vh <= 0 || _bmpW <= 0) return 1;
            bool rot = _viewRotation % 180 != 0;
            double ew = rot ? _bmpH : _bmpW, eh = rot ? _bmpW : _bmpH;
            double z = Math.Min(vw / ew, vh / eh);
            double actual = PixelRatio / DpiScale;   // 100%
            if (!S.UpscaleSmall && !_isVector) z = Math.Min(z, actual);
            return z;
        }

        private void UpdateLayoutImage()
        {
            if (Img.Source == null || _bmpW <= 0) { ZoomText.Text = "—"; return; }
            double vw = Viewport.ActualWidth, vh = Viewport.ActualHeight;
            if (vw <= 0 || vh <= 0) return;
            if (_fitMode) _zoom = FitZoom();

            bool rot = _viewRotation % 180 != 0;
            double ew = (rot ? _bmpH : _bmpW) * _zoom, eh = (rot ? _bmpW : _bmpH) * _zoom;

            if (ew <= vw) _offX = (vw - ew) / 2; else _offX = Math.Clamp(_offX, vw - ew, 0);
            if (eh <= vh) _offY = (vh - eh) / 2; else _offY = Math.Clamp(_offY, vh - eh, 0);

            Img.Width = _bmpW * _zoom;
            Img.Height = _bmpH * _zoom;
            Canvas.SetLeft(Img, Math.Round(_offX));
            Canvas.SetTop(Img, Math.Round(_offY));

            double devicePerPixel = _zoom * DpiScale;
            RenderOptions.SetBitmapScalingMode(Img, S.PixelZoom && devicePerPixel >= 2.5 ? BitmapScalingMode.NearestNeighbor : BitmapScalingMode.HighQuality);

            double pct = _zoom * DpiScale / PixelRatio * 100;
            ZoomText.Text = pct >= 10 ? $"{pct:0}%" : $"{pct:0.#}%";
        }

        private void ZoomAt(double factor, Point p)
        {
            if (Img.Source == null) return;
            double fit = FitZoom();
            double actual = PixelRatio / DpiScale;
            double min = Math.Min(fit, actual) * 0.2;
            double max = actual * 32;
            double old = _zoom;
            double nz = Math.Clamp(old * factor, min, max);
            if (Math.Abs(nz - old) < 1e-9) return;
            _fitMode = false;
            _offX = p.X - (p.X - _offX) * (nz / old);
            _offY = p.Y - (p.Y - _offY) * (nz / old);
            _zoom = nz;
            UpdateLayoutImage();
        }

        private Point ViewCenter => new Point(Viewport.ActualWidth / 2, Viewport.ActualHeight / 2);

        private void ZoomToActual(Point at)
        {
            double actual = PixelRatio / DpiScale;
            ZoomAt(actual / _zoom, at);
        }

        private void Viewport_SizeChanged(object sender, SizeChangedEventArgs e) => UpdateLayoutImage();

        private void Viewport_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            bool ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
            if (S.WheelNavigates && !ctrl && !_editMode)
            {
                Navigate(e.Delta > 0 ? -1 : +1);
            }
            else
            {
                double f = e.Delta > 0 ? 1.18 : 1 / 1.18;
                ZoomAt(f, e.GetPosition(Viewport));
            }
            e.Handled = true;
        }

        private void Viewport_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Viewport.Focus();
            if (e.ClickCount == 2)
            {
                if (_fitMode) ZoomToActual(e.GetPosition(Viewport));
                else { _fitMode = true; UpdateLayoutImage(); }
                e.Handled = true;
                return;
            }
            if (Img.Source == null) return;
            _panning = true;
            _panStart = e.GetPosition(Viewport);
            _panOffX = _offX; _panOffY = _offY;
            Viewport.CaptureMouse();
            Viewport.Cursor = Cursors.SizeAll;
        }

        private void Viewport_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_panning) return;
            var p = e.GetPosition(Viewport);
            _fitMode = false;
            _offX = _panOffX + (p.X - _panStart.X);
            _offY = _panOffY + (p.Y - _panStart.Y);
            UpdateLayoutImage();
        }

        private void Viewport_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!_panning) return;
            _panning = false;
            Viewport.ReleaseMouseCapture();
            Viewport.Cursor = null;
            // Простой щелчок без перетаскивания по краям — навигация
            var p = e.GetPosition(Viewport);
            if (Math.Abs(p.X - _panStart.X) < 3 && Math.Abs(p.Y - _panStart.Y) < 3 && _fitMode && !_editMode)
            {
                double w = Viewport.ActualWidth;
                if (p.X < w * 0.12) Navigate(-1);
                else if (p.X > w * 0.88) Navigate(+1);
            }
        }

        private void BtnZoomIn_Click(object sender, RoutedEventArgs e) => ZoomAt(1.25, ViewCenter);
        private void BtnZoomOut_Click(object sender, RoutedEventArgs e) => ZoomAt(1 / 1.25, ViewCenter);
        private void BtnFit_Click(object sender, RoutedEventArgs e) { _fitMode = true; UpdateLayoutImage(); }

        private void BtnZoomToggle_Click(object sender, RoutedEventArgs e)
        {
            if (_fitMode) ZoomToActual(ViewCenter);
            else { _fitMode = true; UpdateLayoutImage(); }
        }

        private void RotateView(int deg)
        {
            if (Img.Source == null) return;
            _viewRotation = ((_viewRotation + deg) % 360 + 360) % 360;
            Img.LayoutTransform = _viewRotation == 0 ? Transform.Identity : new RotateTransform(_viewRotation);
            _fitMode = true;
            UpdateLayoutImage();
            if (_viewRotation != 0) ShowToast("Поворот только для просмотра. Чтобы сохранить — используйте «Поворот на 90°» в редакторе.");
        }

        private void BtnRotateLeft_Click(object sender, RoutedEventArgs e) => RotateView(-90);
        private void BtnRotateRight_Click(object sender, RoutedEventArgs e) => RotateView(90);

        private void FadeIn()
        {
            if (!S.Animations) { Img.Opacity = 1; return; }
            Img.BeginAnimation(OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(170)) { EasingFunction = new QuadraticEase() });
        }

        // =====================================================================
        //  Анимация GIF / WebP
        // =====================================================================

        private void StartAnimation()
        {
            if (_current?.Frames == null || _current.Frames.Count < 2) return;
            _animIndex = 0;
            _animTimer.Interval = TimeSpan.FromMilliseconds(_current.Frames[0].DelayMs);
            _animTimer.Start();
        }

        private void StopAnimation() => _animTimer.Stop();

        private void AnimTimer_Tick(object sender, EventArgs e)
        {
            var frames = _current?.Frames;
            if (frames == null || frames.Count < 2 || _editMode) { _animTimer.Stop(); return; }
            _animIndex = (_animIndex + 1) % frames.Count;
            Img.Source = frames[_animIndex].Bitmap;
            _animTimer.Interval = TimeSpan.FromMilliseconds(frames[_animIndex].DelayMs);
        }

        // =====================================================================
        //  Интерфейс: информация, ошибки, уведомления
        // =====================================================================

        private void UpdateInfo()
        {
            if (_current == null) { InfoText.Text = ""; return; }
            var d = _current;
            string anim = d.IsAnimated ? $" · анимация {d.Frames.Count} кадр." : "";
            InfoText.Text = $"{d.OriginalWidth}×{d.OriginalHeight} · {d.Megapixels:0.#} МП · {d.FormatName} · {MetadataService.FormatSize(d.FileSize)}{anim}";
        }

        private void UpdateUiState()
        {
            bool has = _current != null;
            bool any = _files.Count > 0;
            NavPrev.Visibility = NavNext.Visibility = _files.Count > 1 && !_editMode ? Visibility.Visible : Visibility.Collapsed;
            BottomBar.Visibility = any ? Visibility.Visible : Visibility.Collapsed;
            InfoOverlay.Visibility = S.ShowInfoOverlay && has ? Visibility.Visible : Visibility.Collapsed;
            IndexChip.Visibility = _files.Count > 1 ? Visibility.Visible : Visibility.Collapsed;
            if (!any) EmptyState.Visibility = Visibility.Visible;
            BtnEditTop.IsChecked = BtnEditBar.IsChecked = _editMode;
            BtnSaveTop.Visibility = _editMode ? Visibility.Visible : Visibility.Collapsed;
            EditChip.Visibility = _editMode ? Visibility.Visible : Visibility.Collapsed;
            ThumbBar.Visibility = S.ShowThumbnails && !_fullscreen && _files.Count > 1 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ShowError(string title, string text, bool security)
        {
            ErrorIcon.Text = security ? "🛡" : "⚠";
            ErrorIcon.Foreground = (Brush)FindResource(security ? "AccentBrush" : "WarnBrush");
            ErrorTitle.Text = title;
            ErrorText.Text = text;
            ErrorPanel.Visibility = Visibility.Visible;
            EmptyState.Visibility = Visibility.Collapsed;
            InfoOverlay.Visibility = Visibility.Collapsed;
        }

        private void ShowLoading(bool on)
        {
            LoadingPanel.Visibility = on ? Visibility.Visible : Visibility.Collapsed;
            if (on)
                SpinRotate.BeginAnimation(RotateTransform.AngleProperty, new DoubleAnimation(0, 360, TimeSpan.FromSeconds(0.9)) { RepeatBehavior = RepeatBehavior.Forever });
            else
                SpinRotate.BeginAnimation(RotateTransform.AngleProperty, null);
        }

        private void ShowBusy(string text)
        {
            LoadingText.Text = text;
            ShowLoading(true);
        }

        public void ShowToast(string text, bool error = false)
        {
            ToastText.Text = text;
            Toast.BorderBrush = (Brush)FindResource(error ? "DangerBrush" : "AccentBrush");
            Toast.Visibility = Visibility.Visible;
            if (S.Animations) Toast.BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromMilliseconds(150)));
            else { Toast.BeginAnimation(OpacityProperty, null); Toast.Opacity = 1; }
            _toastTimer.Stop();
            _toastTimer.Interval = TimeSpan.FromSeconds(Math.Clamp(text.Length / 18.0, 2.5, 7));
            _toastTimer.Start();
        }

        private void HideToast()
        {
            _toastTimer.Stop();
            if (!S.Animations) { Toast.Visibility = Visibility.Collapsed; return; }
            var a = new DoubleAnimation(0, TimeSpan.FromMilliseconds(250));
            a.Completed += (s, e) => { if (Toast.Opacity < 0.05) Toast.Visibility = Visibility.Collapsed; };
            Toast.BeginAnimation(OpacityProperty, a);
        }

        private void SetChromeVisible(bool visible)
        {
            double target = visible ? 1 : 0;
            foreach (var el in new UIElement[] { BottomBar, NavPrev, NavNext, InfoOverlay })
            {
                if (S.Animations) el.BeginAnimation(OpacityProperty, new DoubleAnimation(target, TimeSpan.FromMilliseconds(200)));
                else { el.BeginAnimation(OpacityProperty, null); el.Opacity = target; }
                el.IsHitTestVisible = visible && el != InfoOverlay;
            }
            Mouse.OverrideCursor = !visible && _fullscreen ? Cursors.None : null;
        }

        // =====================================================================
        //  Окно
        // =====================================================================

        private void BtnMin_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void BtnMax_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();

        private void BtnFullscreen_Click(object sender, RoutedEventArgs e) => ToggleFullscreen();

        private void ToggleFullscreen()
        {
            if (!_fullscreen)
            {
                _restoreState = WindowState;
                _restoreBounds = WindowState == WindowState.Normal ? new Rect(Left, Top, Width, Height) : RestoreBounds;
                _fullscreen = true;
                TitleBar.Visibility = Visibility.Collapsed;
                ThumbBar.Visibility = Visibility.Collapsed;
                RootGrid.Margin = new Thickness(0);
                var hwnd = new WindowInteropHelper(this).Handle;
                var mon = Native.GetMonitorBounds(hwnd);
                WindowState = WindowState.Normal;
                ResizeMode = ResizeMode.NoResize;
                if (mon.HasValue)
                {
                    double dpi = DpiScale;
                    var r = mon.Value;
                    Left = r.Left / dpi; Top = r.Top / dpi;
                    Width = (r.Right - r.Left) / dpi; Height = (r.Bottom - r.Top) / dpi;
                }
                else WindowState = WindowState.Maximized;
                Topmost = true;
                BtnFull.Content = "";
                _idleTimer.Start();
            }
            else
            {
                _fullscreen = false;
                Topmost = false;
                ResizeMode = ResizeMode.CanResize;
                TitleBar.Visibility = Visibility.Visible;
                Left = _restoreBounds.Left; Top = _restoreBounds.Top;
                Width = _restoreBounds.Width; Height = _restoreBounds.Height;
                WindowState = _restoreState == WindowState.Maximized ? WindowState.Maximized : WindowState.Normal;
                BtnFull.Content = "";
                _idleTimer.Stop();
                SetChromeVisible(true);
                UpdateUiState();
                UpdateMaxState();
            }
            _fitMode = true;
            Dispatcher.BeginInvoke(new Action(UpdateLayoutImage), DispatcherPriority.Loaded);
        }

        // =====================================================================
        //  Слайд-шоу
        // =====================================================================

        private void BtnSlideshow_Click(object sender, RoutedEventArgs e)
        {
            if (_slideTimer.IsEnabled) StopSlideshow();
            else StartSlideshow();
        }

        private void StartSlideshow()
        {
            if (_files.Count < 2) { BtnSlides.IsChecked = false; ShowToast("Для слайд-шоу нужно хотя бы два изображения в папке."); return; }
            if (_editMode && !ExitEditMode(false)) { BtnSlides.IsChecked = false; return; }
            _slideTimer.Interval = TimeSpan.FromSeconds(S.SlideshowSeconds);
            _slideTimer.Start();
            BtnSlides.IsChecked = true;
            if (!_fullscreen) ToggleFullscreen();
            ShowToast($"Слайд-шоу: каждые {S.SlideshowSeconds:0.#} с. Пробел или F5 — остановить, Esc — выйти.");
        }

        private void StopSlideshow()
        {
            if (!_slideTimer.IsEnabled) { BtnSlides.IsChecked = false; return; }
            _slideTimer.Stop();
            BtnSlides.IsChecked = false;
            ShowToast("Слайд-шоу остановлено.");
        }

        // =====================================================================
        //  Действия с файлом
        // =====================================================================

        private void ViewMenu_Opened(object sender, RoutedEventArgs e)
        {
            bool has = _currentPath != null && File.Exists(_currentPath);
            MiCopy.IsEnabled = Img.Source is BitmapSource;
            MiCopyPath.IsEnabled = MiShow.IsEnabled = MiRename.IsEnabled = MiDelete.IsEnabled = MiInfo.IsEnabled = has;
            MiPrint.IsEnabled = MiEdit.IsEnabled = has && _current != null;
            MiSlides.IsEnabled = _files.Count > 1;
        }

        private void MenuCopy_Click(object sender, RoutedEventArgs e) => CopyImage();

        private void CopyImage()
        {
            if (Img.Source is BitmapSource b)
            {
                try { Clipboard.SetImage(b); ShowToast("Изображение скопировано в буфер обмена."); }
                catch (Exception ex) { ShowToast("Буфер обмена недоступен: " + ex.Message, true); }
            }
        }

        private void MenuCopyPath_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPath == null) return;
            try { Clipboard.SetText(_currentPath); ShowToast("Путь скопирован."); } catch { }
        }

        private void MenuShowInFolder_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPath == null || !File.Exists(_currentPath)) return;
            try
            {
                var psi = new ProcessStartInfo(IOPath.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe"))
                { UseShellExecute = false, Arguments = "/select,\"" + _currentPath + "\"" };
                Process.Start(psi);
            }
            catch (Exception ex) { ShowToast("Не удалось открыть Проводник: " + ex.Message, true); }
        }

        private void MenuRename_Click(object sender, RoutedEventArgs e) => RenameCurrent();

        private void RenameCurrent()
        {
            if (_currentPath == null || !File.Exists(_currentPath) || _editMode) return;
            string oldName = IOPath.GetFileName(_currentPath);
            string n = NeonDialog.Prompt(this, "Переименовать", "Новое имя файла:", oldName);
            if (string.IsNullOrWhiteSpace(n) || n == oldName) return;
            n = n.Trim();
            if (n.IndexOfAny(IOPath.GetInvalidFileNameChars()) >= 0 || n.EndsWith(".") || n.Length > 240)
            {
                ShowToast("Недопустимое имя файла.", true);
                return;
            }
            string oldExt = IOPath.GetExtension(oldName), newExt = IOPath.GetExtension(n);
            if (!string.Equals(oldExt, newExt, StringComparison.OrdinalIgnoreCase) &&
                !NeonDialog.Confirm(this, "Смена расширения", $"Вы меняете расширение с «{oldExt}» на «{newExt}». Содержимое файла при этом не изменится. Продолжить?"))
                return;
            string target = IOPath.Combine(IOPath.GetDirectoryName(_currentPath) ?? "", n);
            if (File.Exists(target)) { ShowToast("Файл с таким именем уже существует.", true); return; }
            try
            {
                StopAnimation();
                File.Move(_currentPath, target);
                ReloadFolder(target);
                ShowToast("Файл переименован.");
            }
            catch (Exception ex) { ShowToast("Не удалось переименовать: " + ex.Message, true); }
        }

        private void MenuPrint_Click(object sender, RoutedEventArgs e) => PrintCurrent();

        private void PrintCurrent()
        {
            if (!(Img.Source is BitmapSource bmp)) return;
            try
            {
                var pd = new PrintDialog();
                if (pd.ShowDialog() != true) return;
                double pw = pd.PrintableAreaWidth, ph = pd.PrintableAreaHeight;
                bool landscape = bmp.PixelWidth > bmp.PixelHeight;
                var img = new Image { Source = bmp, Stretch = Stretch.Uniform };
                RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
                var root = new Grid { Width = pw, Height = ph, Background = Brushes.White };
                img.Margin = new Thickness(24);
                if (landscape && ph > pw) img.LayoutTransform = new RotateTransform(90);
                root.Children.Add(img);
                root.Measure(new Size(pw, ph));
                root.Arrange(new Rect(0, 0, pw, ph));
                root.UpdateLayout();
                pd.PrintVisual(root, "NeonView — " + IOPath.GetFileName(_currentPath));
            }
            catch (Exception ex) { ShowToast("Ошибка печати: " + ex.Message, true); }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e) => DeleteCurrent();

        private void DeleteCurrent()
        {
            if (_currentPath == null || !File.Exists(_currentPath)) return;
            if (_editMode && !ExitEditMode(false)) return;
            if (S.ConfirmDelete &&
                !NeonDialog.Confirm(this, "Удалить в корзину?", IOPath.GetFileName(_currentPath) + "\n\nФайл можно будет восстановить из Корзины.", "Удалить", "Отмена", "🗑"))
                return;
            string path = _currentPath;
            StopAnimation();
            Img.Source = null;
            bool ok = false;
            try { ok = Native.MoveToRecycleBin(path, new WindowInteropHelper(this).Handle); } catch { }
            if (!ok)
            {
                ShowToast("Не удалось удалить файл (возможно, он открыт в другой программе или нет прав).", true);
                if (_current != null) SetSource(_current.Bitmap, false);
                return;
            }
            int idx = _index;
            _files.RemoveAt(idx);
            if (idx < _thumbs.Count) _thumbs.RemoveAt(idx);
            _preload.Clear();
            ShowToast("Перемещено в корзину.");
            if (_files.Count == 0) { ClearView(); ApplySettings(); return; }
            ApplySettings();
            _ = LoadIndex(Math.Min(idx, _files.Count - 1));
        }

        private void BtnInfo_Click(object sender, RoutedEventArgs e) => ShowProperties();

        private void ShowProperties()
        {
            if (_currentPath == null || !File.Exists(_currentPath)) return;
            var w = new PropertiesWindow(_currentPath, _current, Img.Source as BitmapSource) { Owner = this };
            w.MetadataChanged += () =>
            {
                _preload.Clear();
                if (!_editMode) _ = LoadIndex(_index);
            };
            w.FileCreated += p => ReloadFolder(p);
            w.Show();
        }

        private void BtnSettings_Click(object sender, RoutedEventArgs e)
        {
            var w = new SettingsWindow { Owner = this };
            w.ShowDialog();
            if (_folder != null && w.SortChanged && !_editMode) ReloadFolder(_currentPath);
        }

        // =====================================================================
        //  Клавиатура
        // =====================================================================

        private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            var focused = Keyboard.FocusedElement;
            if (focused is TextBox) return;
            bool inControl = focused is Slider || focused is ComboBox || focused is ListBoxItem lbi && ItemsControl.ItemsControlFromItemContainer(lbi) != ThumbList;
            var mods = Keyboard.Modifiers;
            bool ctrl = (mods & ModifierKeys.Control) != 0, shift = (mods & ModifierKeys.Shift) != 0;
            Key key = e.Key == Key.System ? e.SystemKey : e.Key;

            if (ctrl)
            {
                switch (key)
                {
                    case Key.O: BtnOpen_Click(this, null); e.Handled = true; return;
                    case Key.S:
                        if (_editMode) { if (shift) SaveAs(); else _ = SaveEdits(SaveMode.Copy, null, null); }
                        e.Handled = true; return;
                    case Key.Z: if (_editMode) { Undo(); e.Handled = true; } return;
                    case Key.Y: if (_editMode) { Redo(); e.Handled = true; } return;
                    case Key.C:
                        if (shift) MenuCopyPath_Click(this, null); else CopyImage();
                        e.Handled = true; return;
                    case Key.P: PrintCurrent(); e.Handled = true; return;
                    case Key.OemComma: BtnSettings_Click(this, null); e.Handled = true; return;
                    case Key.D0: case Key.NumPad0: _fitMode = true; UpdateLayoutImage(); e.Handled = true; return;
                    case Key.OemPlus: case Key.Add: ZoomAt(1.25, ViewCenter); e.Handled = true; return;
                    case Key.OemMinus: case Key.Subtract: ZoomAt(1 / 1.25, ViewCenter); e.Handled = true; return;
                }
                return;
            }

            if (key == Key.Escape)
            {
                if (_slideTimer.IsEnabled) { StopSlideshow(); if (_fullscreen) ToggleFullscreen(); }
                else if (_fullscreen) ToggleFullscreen();
                else if (_editMode) ExitEditMode(false);
                e.Handled = true;
                return;
            }
            if (inControl && (key == Key.Left || key == Key.Right || key == Key.Up || key == Key.Down || key == Key.Home || key == Key.End || key == Key.PageUp || key == Key.PageDown)) return;

            switch (key)
            {
                case Key.Left: case Key.PageUp: if (!_editMode) Navigate(-1); e.Handled = true; break;
                case Key.Right: case Key.PageDown: if (!_editMode) Navigate(+1); e.Handled = true; break;
                case Key.Home: if (!_editMode && _files.Count > 0 && ConfirmLeaveEdit()) _ = LoadIndex(0); e.Handled = true; break;
                case Key.End: if (!_editMode && _files.Count > 0 && ConfirmLeaveEdit()) _ = LoadIndex(_files.Count - 1); e.Handled = true; break;
                case Key.Space:
                    if (_slideTimer.IsEnabled) StopSlideshow(); else if (!_editMode) Navigate(+1);
                    e.Handled = true; break;
                case Key.F11: ToggleFullscreen(); e.Handled = true; break;
                case Key.F5: BtnSlideshow_Click(this, null); e.Handled = true; break;
                case Key.F2: RenameCurrent(); e.Handled = true; break;
                case Key.Delete: DeleteCurrent(); e.Handled = true; break;
                case Key.E: ToggleEdit(); e.Handled = true; break;
                case Key.I: ShowProperties(); e.Handled = true; break;
                case Key.R: RotateView(shift ? -90 : 90); e.Handled = true; break;
                case Key.D0: case Key.NumPad0: _fitMode = true; UpdateLayoutImage(); e.Handled = true; break;
                case Key.D1: case Key.NumPad1: ZoomToActual(ViewCenter); e.Handled = true; break;
                case Key.OemPlus: case Key.Add: ZoomAt(1.25, ViewCenter); e.Handled = true; break;
                case Key.OemMinus: case Key.Subtract: ZoomAt(1 / 1.25, ViewCenter); e.Handled = true; break;
                case Key.Enter: if ((mods & ModifierKeys.Alt) != 0) { ShowProperties(); e.Handled = true; } break;
            }
        }

        // =====================================================================
        //  РЕДАКТОР
        // =====================================================================

        private void BuildCategories()
        {
            CategoryPanel.Children.Clear();
            foreach (var c in ToolCatalog.Categories)
            {
                var rb = new RadioButton { Content = c, GroupName = "cat", Style = (Style)FindResource("ChipRadio"), IsChecked = c == _category };
                string cat = c;
                rb.Checked += (s, e) => { _category = cat; FillToolList(); };
                CategoryPanel.Children.Add(rb);
            }
            FillToolList();
        }

        private void FillToolList()
        {
            ToolList.ItemsSource = ToolCatalog.Tools.Where(t => t.Category == _category).ToList();
            ToolList.SelectedItem = _tool != null && _tool.Category == _category ? _tool : null;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e) => ToggleEdit();

        private void ToggleEdit()
        {
            if (_editMode) ExitEditMode(false);
            else _ = EnterEditMode();
            UpdateUiState();
        }

        private bool ConfirmLeaveEdit()
        {
            if (!_editMode) return true;
            return ExitEditMode(false);
        }

        private async Task EnterEditMode()
        {
            UpdateUiState();
            if (_current == null || _currentPath == null || _editMode) return;
            StopSlideshow();
            string path = _currentPath;
            ShowBusy("Подготовка редактора…");
            IMagickImageU baseImg;
            BitmapSource baseBmp;
            int previewSide = S.PreviewMaxSide;
            long max = S.MaxFileBytes;
            try
            {
                (baseImg, baseBmp) = await Task.Run(() =>
                {
                    var img = ImageLoader.DecodeMagick(path, previewSide, max);
                    return (img, ImageLoader.ToBitmapSource(img));
                });
            }
            catch (Exception ex)
            {
                ShowLoading(false);
                ShowToast("Не удалось открыть в редакторе: " + ex.Message, true);
                UpdateUiState();
                return;
            }
            ShowLoading(false);
            if (path != _currentPath) { baseImg.Dispose(); return; }

            StopAnimation();
            _editBase = baseImg;
            _editOriginalBitmap = baseBmp;
            _editScale = _current.OriginalWidth > 0 ? baseImg.Width / (double)_current.OriginalWidth : 1;
            if (_editScale <= 0 || _editScale > 1) _editScale = 1;
            _ops.Clear(); _redo.Clear(); _opsVersion++;
            _tool = null; _toolValues = null;
            _editMode = true;
            _viewRotation = 0;
            Img.LayoutTransform = Transform.Identity;
            EditPanel.Visibility = Visibility.Visible;
            ShowToolDetails();
            RefreshHistory();
            UpdateUiState();
            SetSource(baseBmp, true);
            if (_current.IsAnimated) ShowToast("Анимация: правки применяются к первому кадру, результат сохраняется как статичное изображение.");
            else if (_current.Detect?.IsSvg == true) ShowToast("SVG будет растеризован (сохранён как обычное изображение).");
        }

        /// <summary>Выход из редактора. Возвращает false, если пользователь отменил.</summary>
        private bool ExitEditMode(bool force)
        {
            if (!_editMode) return true;
            if (!force && _ops.Count > 0)
            {
                int r = NeonDialog.Show(this, "Выйти из редактора?", $"Несохранённых правок: {_ops.Count}. Они будут потеряны.", "⚠", 0, "Сохранить копию", "Выйти без сохранения", "Остаться");
                if (r == 0) { _ = SaveEdits(SaveMode.Copy, null, null); return false; }
                if (r != 1) return false;
            }
            _editMode = false;
            _previewVersion++;
            var b = _editBase; var c = _appliedCache;
            _editBase = null; _appliedCache = null; _appliedCacheVersion = -1;
            _ = Task.Run(async () =>
            {
                await _renderGate.WaitAsync();
                try { c?.Dispose(); b?.Dispose(); } finally { _renderGate.Release(); }
            });
            _ops.Clear(); _redo.Clear();
            _tool = null; _toolValues = null;
            _editBitmap = null; _editOriginalBitmap = null;
            EditPanel.Visibility = Visibility.Collapsed;
            EditBusy.Visibility = Visibility.Collapsed;
            ToolList.SelectedItem = null;
            UpdateUiState();
            if (_current != null)
            {
                SetSource(_current.Bitmap, true);
                if (_current.IsAnimated) StartAnimation();
            }
            return true;
        }

        private void ToolList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ToolList.SelectedItem is ToolDef t)
            {
                if (t == _tool) return;
                _tool = t;
                _toolValues = t.Defaults();
            }
            else
            {
                if (_tool != null && _tool.Category != _category) return; // просто сменили категорию
                _tool = null;
                _toolValues = null;
            }
            ShowToolDetails();
            RequestPreview();
        }

        private void ShowToolDetails()
        {
            ParamsPanel.Children.Clear();
            if (_tool == null)
            {
                ToolTitle.Text = "Выберите инструмент";
                ToolExplain.Text = "Каждый инструмент сопровождается пояснением. Двигайте ползунки — результат сразу виден на снимке. Нажмите «Применить», чтобы добавить правку в историю. Двойной щелчок по ползунку сбрасывает его.";
                ToolTipBox.Visibility = Visibility.Collapsed;
                ToolButtons.Visibility = Visibility.Collapsed;
                return;
            }
            ToolTitle.Text = _tool.Name;
            ToolExplain.Text = _tool.Explanation;
            ToolTipText.Text = "💡 " + _tool.Tip;
            ToolTipBox.Visibility = string.IsNullOrEmpty(_tool.Tip) ? Visibility.Collapsed : Visibility.Visible;
            ToolButtons.Visibility = Visibility.Visible;

            for (int i = 0; i < _tool.Params.Count; i++)
            {
                int idx = i;
                var p = _tool.Params[i];
                var head = new DockPanel { Margin = new Thickness(0, 10, 0, 2) };
                var val = new TextBlock { FontWeight = FontWeights.SemiBold, Text = p.Format(_toolValues[idx]) };
                val.SetResourceReference(TextBlock.ForegroundProperty, "AccentBrush");
                DockPanel.SetDock(val, Dock.Right);
                head.Children.Add(val);
                head.Children.Add(new TextBlock { Text = p.Label });
                ParamsPanel.Children.Add(head);

                if (p.Kind == ParamKind.Choice)
                {
                    var cb = new ComboBox { ItemsSource = p.Options, SelectedIndex = (int)Math.Round(_toolValues[idx]) };
                    cb.SelectionChanged += (s, e) =>
                    {
                        if (_toolValues == null || cb.SelectedIndex < 0) return;
                        _toolValues[idx] = cb.SelectedIndex;
                        val.Text = p.Format(cb.SelectedIndex);
                        RequestPreview();
                    };
                    ParamsPanel.Children.Add(cb);
                }
                else
                {
                    var sl = new Slider
                    {
                        Minimum = p.Min, Maximum = p.Max, Value = _toolValues[idx],
                        SmallChange = p.Step, LargeChange = Math.Max(p.Step * 10, (p.Max - p.Min) / 20),
                        TickFrequency = p.Step, IsSnapToTickEnabled = true,
                        ToolTip = "Двойной щелчок — сбросить"
                    };
                    sl.ValueChanged += (s, e) =>
                    {
                        if (_toolValues == null) return;
                        _toolValues[idx] = e.NewValue;
                        val.Text = p.Format(e.NewValue);
                        _previewDebounce.Stop();
                        _previewDebounce.Start();
                    };
                    sl.MouseDoubleClick += (s, e) => { sl.Value = p.Default; e.Handled = true; };
                    ParamsPanel.Children.Add(sl);
                }
                if (!string.IsNullOrEmpty(p.Hint))
                    ParamsPanel.Children.Add(new TextBlock { Text = p.Hint, Style = (Style)FindResource("Sub"), FontSize = 11 });
            }
            if (_tool.Params.Count == 0)
            {
                var t = new TextBlock { Text = "У этого инструмента нет настроек — результат уже показан на снимке. Нажмите «Применить».", Style = (Style)FindResource("Sub"), Margin = new Thickness(0, 10, 0, 0) };
                ParamsPanel.Children.Add(t);
            }
        }

        private void BtnApplyTool_Click(object sender, RoutedEventArgs e)
        {
            if (!_editMode || _tool == null) return;
            _ops.Add(new EditOp(_tool, (double[])_toolValues.Clone()));
            _redo.Clear();
            _opsVersion++;
            ShowToast("Применено: " + _ops[^1].Title);
            _tool = null; _toolValues = null;
            ToolList.SelectedItem = null;
            ShowToolDetails();
            RefreshHistory();
            RequestPreview();
        }

        private void BtnResetTool_Click(object sender, RoutedEventArgs e)
        {
            if (_tool == null) return;
            _toolValues = _tool.Defaults();
            ShowToolDetails();
            RequestPreview();
        }

        private void BtnCancelTool_Click(object sender, RoutedEventArgs e)
        {
            _tool = null; _toolValues = null;
            ToolList.SelectedItem = null;
            ShowToolDetails();
            RequestPreview();
        }

        private void BtnUndo_Click(object sender, RoutedEventArgs e) => Undo();
        private void BtnRedo_Click(object sender, RoutedEventArgs e) => Redo();

        private void Undo()
        {
            if (_ops.Count == 0) return;
            _redo.Push(_ops[^1]);
            _ops.RemoveAt(_ops.Count - 1);
            _opsVersion++;
            RefreshHistory();
            RequestPreview();
        }

        private void Redo()
        {
            if (_redo.Count == 0) return;
            _ops.Add(_redo.Pop());
            _opsVersion++;
            RefreshHistory();
            RequestPreview();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            if (_ops.Count == 0) return;
            if (!NeonDialog.Confirm(this, "Сбросить все правки?", "Изображение вернётся к исходному виду.")) return;
            _ops.Clear(); _redo.Clear(); _opsVersion++;
            RefreshHistory();
            RequestPreview();
        }

        private void RefreshHistory()
        {
            HistoryList.ItemsSource = _ops.Select((o, i) => $"{i + 1}. {o.Title}").ToList();
            if (_ops.Count > 0) HistoryList.ScrollIntoView(HistoryList.Items[HistoryList.Items.Count - 1]);
            HistoryEmpty.Visibility = _ops.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            BtnUndo.IsEnabled = _ops.Count > 0;
            BtnRedo.IsEnabled = _redo.Count > 0;
            EditChipText.Text = _ops.Count > 0 ? $"Предпросмотр правок · {_ops.Count}" : "Режим редактирования";
        }

        private async void RequestPreview()
        {
            if (!_editMode || _editBase == null) return;
            int v = ++_previewVersion;
            var ops = _ops.ToList();
            int opsVersion = _opsVersion;
            EditOp pending = _tool != null && _toolValues != null ? new EditOp(_tool, (double[])_toolValues.Clone()) : null;
            var baseImg = _editBase;
            double scale = _editScale;

            await _renderGate.WaitAsync();
            try
            {
                if (v != _previewVersion || !_editMode || !ReferenceEquals(baseImg, _editBase)) return;
                EditBusy.Visibility = Visibility.Visible;
                BitmapSource bmp = await Task.Run(() =>
                {
                    var ctx = new EditContext { Scale = scale };
                    if (_appliedCacheVersion != opsVersion || _appliedCache == null)
                    {
                        _appliedCache?.Dispose();
                        _appliedCache = null;
                        var c = baseImg.Clone();
                        foreach (var op in ops) op.Run(c, ctx);
                        _appliedCache = c;
                        _appliedCacheVersion = opsVersion;
                    }
                    if (pending == null) return ImageLoader.ToBitmapSource(_appliedCache);
                    using var img = _appliedCache.Clone();
                    pending.Run(img, ctx);
                    return ImageLoader.ToBitmapSource(img);
                });
                if (!_editMode || !ReferenceEquals(baseImg, _editBase)) return;
                _editBitmap = bmp;
                if (!_comparing) SetSource(bmp, false);
            }
            catch (Exception ex)
            {
                ShowToast("Не удалось применить эффект: " + ex.Message, true);
            }
            finally
            {
                _renderGate.Release();
                if (v == _previewVersion) EditBusy.Visibility = Visibility.Collapsed;
            }
        }

        private void BtnCompare_Down(object sender, MouseButtonEventArgs e)
        {
            if (!_editMode || _editOriginalBitmap == null) return;
            _comparing = true;
            SetSource(_editOriginalBitmap, false);
            EditChipText.Text = "Оригинал";
        }

        private void BtnCompare_Up(object sender, MouseEventArgs e)
        {
            if (!_comparing) return;
            _comparing = false;
            if (_editBitmap != null) SetSource(_editBitmap, false);
            RefreshHistory();
        }

        // ---------------- Сохранение ----------------

        private enum SaveMode { Copy, As }

        private static readonly (string Name, string Ext, MagickFormat Fmt, bool Lossy)[] SaveFormats =
        {
            ("JPEG", ".jpg", MagickFormat.Jpeg, true),
            ("PNG (без потерь)", ".png", MagickFormat.Png, false),
            ("WebP", ".webp", MagickFormat.WebP, true),
            ("AVIF", ".avif", MagickFormat.Avif, true),
            ("TIFF (без потерь)", ".tif", MagickFormat.Tiff, false),
            ("BMP", ".bmp", MagickFormat.Bmp, false),
            ("JPEG XL", ".jxl", MagickFormat.Jxl, true),
        };

        private (string ext, MagickFormat fmt) DefaultSaveFormat()
        {
            switch (_current?.Detect?.MagickFormat)
            {
                case "Png": return (".png", MagickFormat.Png);
                case "WebP": return (".webp", MagickFormat.WebP);
                case "Avif": return (".avif", MagickFormat.Avif);
                case "Tiff": return (".tif", MagickFormat.Tiff);
                case "Bmp": return (".bmp", MagickFormat.Bmp);
                case "Jxl": return (".jxl", MagickFormat.Jxl);
                case "Svg":
                case "Gif":
                case "Ico":
                case "Psd": return (".png", MagickFormat.Png);
                default: return (".jpg", MagickFormat.Jpeg);
            }
        }

        private void BtnSaveCopy_Click(object sender, RoutedEventArgs e) => _ = SaveEdits(SaveMode.Copy, null, null);
        private void BtnSaveAs_Click(object sender, RoutedEventArgs e) => SaveAs();

        private void SaveAs()
        {
            if (!_editMode || _currentPath == null) return;
            var def = DefaultSaveFormat();
            var dlg = new SaveFileDialog
            {
                Title = "Сохранить изображение как",
                Filter = string.Join("|", SaveFormats.Select(f => $"{f.Name}|*{f.Ext}")),
                FilterIndex = Math.Max(1, Array.FindIndex(SaveFormats, f => f.Fmt == def.fmt) + 1),
                FileName = IOPath.GetFileNameWithoutExtension(_currentPath) + "_neon",
                InitialDirectory = IOPath.GetDirectoryName(_currentPath),
                AddExtension = true,
                OverwritePrompt = true
            };
            if (dlg.ShowDialog(this) != true) return;
            var chosen = SaveFormats[Math.Clamp(dlg.FilterIndex - 1, 0, SaveFormats.Length - 1)];
            string target = dlg.FileName;
            if (!target.EndsWith(chosen.Ext, StringComparison.OrdinalIgnoreCase) &&
                !(chosen.Fmt == MagickFormat.Jpeg && target.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase)) &&
                !(chosen.Fmt == MagickFormat.Tiff && target.EndsWith(".tiff", StringComparison.OrdinalIgnoreCase)))
                target += chosen.Ext;
            if (string.Equals(IOPath.GetFullPath(target), IOPath.GetFullPath(_currentPath), StringComparison.OrdinalIgnoreCase) &&
                !NeonDialog.Confirm(this, "Перезаписать оригинал?", "Вы выбрали исходный файл. Оригинал будет заменён отредактированной версией без возможности отмены.", "Перезаписать", "Отмена"))
                return;
            _ = SaveEdits(SaveMode.As, target, chosen.Fmt);
        }

        private async Task SaveEdits(SaveMode mode, string target, MagickFormat? fmt)
        {
            if (!_editMode || _currentPath == null) return;
            if (_tool != null && _toolValues != null)
            {
                int r = NeonDialog.Show(this, "Незавершённая правка", $"Инструмент «{_tool.Name}» настроен, но не применён. Применить его перед сохранением?", "?", 0, "Применить", "Не применять", "Отмена");
                if (r == 2 || r < 0) return;
                if (r == 0) BtnApplyTool_Click(this, null);
            }
            if (_ops.Count == 0) { ShowToast("Нет правок для сохранения."); return; }

            string src = _currentPath;
            if (mode == SaveMode.Copy || target == null)
            {
                var def = DefaultSaveFormat();
                fmt = def.fmt;
                target = MetadataWriter.UniquePath(IOPath.GetDirectoryName(src) ?? "", IOPath.GetFileNameWithoutExtension(src) + "_neon", def.ext);
            }
            var ops = _ops.ToList();
            int quality = S.JpegQuality;
            bool strip = S.StripMetadataOnSave;
            long max = S.MaxFileBytes;
            MagickFormat f = fmt ?? MagickFormat.Jpeg;

            ShowBusy("Сохранение в полном разрешении…");
            IsEnabled = false;
            try
            {
                await Task.Run(() =>
                {
                    using var img = ImageLoader.DecodeMagick(src, 0, max);
                    var ctx = new EditContext { Scale = 1 };
                    foreach (var op in ops) op.Run(img, ctx);
                    if (strip)
                    {
                        var cp = img.GetColorProfile();
                        img.Strip();
                        if (cp != null) { try { img.SetProfile(cp); } catch { } }
                    }
                    else
                    {
                        // Ориентация уже применена к пикселям
                        try { var exif = img.GetExifProfile(); if (exif != null) { exif.SetValue(ExifTag.Orientation, (ushort)1); img.SetProfile(exif); } } catch { }
                    }
                    img.Quality = quality;
                    if (f == MagickFormat.Jpeg && img.HasAlpha)
                    {
                        img.BackgroundColor = MagickColors.White;
                        img.Alpha(AlphaOption.Remove);
                    }
                    string dir = IOPath.GetDirectoryName(target) ?? ".";
                    string tmp = IOPath.Combine(dir, "." + Guid.NewGuid().ToString("N").Substring(0, 10) + ".neontmp");
                    try
                    {
                        img.Write(tmp, f);
                        File.SetAttributes(tmp, FileAttributes.Hidden);
                        if (File.Exists(target)) File.Replace(tmp, target, null, true);
                        else File.Move(tmp, target);
                        try { File.SetAttributes(target, File.GetAttributes(target) & ~FileAttributes.Hidden); } catch { }
                    }
                    finally
                    {
                        try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
                    }
                });
            }
            catch (Exception ex)
            {
                IsEnabled = true;
                ShowLoading(false);
                NeonDialog.Info(this, "Не удалось сохранить", ex.Message, "⚠");
                return;
            }
            IsEnabled = true;
            ShowLoading(false);
            ExitEditMode(true);
            ShowToast("Сохранено: " + IOPath.GetFileName(target));
            if (string.Equals(IOPath.GetDirectoryName(target), _folder, StringComparison.OrdinalIgnoreCase)) ReloadFolder(target);
            else OpenPath(target);
        }
    }
}
