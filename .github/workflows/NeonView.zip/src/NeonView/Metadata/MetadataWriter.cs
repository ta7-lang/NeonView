using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Media.Imaging;
using NeonView.Imaging;

namespace NeonView.Metadata
{
    /// <summary>
    /// Запись метаданных JPEG/TIFF через Windows Imaging Component.
    /// Сначала пробуется запись «на месте» (без перекодирования пикселей),
    /// затем — перепаковка с сохранением исходных данных изображения.
    /// Файл заменяется атомарно, только после успешной проверки результата.
    /// </summary>
    public static class MetadataWriter
    {
        private static T Try<T>(Func<T> f, T def = default)
        {
            try { return f(); } catch { return def; }
        }

        public static EditableMeta ReadEditable(byte[] data)
        {
            var e = new EditableMeta();
            using var ms = new MemoryStream(data, false);
            var dec = BitmapDecoder.Create(ms, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile | BitmapCreateOptions.DelayCreation, BitmapCacheOption.None);
            if (dec.Frames.Count == 0) return e;
            if (dec.Frames[0].Metadata is not BitmapMetadata md) return e;
            e.Title = Try(() => md.Title) ?? "";
            e.Subject = Try(() => md.Subject) ?? "";
            e.Comment = Try(() => md.Comment) ?? "";
            e.Copyright = Try(() => md.Copyright) ?? "";
            e.DateTaken = Try(() => md.DateTaken) ?? "";
            e.CameraMake = Try(() => md.CameraManufacturer) ?? "";
            e.CameraModel = Try(() => md.CameraModel) ?? "";
            e.Software = Try(() => md.ApplicationName) ?? "";
            e.Rating = Try(() => md.Rating);
            var kw = Try(() => md.Keywords);
            e.Keywords = kw != null ? string.Join("; ", kw) : "";
            var au = Try(() => md.Author);
            e.Authors = au != null ? string.Join("; ", au) : "";
            return e;
        }

        private static ReadOnlyCollection<string> SplitList(string s) =>
            new ReadOnlyCollection<string>((s ?? "").Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim()).Where(x => x.Length > 0).Distinct().ToList());

        private static void ApplyFields(BitmapMetadata md, EditableMeta e, List<string> failed)
        {
            void Set(string name, Action a)
            {
                try { a(); } catch { failed.Add(name); }
            }
            Set("Название", () => { if (!string.IsNullOrWhiteSpace(e.Title)) md.Title = e.Title.Trim(); });
            Set("Тема", () => { if (!string.IsNullOrWhiteSpace(e.Subject)) md.Subject = e.Subject.Trim(); });
            Set("Комментарий", () => { if (!string.IsNullOrWhiteSpace(e.Comment)) md.Comment = e.Comment.Trim(); });
            Set("Авторские права", () => { if (!string.IsNullOrWhiteSpace(e.Copyright)) md.Copyright = e.Copyright.Trim(); });
            Set("Производитель", () => { if (!string.IsNullOrWhiteSpace(e.CameraMake)) md.CameraManufacturer = e.CameraMake.Trim(); });
            Set("Модель", () => { if (!string.IsNullOrWhiteSpace(e.CameraModel)) md.CameraModel = e.CameraModel.Trim(); });
            Set("Оценка", () => md.Rating = Math.Clamp(e.Rating, 0, 5));
            Set("Ключевые слова", () => { var l = SplitList(e.Keywords); if (l.Count > 0) md.Keywords = l; });
            Set("Авторы", () => { var l = SplitList(e.Authors); if (l.Count > 0) md.Author = l; });
            Set("Дата съёмки", () =>
            {
                if (string.IsNullOrWhiteSpace(e.DateTaken)) return;
                if (DateTime.TryParse(e.DateTaken, CultureInfo.CurrentCulture, DateTimeStyles.AllowWhiteSpaces, out var dt) ||
                    DateTime.TryParse(e.DateTaken, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out dt))
                    md.DateTaken = dt.ToString("yyyy-MM-ddTHH:mm:ss", CultureInfo.InvariantCulture);
                else throw new FormatException();
            });
        }

        private static readonly string[] GpsQueries =
        {
            "/app1/ifd/gps",
            "/ifd/gps",
            "/xmp/exif:GPSLatitude", "/xmp/exif:GPSLongitude", "/xmp/exif:GPSAltitude", "/xmp/exif:GPSAltitudeRef",
            "/xmp/exif:GPSVersionID", "/xmp/exif:GPSTimeStamp", "/xmp/exif:GPSMapDatum",
            "/app1/ifd/{ushort=34853}"
        };

        /// <summary>Сохранить поля. Возвращает текст-отчёт.</summary>
        public static string Save(string path, EditableMeta e)
        {
            var failed = new List<string>();
            string mode = Rewrite(path, md => { failed.Clear(); ApplyFields(md, e, failed); });
            return failed.Count == 0 ? $"Метаданные сохранены ({mode})."
                : $"Сохранено ({mode}), но не удалось записать: {string.Join(", ", failed)}.";
        }

        public static string RemoveGps(string path)
        {
            string mode = Rewrite(path, md =>
            {
                foreach (var q in GpsQueries)
                {
                    try { if (md.ContainsQuery(q)) md.RemoveQuery(q); } catch { }
                }
            });
            // Проверяем результат
            try
            {
                var bytes = File.ReadAllBytes(path);
                using var ms = new MemoryStream(bytes, false);
                var dirs = MetadataExtractor.ImageMetadataReader.ReadMetadata(ms);
                bool still = dirs.OfType<MetadataExtractor.Formats.Exif.GpsDirectory>().Any(d => d.Tags.Count > 1);
                if (still) return "GPS-данные удалены частично. Для полной очистки используйте «Удалить все метаданные».";
            }
            catch { }
            return $"Геоданные (GPS) удалены ({mode}).";
        }

        /// <summary>Общая процедура: пробуем запись на месте, иначе перепаковываем.</summary>
        private static string Rewrite(string path, Action<BitmapMetadata> mutate)
        {
            var fi = new FileInfo(path);
            if (!fi.Exists) throw new FileNotFoundException("Файл не найден", path);
            if (fi.IsReadOnly) throw new IOException("Файл доступен только для чтения.");

            byte[] original = File.ReadAllBytes(path);
            var det = FormatDetector.Detect(original, path);
            if (!det.SupportsMetadataEdit) throw new NotSupportedException("Редактирование метаданных поддерживается только для JPEG и TIFF.");

            // 1) Запись «на месте» — пиксели вообще не затрагиваются
            try
            {
                using var fs = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                var dec = BitmapDecoder.Create(fs, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.Default);
                var writer = dec.Frames[0].CreateInPlaceBitmapMetadataWriter();
                if (writer != null)
                {
                    mutate(writer);
                    if (writer.TrySave()) return "без перекодирования";
                }
            }
            catch { }

            // 2) Перепаковка: кадр передаётся кодировщику без изменений
            byte[] result;
            using (var ms = new MemoryStream(original, false))
            {
                var dec = BitmapDecoder.Create(ms, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.None);
                BitmapEncoder enc;
                if (det.IsJpeg) enc = new JpegBitmapEncoder { QualityLevel = 98 };
                else enc = new TiffBitmapEncoder();

                for (int i = 0; i < dec.Frames.Count; i++)
                {
                    var src = dec.Frames[i];
                    BitmapMetadata md = src.Metadata is BitmapMetadata m0 ? (BitmapMetadata)m0.Clone() : new BitmapMetadata(det.IsJpeg ? "jpg" : "tiff");
                    if (det.IsJpeg)
                    {
                        try { md.SetQuery("/app1/ifd/PaddingSchema:Padding", (uint)4096); } catch { }
                        try { md.SetQuery("/app1/ifd/exif/PaddingSchema:Padding", (uint)4096); } catch { }
                        try { md.SetQuery("/xmp/PaddingSchema:Padding", (uint)4096); } catch { }
                    }
                    if (i == 0) mutate(md);
                    enc.Frames.Add(BitmapFrame.Create(src, src.Thumbnail, md, src.ColorContexts));
                }
                using var outMs = new MemoryStream();
                enc.Save(outMs);
                result = outMs.ToArray();
            }

            // Проверка: результат должен декодироваться и иметь те же размеры
            using (var check = new MemoryStream(result, false))
            using (var orig = new MemoryStream(original, false))
            {
                var a = BitmapDecoder.Create(check, BitmapCreateOptions.None, BitmapCacheOption.OnLoad).Frames[0];
                var b = BitmapDecoder.Create(orig, BitmapCreateOptions.DelayCreation, BitmapCacheOption.None).Frames[0];
                if (a.PixelWidth != b.PixelWidth || a.PixelHeight != b.PixelHeight)
                    throw new InvalidOperationException("Проверка результата не пройдена — исходный файл не изменён.");
            }
            ReplaceAtomically(path, result);
            return det.IsJpeg ? "с перепаковкой файла" : "TIFF перезаписан без потерь";
        }

        public static void ReplaceAtomically(string path, byte[] content)
        {
            string dir = Path.GetDirectoryName(path) ?? ".";
            string tmp = Path.Combine(dir, "." + Path.GetFileName(path) + "." + Guid.NewGuid().ToString("N").Substring(0, 8) + ".neontmp");
            try
            {
                File.WriteAllBytes(tmp, content);
                File.SetAttributes(tmp, FileAttributes.Hidden);
                File.Replace(tmp, path, null, true);
                try { File.SetAttributes(path, File.GetAttributes(path) & ~FileAttributes.Hidden); } catch { }
            }
            finally
            {
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            }
        }

        /// <summary>
        /// Удаление ВСЕХ метаданных (EXIF, GPS, XMP, IPTC, комментарии) в новый файл-копию.
        /// Для JPEG — без перекодирования (вырезаются служебные сегменты), ICC-профиль сохраняется.
        /// </summary>
        public static string StripToCopy(string path, out string newPath)
        {
            byte[] data = File.ReadAllBytes(path);
            var det = FormatDetector.Detect(data, path);
            string dir = Path.GetDirectoryName(path) ?? ".";
            string name = Path.GetFileNameWithoutExtension(path);
            string ext = Path.GetExtension(path);

            if (det.IsJpeg && GetJpegOrientation(data) <= 1)
            {
                byte[] clean = StripJpegSegments(data);
                newPath = UniquePath(dir, name + "_clean", ext);
                File.WriteAllBytes(newPath, clean);
                return "Метаданные удалены без перекодирования изображения.";
            }

            // Остальные форматы (и JPEG с поворотом по EXIF) — через декодер
            using var img = ImageLoader.DecodeMagick(path, 0, long.MaxValue / 4);
            var cp = img.GetColorProfile();
            img.Strip();
            if (cp != null) { try { img.SetProfile(cp); } catch { } }
            string outExt;
            ImageMagick.MagickFormat fmt;
            switch (det.MagickFormat)
            {
                case "Png": fmt = ImageMagick.MagickFormat.Png; outExt = ".png"; break;
                case "WebP": fmt = ImageMagick.MagickFormat.WebP; outExt = ".webp"; img.Quality = 95; break;
                case "Tiff": fmt = ImageMagick.MagickFormat.Tiff; outExt = ".tif"; break;
                case "Bmp": fmt = ImageMagick.MagickFormat.Bmp; outExt = ".bmp"; break;
                case "Gif": fmt = ImageMagick.MagickFormat.Png; outExt = ".png"; break;
                default: fmt = ImageMagick.MagickFormat.Jpeg; outExt = ".jpg"; img.Quality = 95; break;
            }
            newPath = UniquePath(dir, name + "_clean", outExt);
            img.Write(newPath, fmt);
            return "Метаданные удалены (изображение пересохранено).";
        }

        public static string UniquePath(string dir, string baseName, string ext)
        {
            string p = Path.Combine(dir, baseName + ext);
            int i = 2;
            while (File.Exists(p)) p = Path.Combine(dir, $"{baseName} ({i++}){ext}");
            return p;
        }

        private static int GetJpegOrientation(byte[] data)
        {
            try
            {
                using var ms = new MemoryStream(data, false);
                var dirs = MetadataExtractor.ImageMetadataReader.ReadMetadata(ms);
                foreach (var d in dirs.OfType<MetadataExtractor.Formats.Exif.ExifIfd0Directory>())
                    if (d.TryGetInt32(MetadataExtractor.Formats.Exif.ExifDirectoryBase.TagOrientation, out int o)) return o;
            }
            catch { }
            return 1;
        }

        /// <summary>Вырезает APP1..APP15 (кроме ICC-профиля APP2 и Adobe APP14) и комментарии из JPEG.</summary>
        public static byte[] StripJpegSegments(byte[] d)
        {
            if (d.Length < 4 || d[0] != 0xFF || d[1] != 0xD8) throw new InvalidDataException("Не JPEG");
            using var o = new MemoryStream(d.Length);
            o.WriteByte(0xFF); o.WriteByte(0xD8);
            int i = 2;
            while (i < d.Length - 1)
            {
                if (d[i] != 0xFF) throw new InvalidDataException("Повреждённая структура JPEG");
                byte marker = d[i + 1];
                if (marker == 0xFF) { i++; continue; }
                if (marker == 0xD9) { o.WriteByte(0xFF); o.WriteByte(0xD9); break; }
                if (marker == 0x01 || (marker >= 0xD0 && marker <= 0xD7))
                {
                    o.WriteByte(0xFF); o.WriteByte(marker); i += 2; continue;
                }
                if (i + 3 >= d.Length) break;
                int len = (d[i + 2] << 8) | d[i + 3];
                if (len < 2 || i + 2 + len > d.Length) throw new InvalidDataException("Повреждённый сегмент JPEG");

                if (marker == 0xDA)
                {
                    // Начало данных изображения — копируем всё до конца
                    o.Write(d, i, d.Length - i);
                    break;
                }

                bool keep = true;
                if (marker == 0xFE) keep = false; // COM
                else if (marker >= 0xE1 && marker <= 0xEF)
                {
                    keep = false;
                    if (marker == 0xE2 && len > 14 && System.Text.Encoding.ASCII.GetString(d, i + 4, 11) == "ICC_PROFILE") keep = true;
                    if (marker == 0xEE && len > 7 && System.Text.Encoding.ASCII.GetString(d, i + 4, 5) == "Adobe") keep = true;
                }
                if (keep) o.Write(d, i, 2 + len);
                i += 2 + len;
            }
            return o.ToArray();
        }
    }
}
