using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Media.Imaging;
using MetadataExtractor;
using MetadataExtractor.Formats.Exif;
using NeonView.Imaging;
using NeonView.Security;
using MDirectory = MetadataExtractor.Directory;

namespace NeonView.Metadata
{
    public sealed class PropRow
    {
        public string Group { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }

    public sealed class EditableMeta
    {
        public string Title = "", Subject = "", Comment = "", Keywords = "", Authors = "", Copyright = "",
                      DateTaken = "", CameraMake = "", CameraModel = "", Software = "";
        public int Rating;
    }

    public sealed class MetadataReport
    {
        public List<PropRow> File = new List<PropRow>();
        public List<PropRow> Image = new List<PropRow>();
        public List<PropRow> Camera = new List<PropRow>();
        public List<PropRow> Security = new List<PropRow>();
        public List<PropRow> All = new List<PropRow>();
        public double? Latitude, Longitude, Altitude;
        public bool CanEdit;
        public string EditNote;
        public EditableMeta Editable = new EditableMeta();
        public DetectResult Detect;
        public int DirectoryCount;
    }

    public static class MetadataService
    {
        private const int MaxValueLength = 2000;

        private static string Trunc(string s)
        {
            if (s == null) return "";
            s = new string(s.Select(ch => char.IsControl(ch) && ch != '\n' && ch != '\t' ? ' ' : ch).ToArray());
            return s.Length > MaxValueLength ? s.Substring(0, MaxValueLength) + "…" : s;
        }

        public static string FormatSize(long bytes)
        {
            string[] u = { "Б", "КБ", "МБ", "ГБ" };
            double v = bytes; int i = 0;
            while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
            return i == 0 ? $"{bytes} Б" : $"{v:0.##} {u[i]}";
        }

        public static MetadataReport Read(string path, DecodedImage decoded, long maxBytes)
        {
            var rep = new MetadataReport();
            var fi = new FileInfo(path);
            byte[] data = ImageLoader.ReadFileSafe(path, maxBytes);
            var det = FormatDetector.Detect(data, path);
            rep.Detect = det;

            void F(string n, string v) => rep.File.Add(new PropRow { Group = "Файл", Name = n, Value = Trunc(v) });
            F("Имя", fi.Name);
            F("Папка", fi.DirectoryName);
            F("Размер", $"{FormatSize(fi.Length)} ({fi.Length:N0} байт)");
            F("Формат (по содержимому)", det.DisplayName ?? "не распознан");
            F("Расширение", fi.Extension);
            F("Создан", fi.CreationTime.ToString("dd.MM.yyyy HH:mm:ss"));
            F("Изменён", fi.LastWriteTime.ToString("dd.MM.yyyy HH:mm:ss"));
            F("Открыт", fi.LastAccessTime.ToString("dd.MM.yyyy HH:mm:ss"));
            var attrs = new List<string>();
            if (fi.IsReadOnly) attrs.Add("только чтение");
            if ((fi.Attributes & FileAttributes.Hidden) != 0) attrs.Add("скрытый");
            if ((fi.Attributes & FileAttributes.System) != 0) attrs.Add("системный");
            if ((fi.Attributes & FileAttributes.Compressed) != 0) attrs.Add("сжат NTFS");
            if ((fi.Attributes & FileAttributes.Encrypted) != 0) attrs.Add("зашифрован EFS");
            F("Атрибуты", attrs.Count > 0 ? string.Join(", ", attrs) : "обычный");
            try
            {
                using var sha = SHA256.Create();
                F("SHA-256", Convert.ToHexString(sha.ComputeHash(data)).ToLowerInvariant());
            }
            catch { }

            // --- Безопасность ---
            void S(string n, string v) => rep.Security.Add(new PropRow { Group = "Безопасность", Name = n, Value = Trunc(v) });
            var motw = Motw.Read(path);
            if (motw != null)
            {
                S("Источник файла", motw.ZoneName + (motw.IsInternet ? " — файл скачан из сети" : ""));
                if (!string.IsNullOrEmpty(motw.HostUrl)) S("Адрес загрузки", motw.HostUrl);
                if (!string.IsNullOrEmpty(motw.ReferrerUrl)) S("Страница-источник", motw.ReferrerUrl);
            }
            else S("Источник файла", "Нет метки загрузки из интернета");
            S("Проверка сигнатуры", det.Rejected ? "ОТКЛОНЁН: " + det.Reason : "Содержимое соответствует формату " + det.DisplayName);
            if (det.ExtensionMismatch) S("Внимание", det.MismatchNote);
            if (decoded?.SvgRemovedItems > 0) S("SVG-фильтр", $"Удалено потенциально опасных элементов: {decoded.SvgRemovedItems}");
            S("Режим чтения", "Только чтение, файл декодируется изолированно в памяти, сетевые и скриптовые функции декодера отключены");

            // --- Изображение ---
            if (decoded != null)
            {
                foreach (var kv in decoded.Info) rep.Image.Add(new PropRow { Group = "Изображение", Name = kv.Key, Value = kv.Value });
                if (decoded.IsAnimated)
                {
                    int total = decoded.Frames.Sum(f => f.DelayMs);
                    rep.Image.Add(new PropRow { Group = "Изображение", Name = "Анимация", Value = $"{decoded.Frames.Count} кадров, {total / 1000.0:0.##} с" });
                }
            }

            // --- Все метаданные ---
            IReadOnlyList<MDirectory> dirs = null;
            if (!det.IsSvg && !det.Rejected)
            {
                try
                {
                    using var ms = new MemoryStream(data, false);
                    dirs = ImageMetadataReader.ReadMetadata(ms);
                }
                catch { dirs = null; }
            }
            if (dirs != null)
            {
                rep.DirectoryCount = dirs.Count;
                foreach (var dir in dirs)
                {
                    foreach (var tag in dir.Tags)
                    {
                        string val;
                        try { val = tag.Description; } catch { val = null; }
                        if (string.IsNullOrWhiteSpace(val)) continue;
                        rep.All.Add(new PropRow { Group = dir.Name, Name = tag.Name, Value = Trunc(val) });
                    }
                    foreach (var err in dir.Errors)
                        rep.All.Add(new PropRow { Group = dir.Name, Name = "⚠ Ошибка разбора", Value = Trunc(err) });
                }
                FillCamera(rep, dirs);
                FillGps(rep, dirs);
            }

            // --- Редактируемые поля ---
            if (det.SupportsMetadataEdit)
            {
                rep.CanEdit = true;
                try { rep.Editable = MetadataWriter.ReadEditable(data); }
                catch (Exception ex) { rep.EditNote = "Не удалось прочитать поля: " + ex.Message; }
                if (fi.IsReadOnly) { rep.CanEdit = false; rep.EditNote = "Файл помечен «только чтение»."; }
            }
            else
            {
                rep.EditNote = "Редактирование метаданных доступно для JPEG и TIFF. Для других форматов сохраните копию в JPEG в редакторе.";
            }
            return rep;
        }

        private static string Find(IReadOnlyList<MDirectory> dirs, params string[] names)
        {
            foreach (var n in names)
                foreach (var d in dirs)
                    foreach (var t in d.Tags)
                        if (string.Equals(t.Name, n, StringComparison.OrdinalIgnoreCase))
                        {
                            string v = null;
                            try { v = t.Description; } catch { }
                            if (!string.IsNullOrWhiteSpace(v)) return v.Trim();
                        }
            return null;
        }

        private static void FillCamera(MetadataReport rep, IReadOnlyList<MDirectory> dirs)
        {
            void C(string n, params string[] tags)
            {
                var v = Find(dirs, tags);
                if (v != null) rep.Camera.Add(new PropRow { Group = "Съёмка", Name = n, Value = Trunc(v) });
            }
            C("Производитель", "Make");
            C("Модель камеры", "Model");
            C("Объектив", "Lens Model", "Lens", "Lens Specification");
            C("Дата съёмки", "Date/Time Original", "Date/Time Digitized", "Date/Time");
            C("Выдержка", "Exposure Time", "Shutter Speed Value");
            C("Диафрагма", "F-Number", "Aperture Value");
            C("ISO", "ISO Speed Ratings", "Photographic Sensitivity", "ISO");
            C("Фокусное расстояние", "Focal Length");
            C("ФР в экв. 35 мм", "Focal Length 35");
            C("Поправка экспозиции", "Exposure Bias Value");
            C("Режим экспозиции", "Exposure Program");
            C("Замер", "Metering Mode");
            C("Вспышка", "Flash");
            C("Баланс белого", "White Balance Mode", "White Balance");
            C("Программа", "Software");
            C("Автор", "Artist", "By-line", "Creator");
            C("Авторские права", "Copyright", "Copyright Notice");
            C("Описание", "Image Description", "Caption/Abstract", "Windows XP Title");
        }

        private static void FillGps(MetadataReport rep, IReadOnlyList<MDirectory> dirs)
        {
            var gps = dirs.OfType<GpsDirectory>().FirstOrDefault();
            if (gps == null) return;
            try
            {
                double? lat = Dms(gps.GetRationalArray(GpsDirectory.TagLatitude));
                double? lon = Dms(gps.GetRationalArray(GpsDirectory.TagLongitude));
                if (lat.HasValue && lon.HasValue)
                {
                    string latRef = gps.GetString(GpsDirectory.TagLatitudeRef) ?? "N";
                    string lonRef = gps.GetString(GpsDirectory.TagLongitudeRef) ?? "E";
                    if (latRef.StartsWith("S", StringComparison.OrdinalIgnoreCase)) lat = -lat;
                    if (lonRef.StartsWith("W", StringComparison.OrdinalIgnoreCase)) lon = -lon;
                    if (Math.Abs(lat.Value) <= 90 && Math.Abs(lon.Value) <= 180 && !(lat == 0 && lon == 0))
                    {
                        rep.Latitude = lat;
                        rep.Longitude = lon;
                    }
                }
                if (gps.TryGetRational(GpsDirectory.TagAltitude, out var alt))
                {
                    double a = alt.ToDouble();
                    if (gps.TryGetByte(GpsDirectory.TagAltitudeRef, out byte aref) && aref == 1) a = -a;
                    if (double.IsFinite(a)) rep.Altitude = a;
                }
            }
            catch { }
        }

        private static double? Dms(Rational[] r)
        {
            if (r == null || r.Length < 1) return null;
            double d = r[0].ToDouble();
            double m = r.Length > 1 ? r[1].ToDouble() : 0;
            double s = r.Length > 2 ? r[2].ToDouble() : 0;
            double v = d + m / 60 + s / 3600;
            return double.IsFinite(v) ? v : null;
        }

        public static string FormatCoord(double lat, double lon) =>
            string.Format(CultureInfo.InvariantCulture, "{0:0.000000}, {1:0.000000}", lat, lon);

        public static string FormatDms(double lat, double lon)
        {
            static string P(double v, string pos, string neg)
            {
                string h = v >= 0 ? pos : neg;
                v = Math.Abs(v);
                int d = (int)v; double mf = (v - d) * 60; int m = (int)mf; double s = (mf - m) * 60;
                return $"{d}°{m:00}′{s:00.0}″ {h}";
            }
            return P(lat, "с. ш.", "ю. ш.") + ", " + P(lon, "в. д.", "з. д.");
        }
    }
}
