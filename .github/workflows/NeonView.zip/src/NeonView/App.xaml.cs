using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using NeonView.Imaging;
using NeonView.Security;
using NeonView.Theming;

namespace NeonView
{
    public partial class App : Application
    {
        public static AppSettings Settings { get; private set; } = new AppSettings();

        /// <summary>Вызывается при изменении настроек (тема, вид и т.д.).</summary>
        public static event Action SettingsChanged;

        public static void RaiseSettingsChanged()
        {
            ThemeManager.Apply(Settings);
            SettingsChanged?.Invoke();
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            string startDir = Environment.CurrentDirectory;

            // 1. Защита процесса до загрузки чего-либо ещё
            SecurityHardening.Apply();

            DispatcherUnhandledException += OnDispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += (s, a) => CrashLog.Write(a.ExceptionObject as Exception);
            TaskScheduler.UnobservedTaskException += (s, a) => { CrashLog.Write(a.Exception); a.SetObserved(); };

            base.OnStartup(e);

            Settings = SettingsStore.Load();
            ThemeManager.Apply(Settings);

            try
            {
                MagickBootstrap.Initialize();
            }
            catch (Exception ex)
            {
                CrashLog.Write(ex);
                MessageBox.Show("Не удалось инициализировать модуль декодирования изображений.\n\n" + ex.Message,
                    "NeonView", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            string arg = e.Args?.FirstOrDefault(a => !string.IsNullOrWhiteSpace(a) && !a.StartsWith("--", StringComparison.Ordinal));
            if (arg != null)
            {
                try { arg = Path.GetFullPath(Path.Combine(startDir, arg.Trim('"'))); } catch { arg = null; }
            }
            var w = new MainWindow(arg);
            MainWindow = w;
            w.Show();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            try { SettingsStore.Save(Settings); } catch { }
            try { ThumbnailService.Shutdown(); } catch { }
            try { MagickBootstrap.Cleanup(); } catch { }
            base.OnExit(e);
        }

        private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            CrashLog.Write(e.Exception);
            e.Handled = true;
            try
            {
                MessageBox.Show("Произошла непредвиденная ошибка, но приложение продолжит работу.\n\n" + e.Exception.Message,
                    "NeonView", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch { }
        }
    }

    /// <summary>Один небольшой файл журнала ошибок (перезаписывается, не растёт бесконечно).</summary>
    public static class CrashLog
    {
        private const long MaxSize = 64 * 1024;
        private static readonly object Gate = new object();

        public static string LogPath => Path.Combine(AppPaths.DataDir, "error.log");

        public static void Write(Exception ex)
        {
            if (ex == null) return;
            try
            {
                lock (Gate)
                {
                    Directory.CreateDirectory(AppPaths.DataDir);
                    var fi = new FileInfo(LogPath);
                    if (fi.Exists && fi.Length > MaxSize) fi.Delete();
                    File.AppendAllText(LogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex.GetType().Name}: {ex.Message}{Environment.NewLine}{ex.StackTrace}{Environment.NewLine}{Environment.NewLine}");
                }
            }
            catch { }
        }
    }

    public static class AppPaths
    {
        public static string DataDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NeonView");
        public static string SettingsDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NeonView");
        public static string TempDir => Path.Combine(DataDir, "Temp");
    }
}
