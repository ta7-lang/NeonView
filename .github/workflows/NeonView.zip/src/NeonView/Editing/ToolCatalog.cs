using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using ImageMagick;

namespace NeonView.Editing
{
    public sealed class EditContext
    {
        /// <summary>Масштаб редактируемого изображения относительно оригинала (для превью &lt; 1).</summary>
        public double Scale = 1;
        public double R(double px) => Math.Max(0.3, px * Scale);
    }

    public enum ParamKind { Slider, Choice }

    public sealed class ToolParam
    {
        public string Label { get; set; }
        public double Min { get; set; }
        public double Max { get; set; }
        public double Default { get; set; }
        public double Step { get; set; } = 1;
        public string Unit { get; set; } = "";
        public string[] Options { get; set; }
        public ParamKind Kind { get; set; } = ParamKind.Slider;
        public string Hint { get; set; }

        public static ToolParam S(string label, double min, double max, double def, double step = 1, string unit = "", string hint = null) =>
            new ToolParam { Label = label, Min = min, Max = max, Default = def, Step = step, Unit = unit, Hint = hint };

        public static ToolParam C(string label, string hint, params string[] options) =>
            new ToolParam { Label = label, Kind = ParamKind.Choice, Options = options, Min = 0, Max = options.Length - 1, Default = 0, Hint = hint };

        public string Format(double v)
        {
            if (Kind == ParamKind.Choice)
            {
                int i = (int)Math.Round(v);
                return Options != null && i >= 0 && i < Options.Length ? Options[i] : "";
            }
            string num = Step < 0.1 ? v.ToString("0.00", CultureInfo.CurrentCulture)
                       : Step < 1 ? v.ToString("0.0", CultureInfo.CurrentCulture)
                       : v.ToString("0", CultureInfo.CurrentCulture);
            if (Min < 0 && v > 0) num = "+" + num;
            return num + Unit;
        }
    }

    public sealed class ToolDef
    {
        public string Id { get; set; }
        public string Category { get; set; }
        public string Name { get; set; }
        public string Glyph { get; set; }
        public string Short { get; set; }
        public string Explanation { get; set; }
        public string Tip { get; set; }
        public List<ToolParam> Params { get; set; } = new List<ToolParam>();
        public Action<IMagickImage<ushort>, double[], EditContext> Apply { get; set; }
        public bool HasParams => Params.Count > 0;

        public double[] Defaults() => Params.Select(p => p.Default).ToArray();

        public string Describe(double[] v)
        {
            if (Params.Count == 0 || v == null) return "";
            return string.Join(", ", Params.Select((p, i) => Params.Count == 1 ? p.Format(v[i]) : p.Label + " " + p.Format(v[i])));
        }
    }

    public sealed class EditOp
    {
        public ToolDef Tool { get; }
        public double[] Values { get; }
        public EditOp(ToolDef t, double[] v) { Tool = t; Values = v; }
        public string Title
        {
            get
            {
                string d = Tool.Describe(Values);
                return string.IsNullOrEmpty(d) ? Tool.Name : Tool.Name + ": " + d;
            }
        }
        public void Run(IMagickImage<ushort> img, EditContext ctx) => Tool.Apply(img, Values, ctx);
    }

    /// <summary>Набор инструментов редактирования с понятными пояснениями.</summary>
    public static class ToolCatalog
    {
        public static readonly string[] Categories = { "Геометрия", "Свет", "Цвет", "Детали", "Эффекты" };

        public static readonly List<ToolDef> Tools = Build();

        private static int I(double v) => (int)Math.Round(v);

        private static void Mul(IMagickImage<ushort> img, Channels ch, double k)
        {
            if (Math.Abs(k - 1) < 1e-4) return;
            img.Evaluate(ch, EvaluateOperator.Multiply, k);
        }

        private static void CropRect(IMagickImage<ushort> img, int x, int y, int w, int h)
        {
            w = Math.Max(1, Math.Min(w, img.Width - x));
            h = Math.Max(1, Math.Min(h, img.Height - y));
            if (x <= 0 && y <= 0 && w >= img.Width && h >= img.Height) return;
            img.Crop(new MagickGeometry(Math.Max(0, x), Math.Max(0, y), w, h));
            img.Page = new MagickGeometry(0, 0, 0, 0);
        }

        private static string HueHex(double hue, double s = 1, double v = 1)
        {
            var c = Theming.ThemeManager.FromHsv(hue, s, v);
            return $"#{c.R:X2}{c.G:X2}{c.B:X2}";
        }

        private static List<ToolDef> Build()
        {
            var t = new List<ToolDef>();

            // ================= ГЕОМЕТРИЯ =================
            t.Add(new ToolDef
            {
                Id = "rotate", Category = "Геометрия", Name = "Поворот на 90°", Glyph = "⟳",
                Short = "Повернуть снимок на четверть или пол-оборота",
                Explanation = "Поворачивает изображение без потери деталей. Используйте, если фото лежит «на боку» или вверх ногами.",
                Tip = "Быстрый поворот только для просмотра — клавиша R. Здесь поворот сохраняется в файл.",
                Params = { ToolParam.C("Направление", null, "90° по часовой", "90° против часовой", "180°") },
                Apply = (img, v, c) => img.Rotate(I(v[0]) switch { 1 => -90, 2 => 180, _ => 90 })
            });
            t.Add(new ToolDef
            {
                Id = "flip", Category = "Геометрия", Name = "Отражение", Glyph = "⇆",
                Short = "Зеркально отразить по горизонтали или вертикали",
                Explanation = "Отражает изображение как в зеркале. Полезно для селфи (камера телефона часто их зеркалит) и для композиции.",
                Tip = "Отражение по вертикали — это не то же самое, что поворот на 180°.",
                Params = { ToolParam.C("Ось", null, "Зеркально (слева направо)", "Вверх ногами (сверху вниз)") },
                Apply = (img, v, c) => { if (I(v[0]) == 1) img.Flip(); else img.Flop(); }
            });
            t.Add(new ToolDef
            {
                Id = "straighten", Category = "Геометрия", Name = "Выравнивание горизонта", Glyph = "⦨",
                Short = "Исправить завал горизонта с автообрезкой краёв",
                Explanation = "Поворачивает снимок на небольшой угол и автоматически обрезает пустые углы, чтобы горизонт, линия моря или стены стали ровными.",
                Tip = "Двойной щелчок по ползунку сбрасывает значение. Ориентируйтесь на самую длинную прямую линию в кадре.",
                Params = { ToolParam.S("Угол", -45, 45, 0, 0.1, "°") },
                Apply = (img, v, c) =>
                {
                    double a = v[0];
                    if (Math.Abs(a) < 0.05) return;
                    int w0 = img.Width, h0 = img.Height;
                    img.BackgroundColor = MagickColors.Transparent;
                    img.Rotate(a);
                    double rad = Math.Abs(a) * Math.PI / 180.0, cs = Math.Cos(rad), sn = Math.Sin(rad);
                    double s = Math.Min(w0 / (w0 * cs + h0 * sn), h0 / (w0 * sn + h0 * cs));
                    int cw = (int)Math.Floor(w0 * s), ch = (int)Math.Floor(h0 * s);
                    CropRect(img, (img.Width - cw) / 2, (img.Height - ch) / 2, cw, ch);
                }
            });
            t.Add(new ToolDef
            {
                Id = "crop", Category = "Геометрия", Name = "Обрезка", Glyph = "✂",
                Short = "Отрезать лишнее с любого края",
                Explanation = "Убирает части изображения с каждой стороны. Значения — в процентах от ширины/высоты, поэтому обрезка одинаково точно применится и к полному разрешению.",
                Tip = "Правило третей: помещайте главный объект на пересечение воображаемых линий, делящих кадр на три части.",
                Params =
                {
                    ToolParam.S("Слева", 0, 45, 0, 0.5, "%"), ToolParam.S("Сверху", 0, 45, 0, 0.5, "%"),
                    ToolParam.S("Справа", 0, 45, 0, 0.5, "%"), ToolParam.S("Снизу", 0, 45, 0, 0.5, "%")
                },
                Apply = (img, v, c) =>
                {
                    int w = img.Width, h = img.Height;
                    int x = (int)(w * v[0] / 100), y = (int)(h * v[1] / 100);
                    int r = (int)(w * v[2] / 100), b = (int)(h * v[3] / 100);
                    CropRect(img, x, y, w - x - r, h - y - b);
                }
            });
            t.Add(new ToolDef
            {
                Id = "aspect", Category = "Геометрия", Name = "Кадрирование по пропорциям", Glyph = "▭",
                Short = "Квадрат, 4:3, 16:9, сторис 9:16…",
                Explanation = "Обрезает снимок до выбранных пропорций по центру. «Сдвиг» перемещает рамку вдоль длинной стороны — так можно сохранить нужный объект в кадре.",
                Tip = "1:1 — для аватарок и Instagram, 4:5 — для ленты, 9:16 — для сторис, 16:9 — для экранов и YouTube.",
                Params =
                {
                    ToolParam.C("Пропорции", null, "1:1 (квадрат)", "4:3", "3:2", "16:9", "9:16 (сторис)", "4:5", "3:4", "2:3", "21:9"),
                    ToolParam.S("Сдвиг рамки", -100, 100, 0, 1, "%")
                },
                Apply = (img, v, c) =>
                {
                    double[] ratios = { 1, 4.0 / 3, 3.0 / 2, 16.0 / 9, 9.0 / 16, 4.0 / 5, 3.0 / 4, 2.0 / 3, 21.0 / 9 };
                    double r = ratios[Math.Clamp(I(v[0]), 0, ratios.Length - 1)];
                    int w = img.Width, h = img.Height;
                    int cw = w, ch = (int)Math.Round(w / r);
                    if (ch > h) { ch = h; cw = (int)Math.Round(h * r); }
                    double shift = v[1] / 100.0;
                    int x = (int)((w - cw) / 2.0 * (1 + shift));
                    int y = (int)((h - ch) / 2.0 * (1 + shift));
                    CropRect(img, Math.Clamp(x, 0, w - cw), Math.Clamp(y, 0, h - ch), cw, ch);
                }
            });
            t.Add(new ToolDef
            {
                Id = "resize", Category = "Геометрия", Name = "Изменение размера", Glyph = "⤢",
                Short = "Уменьшить или увеличить изображение",
                Explanation = "Меняет количество пикселей. Уменьшение делает файл легче для отправки в мессенджерах и почте. Используется качественный фильтр Ланцоша.",
                Tip = "Увеличение больше 100% не добавляет деталей — изображение лишь становится крупнее и мягче.",
                Params = { ToolParam.S("Масштаб", 5, 200, 50, 1, "%") },
                Apply = (img, v, c) => { if (Math.Abs(v[0] - 100) > 0.01) img.Resize(new Percentage(v[0])); }
            });

            // ================= СВЕТ =================
            t.Add(new ToolDef
            {
                Id = "autofix", Category = "Свет", Name = "Автокоррекция", Glyph = "✦",
                Short = "Одно нажатие — сбалансированные уровни и гамма",
                Explanation = "Автоматически растягивает тональный диапазон (самые тёмные точки становятся чёрными, самые светлые — белыми) и подбирает гамму. Хорошая отправная точка для тусклых снимков.",
                Tip = "После автокоррекции можно точнее донастроить яркость и насыщенность.",
                Apply = (img, v, c) => { img.AutoLevel(); img.AutoGamma(); }
            });
            t.Add(new ToolDef
            {
                Id = "brightcontrast", Category = "Свет", Name = "Яркость и контраст", Glyph = "☀",
                Short = "Сделать светлее/темнее и «сочнее»",
                Explanation = "Яркость равномерно осветляет или затемняет всё изображение. Контраст увеличивает разницу между светлыми и тёмными участками — снимок становится выразительнее.",
                Tip = "Слишком сильный контраст «выбивает» детали в тенях и светах — следите за небом и тёмной одеждой.",
                Params = { ToolParam.S("Яркость", -100, 100, 0), ToolParam.S("Контраст", -100, 100, 0) },
                Apply = (img, v, c) => { if (v[0] != 0 || v[1] != 0) img.BrightnessContrast(new Percentage(v[0]), new Percentage(v[1])); }
            });
            t.Add(new ToolDef
            {
                Id = "exposure", Category = "Свет", Name = "Экспозиция", Glyph = "◐",
                Short = "Как будто снимок сделан с другой выдержкой",
                Explanation = "Изменяет количество «света» в ступенях EV, как в фотоаппарате: +1 EV — вдвое светлее, −1 EV — вдвое темнее. В отличие от яркости, сохраняет соотношения тонов.",
                Tip = "Для недоэкспонированных RAW-снимков обычно хватает +0.3…+1 EV.",
                Params = { ToolParam.S("Экспозиция", -3, 3, 0, 0.05, " EV") },
                Apply = (img, v, c) =>
                {
                    double k = Math.Pow(2, v[0]);
                    Mul(img, Channels.Red, k); Mul(img, Channels.Green, k); Mul(img, Channels.Blue, k);
                }
            });
            t.Add(new ToolDef
            {
                Id = "gamma", Category = "Свет", Name = "Гамма (средние тона)", Glyph = "◑",
                Short = "Осветлить тени, не пересвечивая небо",
                Explanation = "Меняет яркость средних тонов, почти не трогая самые тёмные и самые светлые точки. Значение больше 1 — светлее, меньше 1 — темнее.",
                Tip = "Отличный способ «вытянуть» лица в тени на фоне яркого неба.",
                Params = { ToolParam.S("Гамма", 0.2, 3, 1, 0.01) },
                Apply = (img, v, c) => { if (Math.Abs(v[0] - 1) > 0.005) img.GammaCorrect(v[0]); }
            });
            t.Add(new ToolDef
            {
                Id = "levels", Category = "Свет", Name = "Уровни", Glyph = "▤",
                Short = "Точки чёрного и белого",
                Explanation = "«Точка чёрного» делает все тона темнее заданного порога чисто чёрными, «точка белого» — светлее порога чисто белыми. Так убирается серая дымка и повышается глубина.",
                Tip = "Смотрите гистограмму в окне «Свойства»: если по краям пусто — уровни можно смело подтянуть.",
                Params = { ToolParam.S("Точка чёрного", 0, 50, 0, 0.5, "%"), ToolParam.S("Точка белого", 50, 100, 100, 0.5, "%") },
                Apply = (img, v, c) => { if (v[0] > 0 || v[1] < 100) img.Level(new Percentage(v[0]), new Percentage(v[1])); }
            });
            t.Add(new ToolDef
            {
                Id = "scurve", Category = "Свет", Name = "Мягкий контраст (S-кривая)", Glyph = "∫",
                Short = "Киношный контраст без жёстких обрезаний",
                Explanation = "Применяет плавную S-образную кривую: тени слегка темнеют, света слегка светлеют, а крайние тона не «обрезаются». Даёт объём без потери деталей.",
                Tip = "Значения 3–6 подходят для большинства пейзажей и портретов.",
                Params = { ToolParam.S("Сила", 0, 15, 4, 0.1) },
                Apply = (img, v, c) => { if (v[0] > 0.05) img.SigmoidalContrast(v[0]); }
            });
            t.Add(new ToolDef
            {
                Id = "normalize", Category = "Свет", Name = "Нормализация", Glyph = "⇕",
                Short = "Растянуть тона на весь диапазон",
                Explanation = "Растягивает яркость так, чтобы использовался весь диапазон от чёрного до белого, отбрасывая самые крайние 2% пикселей. Помогает выцветшим и туманным снимкам.",
                Tip = "Если цвета стали неестественными — отмените и попробуйте «Автокоррекцию».",
                Apply = (img, v, c) => img.Normalize()
            });
            t.Add(new ToolDef
            {
                Id = "equalize", Category = "Свет", Name = "Эквализация гистограммы", Glyph = "≋",
                Short = "Максимально проявить детали (сильный эффект)",
                Explanation = "Перераспределяет тона так, чтобы каждый уровень яркости встречался примерно одинаково часто. Проявляет детали в документах, сканах и тёмных снимках, но часто выглядит неестественно.",
                Tip = "Лучше всего работает для технических снимков, скриншотов и сканов.",
                Apply = (img, v, c) => img.Equalize()
            });

            // ================= ЦВЕТ =================
            t.Add(new ToolDef
            {
                Id = "sathue", Category = "Цвет", Name = "Насыщенность и оттенок", Glyph = "◍",
                Short = "Сочность цветов и сдвиг по цветовому кругу",
                Explanation = "Насыщенность управляет интенсивностью цветов: 0% — чёрно-белое, 100% — без изменений, больше — ярче. Сдвиг оттенка поворачивает все цвета по цветовому кругу (например, зелёное станет синим).",
                Tip = "Для естественного результата не поднимайте насыщенность выше 130–140%.",
                Params = { ToolParam.S("Насыщенность", 0, 300, 100, 1, "%"), ToolParam.S("Сдвиг оттенка", -180, 180, 0, 1, "°") },
                Apply = (img, v, c) =>
                {
                    if (Math.Abs(v[0] - 100) < 0.01 && Math.Abs(v[1]) < 0.01) return;
                    img.Modulate(new Percentage(100), new Percentage(v[0]), new Percentage(100 + v[1] * 100.0 / 180.0));
                }
            });
            t.Add(new ToolDef
            {
                Id = "temperature", Category = "Цвет", Name = "Температура и оттенок", Glyph = "♨",
                Short = "Теплее/холоднее, убрать зелёный или пурпурный",
                Explanation = "Температура смещает цвета к тёплым (жёлто-оранжевым) или холодным (синим) тонам — исправляет желтизну от ламп накаливания или синеву пасмурного дня. Оттенок компенсирует зелёный или пурпурный налёт.",
                Tip = "Ориентируйтесь на то, что должно быть нейтрально-белым или серым: бумагу, облака, стены.",
                Params = { ToolParam.S("Температура", -100, 100, 0), ToolParam.S("Оттенок (зел. ↔ пурп.)", -100, 100, 0) },
                Apply = (img, v, c) =>
                {
                    double tt = v[0] / 100.0, tn = v[1] / 100.0;
                    Mul(img, Channels.Red, 1 + 0.25 * tt + 0.08 * tn);
                    Mul(img, Channels.Blue, 1 - 0.25 * tt + 0.08 * tn);
                    Mul(img, Channels.Green, 1 - 0.18 * tn);
                }
            });
            t.Add(new ToolDef
            {
                Id = "wb", Category = "Цвет", Name = "Автобаланс белого", Glyph = "⚪",
                Short = "Автоматически убрать цветной налёт",
                Explanation = "Анализирует снимок и подстраивает цвета так, чтобы нейтральные участки стали действительно серыми/белыми. Исправляет желтизну, синеву и зеленоватый оттенок.",
                Tip = "Не применяйте к закатам и снимкам с намеренно цветным светом — эффект «съест» атмосферу.",
                Apply = (img, v, c) => img.WhiteBalance()
            });
            t.Add(new ToolDef
            {
                Id = "gray", Category = "Цвет", Name = "Чёрно-белое", Glyph = "◒",
                Short = "Классическая монохромная фотография",
                Explanation = "Преобразует снимок в оттенки серого. «Стандартный» метод учитывает чувствительность глаза к цветам, «Светлота» даёт более ровный результат, «Rec.709» — как в видео.",
                Tip = "Перед переводом в ч/б поднимите контраст — монохром любит выразительные тени.",
                Params = { ToolParam.C("Метод", null, "Стандартный", "Светлота", "Яркость (Rec.709)") },
                Apply = (img, v, c) =>
                {
                    var m = I(v[0]) switch { 1 => PixelIntensityMethod.Lightness, 2 => PixelIntensityMethod.Rec709Luminance, _ => PixelIntensityMethod.Rec601Luma };
                    img.Grayscale(m);
                }
            });
            t.Add(new ToolDef
            {
                Id = "sepia", Category = "Цвет", Name = "Сепия", Glyph = "☕",
                Short = "Тёплый винтажный тон старых фотографий",
                Explanation = "Тонирует изображение в коричневатые оттенки, как у старинных отпечатков. Сила определяет порог тонирования.",
                Tip = "Добавьте «Виньетку» и «Зерно плёнки» для полного винтажного эффекта.",
                Params = { ToolParam.S("Сила", 50, 99, 80, 1, "%") },
                Apply = (img, v, c) => img.SepiaTone(new Percentage(v[0]))
            });
            t.Add(new ToolDef
            {
                Id = "tint", Category = "Цвет", Name = "Цветовая тонировка", Glyph = "◈",
                Short = "Наложить неоновый или любой другой оттенок",
                Explanation = "Окрашивает изображение выбранным цветом с заданной силой. Позволяет создать неоновое, киберпанк- или кинематографичное настроение.",
                Tip = "Оттенки 180–200° — бирюза, 280–320° — неоновый пурпур, 30–45° — тёплое золото.",
                Params = { ToolParam.S("Оттенок", 0, 360, 300, 1, "°"), ToolParam.S("Сила", 0, 100, 25, 1, "%") },
                Apply = (img, v, c) =>
                {
                    if (v[1] <= 0.5) return;
                    img.Colorize(new MagickColor(HueHex(v[0])), new Percentage(v[1]));
                }
            });
            t.Add(new ToolDef
            {
                Id = "negate", Category = "Цвет", Name = "Негатив", Glyph = "◧",
                Short = "Инвертировать цвета",
                Explanation = "Заменяет каждый цвет противоположным: чёрное становится белым, синее — жёлтым. Можно использовать для оцифровки плёночных негативов (с последующим балансом белого).",
                Tip = "Повторное применение возвращает исходные цвета.",
                Apply = (img, v, c) => img.Negate()
            });

            // ================= ДЕТАЛИ =================
            t.Add(new ToolDef
            {
                Id = "sharpen", Category = "Детали", Name = "Резкость", Glyph = "◆",
                Short = "Подчеркнуть мелкие детали и контуры",
                Explanation = "Нерезкое маскирование (Unsharp Mask) усиливает контраст на границах объектов. «Сила» — насколько заметен эффект, «Радиус» — толщина подчёркиваемых контуров.",
                Tip = "Радиус 0.5–1.5 — для мелких деталей и печати; 2–4 — для общего «прояснения». Не переусердствуйте: появятся светлые ореолы.",
                Params = { ToolParam.S("Сила", 0, 300, 80, 1, "%"), ToolParam.S("Радиус", 0.3, 5, 1.2, 0.1, " пикс.") },
                Apply = (img, v, c) => { if (v[0] > 0.5) img.UnsharpMask(0, c.R(v[1]), v[0] / 100.0, 0.02); }
            });
            t.Add(new ToolDef
            {
                Id = "clarity", Category = "Детали", Name = "Чёткость (локальный контраст)", Glyph = "◇",
                Short = "Объём и «хрусткость» фактур",
                Explanation = "Усиливает контраст средних деталей: фактуры камня, дерева, облаков, морщинки. В отличие от резкости, работает с крупными элементами и придаёт снимку объём.",
                Tip = "Для портретов используйте осторожно (10–20%) — кожа может стать грубой.",
                Params = { ToolParam.S("Сила", 0, 100, 30, 1, "%") },
                Apply = (img, v, c) => { if (v[0] > 0.5) img.UnsharpMask(0, c.R(18), v[0] / 100.0 * 0.7, 0); }
            });
            t.Add(new ToolDef
            {
                Id = "blur", Category = "Детали", Name = "Размытие", Glyph = "≈",
                Short = "Смягчить всё изображение",
                Explanation = "Гауссово размытие делает изображение мягче. Подходит для фонов, обоев рабочего стола и скрытия ненужных деталей.",
                Tip = "Небольшое размытие (0.5–1) смягчает цифровой шум и слишком резкие JPEG.",
                Params = { ToolParam.S("Радиус", 0.5, 30, 4, 0.1, " пикс.") },
                Apply = (img, v, c) => img.Blur(0, c.R(v[0]))
            });
            t.Add(new ToolDef
            {
                Id = "denoise", Category = "Детали", Name = "Шумоподавление", Glyph = "⁘",
                Short = "Убрать цифровой шум и «пятнистость»",
                Explanation = "Сглаживает случайные цветные точки и «зерно», которые появляются при съёмке в темноте или на высоком ISO, сохраняя контуры.",
                Tip = "Начинайте с силы 1–2. Высокие значения могут «замылить» мелкие детали.",
                Params = { ToolParam.S("Сила", 1, 5, 2, 1) },
                Apply = (img, v, c) => { for (int i = 0; i < I(v[0]); i++) img.Despeckle(); }
            });
            t.Add(new ToolDef
            {
                Id = "grain", Category = "Детали", Name = "Зерно плёнки", Glyph = "∵",
                Short = "Добавить плёночную фактуру",
                Explanation = "Добавляет мелкий шум, имитирующий зерно фотоплёнки. Придаёт снимку аналоговый характер и маскирует артефакты сжатия.",
                Tip = "Лучше всего смотрится вместе с ч/б или сепией.",
                Params = { ToolParam.S("Сила", 0, 100, 25, 1, "%") },
                Apply = (img, v, c) => { if (v[0] > 0.5) img.AddNoise(NoiseType.Gaussian, 0.05 + v[0] / 100.0 * 0.9); }
            });

            // ================= ЭФФЕКТЫ =================
            t.Add(new ToolDef
            {
                Id = "vignette", Category = "Эффекты", Name = "Виньетка", Glyph = "◉",
                Short = "Затемнить края, привлечь взгляд к центру",
                Explanation = "Плавно затемняет углы и края кадра. Взгляд зрителя естественно направляется к центру — к главному объекту.",
                Tip = "Лёгкая виньетка (20–40%) почти незаметна, но делает снимок цельнее.",
                Params = { ToolParam.S("Сила", 0, 100, 45, 1, "%") },
                Apply = (img, v, c) =>
                {
                    if (v[0] < 0.5) return;
                    double s = v[0] / 100.0;
                    int w = img.Width, h = img.Height;
                    img.BackgroundColor = MagickColors.Black;
                    img.Vignette(0, Math.Max(1, Math.Min(w, h) * 0.18), (int)(w * 0.12 * s), (int)(h * 0.12 * s));
                }
            });
            t.Add(new ToolDef
            {
                Id = "orton", Category = "Эффекты", Name = "Мягкое свечение", Glyph = "✺",
                Short = "Сказочное сияние (эффект Ортона)",
                Explanation = "Накладывает на снимок размытую светлую копию. Света начинают мягко светиться, изображение становится мечтательным — популярно для пейзажей и свадебных фото.",
                Tip = "20–40% — деликатно, 60%+ — выраженный художественный эффект.",
                Params = { ToolParam.S("Сила", 0, 100, 35, 1, "%") },
                Apply = (img, v, c) =>
                {
                    if (v[0] < 0.5) return;
                    using var glow = img.Clone();
                    glow.Blur(0, c.R(14));
                    using var screen = img.Clone();
                    screen.Composite(glow, CompositeOperator.Screen);
                    img.Composite(screen, CompositeOperator.Dissolve, v[0].ToString("0", CultureInfo.InvariantCulture));
                }
            });
            t.Add(new ToolDef
            {
                Id = "neonedges", Category = "Эффекты", Name = "Неоновые контуры", Glyph = "⌁",
                Short = "Светящиеся линии на тёмном фоне",
                Explanation = "Находит контуры объектов и превращает их в яркие светящиеся линии на чёрном фоне — как неоновая вывеска.",
                Tip = "После эффекта примените «Цветовую тонировку», чтобы окрасить неон в любимый цвет.",
                Params = { ToolParam.S("Толщина", 0.5, 4, 1, 0.1), ToolParam.S("Яркость", 100, 400, 220, 1, "%") },
                Apply = (img, v, c) =>
                {
                    img.Edge(c.R(v[0]));
                    img.Modulate(new Percentage(v[1]), new Percentage(250), new Percentage(100));
                }
            });
            t.Add(new ToolDef
            {
                Id = "posterize", Category = "Эффекты", Name = "Постеризация", Glyph = "▦",
                Short = "Плакатный эффект с малым числом цветов",
                Explanation = "Уменьшает число уровней каждого цвета. Плавные переходы превращаются в чёткие пятна, как на поп-арт плакатах.",
                Tip = "4–6 уровней дают самый выразительный поп-арт.",
                Params = { ToolParam.S("Уровни", 2, 32, 6, 1) },
                Apply = (img, v, c) => img.Posterize(I(v[0]))
            });
            t.Add(new ToolDef
            {
                Id = "solarize", Category = "Эффекты", Name = "Соляризация", Glyph = "☼",
                Short = "Сюрреалистичная частичная инверсия",
                Explanation = "Инвертирует только тона светлее порога. Классический фотоэффект Мана Рэя — необычные «металлические» переходы.",
                Tip = "Особенно интересно на чёрно-белых портретах.",
                Params = { ToolParam.S("Порог", 0, 100, 50, 1, "%") },
                Apply = (img, v, c) => img.Solarize(new Percentage(v[0]))
            });
            t.Add(new ToolDef
            {
                Id = "oil", Category = "Эффекты", Name = "Масляная живопись", Glyph = "✎",
                Short = "Как будто нарисовано кистью",
                Explanation = "Превращает снимок в подобие картины маслом: мелкие детали заменяются мазками кисти заданного размера.",
                Tip = "Эффект тяжёлый — на больших фото сохранение может занять некоторое время.",
                Params = { ToolParam.S("Кисть", 1, 10, 3, 0.5) },
                Apply = (img, v, c) => img.OilPaint(c.R(v[0]), 1)
            });
            t.Add(new ToolDef
            {
                Id = "sketch", Category = "Эффекты", Name = "Карандашный рисунок", Glyph = "✐",
                Short = "Набросок простым карандашом",
                Explanation = "Имитирует рисунок карандашом: подчёркивает контуры и штрихует тени.",
                Tip = "Перед эффектом поднимите контраст — штрихи станут чётче.",
                Params = { ToolParam.S("Штрих", 1, 20, 6, 0.5) },
                Apply = (img, v, c) => img.Sketch(0, c.R(v[0]), 135)
            });
            t.Add(new ToolDef
            {
                Id = "charcoal", Category = "Эффекты", Name = "Уголь", Glyph = "✏",
                Short = "Графичный рисунок углём",
                Explanation = "Создаёт чёрно-белое изображение в стиле рисунка углём с выразительными тёмными линиями.",
                Tip = "Подходит для портретов и архитектуры.",
                Params = { ToolParam.S("Сила", 0.5, 10, 2, 0.5) },
                Apply = (img, v, c) => img.Charcoal(0, c.R(v[0]))
            });
            t.Add(new ToolDef
            {
                Id = "emboss", Category = "Эффекты", Name = "Рельеф", Glyph = "⬓",
                Short = "Изображение как чеканка",
                Explanation = "Делает изображение похожим на выдавленный рельеф или барельеф с подсветкой сбоку.",
                Tip = "Комбинируйте с сепией для эффекта «бронзы».",
                Params = { ToolParam.S("Сила", 0.5, 5, 1, 0.1) },
                Apply = (img, v, c) => img.Emboss(0, c.R(v[0]))
            });
            t.Add(new ToolDef
            {
                Id = "pixelate", Category = "Эффекты", Name = "Пикселизация", Glyph = "▩",
                Short = "Ретро-пиксели или скрытие деталей",
                Explanation = "Разбивает изображение на крупные квадраты. Используется для ретро-стиля и для скрытия лиц, номеров и личных данных.",
                Tip = "Для надёжного скрытия личных данных используйте блок не меньше 16 пикселей.",
                Params = { ToolParam.S("Размер блока", 2, 64, 12, 1, " пикс.") },
                Apply = (img, v, c) =>
                {
                    int w = img.Width, h = img.Height;
                    double b = Math.Max(2, v[0] * c.Scale);
                    img.Sample(new MagickGeometry(Math.Max(1, (int)(w / b)), Math.Max(1, (int)(h / b))) { IgnoreAspectRatio = true });
                    img.Sample(new MagickGeometry(w, h) { IgnoreAspectRatio = true });
                }
            });

            return t;
        }
    }
}
